package com.callx.app.feed.controllers;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.callx.app.models.ReelModel;

/**
 * Delegate interface implemented by ReelPlayerFragment.
 * Each controller receives this delegate in its constructor and uses it to
 * access Fragment lifecycle, shared views, shared state, and peer-controller actions.
 */
public interface ReelPlayerDelegate {

    // ── Fragment basics ───────────────────────────────────────────────────

    ReelModel getReel();
    boolean isAdded();
    Context requireContext();
    @Nullable Context getContext();
    @Nullable Activity getActivity();
    Fragment getFragment();
    FragmentManager getChildFragmentManager();
    @Nullable Fragment getParentFragment();
    /** True when this reel is the currently-visible reel in the feed. */
    boolean isCurrentlyVisible();

    // ── Utility ──────────────────────────────────────────────────────────

    @Nullable String safeMyUid();
    String formatCount(int n);
    int dpToPx(int dp);
    void showBottomSheet(DialogFragment sheet, String tag);
    void autoAdvance();

    // ── Shared state reads (from owning controller, readable by peers) ────

    boolean isFollowing();
    boolean isFollowCheckLoaded();
    boolean isPhotoMode();
    boolean hasMultiplePhotos();
    boolean isMuted();
    int getSpeedIndex();
    String[] getSpeedLabels();
    float[] getSpeedSteps();
    boolean isSaved();
    boolean isLiked();
    boolean isReposted();
    /** True when the reel is docked (shrunk) above the open comments sheet. */
    boolean isDocked();

    // ── Player actions (PlayerController) ────────────────────────────────

    void togglePlayPause();
    void toggleMute();
    void cycleSpeed();
    void showSpeedPicker();
    void startDiscAnimation();
    void stopDiscAnimation();
    void stopPhotoSlideshow();
    void startPhotoSlideshow();
    void pausePlayback();

    // ── Social actions (SocialController) ────────────────────────────────

    void toggleLike();
    void toggleSave();
    void toggleFollow();
    void toggleRepost();
    void sendReaction(String emoji);
    void hideReactions();
    void toggleReactionPanel();
    void showLikeAnimation();
    /** Called by SocialController after follow state changes — updates follow button UI. */
    void updateFollowUI(boolean following);
    void recordView();
    void markReelNotificationsRead();

    // ── Share / more-sheet actions (ShareController) ─────────────────────

    void shareReel();
    void downloadReel();
    void openComments();
    void openLikesSheet();
    void openSharesSheet();
    void openCommentsSheet();
    void showMoreOptions();
    void copyReelLink();
    void markNotInterested();

    // ── Navigation / duet actions (DuetController) ───────────────────────

    void openDuet();
    void openStitch();
    void openVideoReply();
    void openShareToStory();
    void openDuetSeries();
    void openDuetInvite();
    void openDuetBattle();
    void openDuetTree();
    void openDuetChallenge();
    void openMultiDuet();
    void openDuetApproval();
    void openReelEdit();
    void openReelAnalytics();
    void openReelReport();
    void openReelQRCode();
    void openPinnedComments();
    void openCollabRequest();
    void openCollabRepost();
    void openBookmarkCollections();
    void openSoundDetail();
    /** Shows the small "Remix and sequence" + audio-info card before SoundDetailActivity. */
    void showSoundQuickActions();
    void openUserReels();
    void openOwnerStatus();
    void confirmDeleteReel();
    void blockReelOwner();
    // Remix & Sequence
    /** Shows the ReelRemixSequencePickerSheet (Remix vs Sequence chooser). */
    void openRemixSequencePicker();
    /** Shows the layout-mode picker (Side-by-Side, React Cam, etc.) then opens ReelRemixActivity. */
    void openRemixWithPicker();
    /** Starts ReelSequenceActivity so the user records their continuation. */
    void openSequence();
    /** Legacy: directly opens ReelRemixActivity with default layout (kept for other callers). */
    void openRemix();
    void openViewRemixes();
    // Watch History
    void openWatchHistory();
    // Quality picker
    void showQualityPicker();
    // v5: Offline save + QoE dashboard entry points
    void saveReelOffline();
    void showQoeStats();
    /** ✅ Shows a dialog telling the user whether THIS reel is on HLS Adaptive Streaming or the per-quality-URL fallback. */
    void showStreamingModeInfo();
    /** Shows a dialog telling the user whether THIS reel is currently cached on disk (won't re-download), and if not, why. */
    void showCacheStatus();
    // Reels Display Mode (Immersive vs Normal) picker
    void showDisplayModePicker();
    /** Toggles the "Background Play" setting (reel keeps playing with audio after app is backgrounded). */
    void toggleBackgroundPlay();
    /** Toggles Cinema Mode (hides right actions, bottom info, top bar, etc.) for the current reel — a 3-dot menu action. */
    void toggleCinemaMode();
    /** True if Cinema Mode is currently hiding the overlay UI for the current reel. */
    boolean isCinemaModeOn();
    /** True if the reel is actively playing right now (used to decide long-press pause/resume). */
    boolean isPlaybackActive();
    /** Resumes playback after an Instagram-style long-press pause. */
    void resumePlayback();
}
