package com.callx.app.social;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.callx.app.models.ReelModel;
import com.callx.app.reels.R;
import com.callx.app.utils.FirebaseUtils;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

/**
 * StitchesByReelActivity — Discover all stitches made of a specific reel.
 *
 * ✅ FIX (GAP #2 — v8): New activity, mirrors DuetsByReelActivity for stitch listings.
 *
 * Features:
 *  ✅ 3-column grid of stitch thumbnails
 *  ✅ Firebase query: reels where stitchOf == originalReelId
 *  ✅ Shows stitch creator name + view count
 *  ✅ Tap opens reel player (SingleReelPlayerActivity)
 *  ✅ Empty state with label
 *  ✅ PAGINATION: loads 20 at a time, "load more" on scroll end
 *  ✅ Loading footer spinner while fetching next page
 */
public class StitchesByReelActivity extends AppCompatActivity {

    public static final String EXTRA_REEL_ID    = "stitches_reel_id";
    public static final String EXTRA_OWNER_NAME = "stitches_owner_name";

    private static final int PAGE_SIZE = 20;

    private static final int VIEW_TYPE_STITCH = 0;
    private static final int VIEW_TYPE_FOOTER = 1;

    private ImageButton  btnBack;
    private TextView     tvTitle, tvStitchCount;
    private RecyclerView rvStitches;
    private ProgressBar  progressStitches;
    private View         layoutEmpty;

    private String               originalReelId;
    private String               ownerName;
    private final List<ReelModel> stitches = new ArrayList<>();
    private StitchesAdapter      adapter;

    private String  lastLoadedKey = null;
    private boolean hasMorePages  = true;
    private boolean isLoadingPage = false;
    private int     totalLoaded   = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stitches_by_reel);

        originalReelId = getIntent().getStringExtra(EXTRA_REEL_ID);
        ownerName      = getIntent().getStringExtra(EXTRA_OWNER_NAME);
        if (ownerName == null) ownerName = "";

        btnBack        = findViewById(R.id.btn_stitches_back);
        tvTitle        = findViewById(R.id.tv_stitches_title);
        tvStitchCount  = findViewById(R.id.tv_stitch_count);
        rvStitches     = findViewById(R.id.rv_stitches);
        progressStitches = findViewById(R.id.progress_stitches);
        layoutEmpty    = findViewById(R.id.layout_stitches_empty);

        tvTitle.setText(ownerName.isEmpty() ? "Stitches" : "Stitches of @" + ownerName);

        GridLayoutManager glm = new GridLayoutManager(this, 3);
        glm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter.getItemViewType(position) == VIEW_TYPE_FOOTER ? 3 : 1;
            }
        });

        adapter = new StitchesAdapter(stitches, this::onStitchTapped);
        rvStitches.setLayoutManager(glm);
        rvStitches.setAdapter(adapter);
        btnBack.setOnClickListener(v -> finish());

        rvStitches.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                if (dy <= 0 || isLoadingPage || !hasMorePages) return;
                GridLayoutManager lm = (GridLayoutManager) rv.getLayoutManager();
                if (lm == null) return;
                int lastVisible = lm.findLastVisibleItemPosition();
                int total       = lm.getItemCount();
                if (lastVisible >= total - 6) loadNextPage();
            }
        });

        loadFirstPage();
    }

    // ── Page loading ──────────────────────────────────────────────────────────

    private void loadFirstPage() {
        if (originalReelId == null) { showEmpty(true); return; }
        progressStitches.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        isLoadingPage = true;

        buildFirstPageQuery().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                progressStitches.setVisibility(View.GONE);
                isLoadingPage = false;

                List<ReelModel> page = parseSnapshot(snap, false);
                hasMorePages = (snap.getChildrenCount() >= PAGE_SIZE);

                if (!page.isEmpty()) {
                    lastLoadedKey = page.get(page.size() - 1).reelId;
                }
                stitches.addAll(page);
                totalLoaded += page.size();
                adapter.setShowFooter(hasMorePages);
                adapter.notifyDataSetChanged();

                updateCountLabel();
                showEmpty(stitches.isEmpty());
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                progressStitches.setVisibility(View.GONE);
                isLoadingPage = false;
                showEmpty(stitches.isEmpty());
                Toast.makeText(StitchesByReelActivity.this,
                    "Failed to load stitches", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadNextPage() {
        if (!hasMorePages || isLoadingPage || lastLoadedKey == null) return;
        isLoadingPage = true;
        adapter.setShowFooter(true);

        buildNextPageQuery(lastLoadedKey).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                isLoadingPage = false;

                List<ReelModel> page = parseSnapshot(snap, true);
                hasMorePages = (snap.getChildrenCount() > PAGE_SIZE);

                if (!page.isEmpty()) {
                    lastLoadedKey = page.get(page.size() - 1).reelId;
                    int insertAt = stitches.size();
                    stitches.addAll(page);
                    totalLoaded += page.size();
                    adapter.setShowFooter(hasMorePages);
                    adapter.notifyItemRangeInserted(insertAt, page.size());
                } else {
                    hasMorePages = false;
                    adapter.setShowFooter(false);
                    adapter.notifyDataSetChanged();
                }
                updateCountLabel();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                isLoadingPage = false;
                adapter.setShowFooter(false);
                adapter.notifyDataSetChanged();
            }
        });
    }

    // ── Firebase queries ──────────────────────────────────────────────────────

    private Query buildFirstPageQuery() {
        return FirebaseUtils.db()
            .getReference("reels")
            .orderByChild("stitchOf")
            .equalTo(originalReelId)
            .limitToFirst(PAGE_SIZE);
    }

    private Query buildNextPageQuery(String cursorKey) {
        return FirebaseUtils.db()
            .getReference("reels")
            .orderByChild("stitchOf")
            .startAt(originalReelId, cursorKey)
            .endAt(originalReelId)
            .limitToFirst(PAGE_SIZE + 1);
    }

    // ── Parse helpers ─────────────────────────────────────────────────────────

    private List<ReelModel> parseSnapshot(DataSnapshot snap, boolean skipFirst) {
        List<ReelModel> page = new ArrayList<>();
        boolean first = true;
        for (DataSnapshot ds : snap.getChildren()) {
            if (skipFirst && first) { first = false; continue; }
            first = false;
            ReelModel m = ds.getValue(ReelModel.class);
            if (m != null) {
                if (m.reelId == null) m.reelId = ds.getKey();
                page.add(m);
            }
        }
        return page;
    }

    private void updateCountLabel() {
        String suffix = hasMorePages ? "+" : "";
        tvStitchCount.setText(totalLoaded + suffix + " stitch" + (totalLoaded == 1 ? "" : "es"));
    }

    private void showEmpty(boolean show) {
        layoutEmpty.setVisibility(show ? View.VISIBLE : View.GONE);
        rvStitches.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void onStitchTapped(ReelModel reel) {
        if (reel == null || reel.reelId == null) return;
        Intent i = new Intent(this, com.callx.app.player.SingleReelPlayerActivity.class);
        i.putExtra(com.callx.app.player.SingleReelPlayerActivity.EXTRA_REEL_ID, reel.reelId);
        i.putExtra(com.callx.app.player.SingleReelPlayerActivity.EXTRA_TITLE,
                   reel.ownerName != null ? "Stitch by @" + reel.ownerName : "Stitch");
        startActivity(i);
    }

    // ── Adapter ───────────────────────────────────────────────────────────────

    private static class StitchesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        interface OnStitchClick { void onClick(ReelModel reel); }

        private final List<ReelModel> items;
        private final OnStitchClick   listener;
        private boolean               showFooter = false;

        StitchesAdapter(List<ReelModel> items, OnStitchClick listener) {
            this.items    = items;
            this.listener = listener;
        }

        void setShowFooter(boolean show) { this.showFooter = show; }

        @Override public int getItemViewType(int position) {
            return (showFooter && position == items.size()) ? VIEW_TYPE_FOOTER : VIEW_TYPE_STITCH;
        }

        @Override public int getItemCount() {
            return items.size() + (showFooter ? 1 : 0);
        }

        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inf = LayoutInflater.from(parent.getContext());
            if (viewType == VIEW_TYPE_FOOTER) {
                FrameLayout fl = new FrameLayout(parent.getContext());
                ProgressBar pb = new ProgressBar(parent.getContext());
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT);
                lp.gravity = android.view.Gravity.CENTER;
                pb.setLayoutParams(lp);
                fl.addView(pb);
                fl.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 120));
                return new FooterVH(fl);
            }
            View v = inf.inflate(R.layout.item_reel_grid, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
            if (holder instanceof FooterVH) return;
            VH h = (VH) holder;
            ReelModel reel = items.get(pos);

            Glide.with(h.thumbnail.getContext())
                .load(reel.thumbUrl != null ? reel.thumbUrl : reel.thumbnailUrl)
                .centerCrop()
                .placeholder(R.drawable.bg_skeleton_rect)
                .override(480, 853)
                .into(h.thumbnail);

            h.tvCreator.setText(reel.ownerName != null ? "@" + reel.ownerName : "");
            h.tvViews.setText(formatCount(reel.viewsCount));
            // Show scissors badge instead of duet badge to distinguish stitches
            if (h.badgeDuet != null) h.badgeDuet.setVisibility(View.GONE);
            h.itemView.setOnClickListener(v -> listener.onClick(reel));
        }

        private static String formatCount(int n) {
            if (n >= 1_000_000) return String.format("%.1fM", n / 1_000_000f);
            if (n >= 1_000)     return String.format("%.1fK", n / 1_000f);
            return String.valueOf(n);
        }

        static class VH extends RecyclerView.ViewHolder {
            ImageView thumbnail;
            TextView  tvCreator, tvViews;
            View      badgeDuet;
            VH(View v) {
                super(v);
                thumbnail = v.findViewById(R.id.iv_reel_thumb);
                tvCreator = v.findViewById(R.id.tv_reel_creator);
                tvViews   = v.findViewById(R.id.tv_reel_views);
                badgeDuet = v.findViewById(R.id.badge_duet);
            }
        }

        static class FooterVH extends RecyclerView.ViewHolder {
            FooterVH(View v) { super(v); }
        }
    }
}
