package com.callx.app.social;

import android.content.Context;

import com.callx.app.utils.Constants;
import com.callx.app.utils.PushNotify;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ✅ MULTI-COLLABORATOR SUPPORT — upload-time invites.
 *
 * Mirrors the Firebase-writing logic in {@link CollabPostInviteActivity#sendInvites()},
 * but for the case where collaborators were picked on the upload/post-details screen
 * (via {@link CollabPostInviteActivity} in staging mode) BEFORE the reel existed. Call
 * this once the reel has just been saved and its reelId is known, right after the
 * "reel posted" success callback in ReelUploadActivity.
 */
public final class CollabInviteHelper {

    private CollabInviteHelper() {}

    public interface Callback {
        void onDone();
    }

    /** One staged collaborator picked on the upload screen. */
    public static class StagedCollaborator {
        public final String uid, displayName, handle, avatarUrl;
        public StagedCollaborator(String uid, String displayName, String handle, String avatarUrl) {
            this.uid = uid;
            this.displayName = displayName != null ? displayName : "";
            this.handle = handle != null ? handle : "";
            this.avatarUrl = avatarUrl != null ? avatarUrl : "";
        }
    }

    /** Builds the staged list from the parallel ArrayLists returned by CollabPostInviteActivity. */
    public static List<StagedCollaborator> fromParallelLists(
            List<String> uids, List<String> names, List<String> handles, List<String> avatars) {
        List<StagedCollaborator> out = new ArrayList<>();
        if (uids == null) return out;
        for (int i = 0; i < uids.size(); i++) {
            out.add(new StagedCollaborator(
                uids.get(i),
                names   != null && i < names.size()   ? names.get(i)   : "",
                handles != null && i < handles.size() ? handles.get(i) : "",
                avatars != null && i < avatars.size() ? avatars.get(i) : ""
            ));
        }
        return out;
    }

    /** Sends one invite per staged collaborator and seeds the new reel's collabMap. */
    public static void sendInvitesForNewReel(Context ctx, String reelId, String thumbUrl,
                                              List<StagedCollaborator> collaborators,
                                              String myUid, String myName, Callback callback) {
        if (collaborators == null || collaborators.isEmpty() || reelId == null || reelId.isEmpty()) {
            if (callback != null) callback.onDone();
            return;
        }

        DatabaseReference root = FirebaseDatabase.getInstance(Constants.DB_URL).getReference();
        Map<String, Object> updates = new HashMap<>();
        long now = System.currentTimeMillis();
        List<String> inviteIds = new ArrayList<>();

        for (StagedCollaborator target : collaborators) {
            String inviteId = root.child("collabPostInvites").push().getKey();
            if (inviteId == null) continue;
            inviteIds.add(inviteId);

            Map<String, Object> invite = new HashMap<>();
            invite.put("inviteId",        inviteId);
            invite.put("reelId",          reelId);
            invite.put("initiatorUid",    myUid);
            invite.put("initiatorName",   myName != null ? myName : "");
            invite.put("collaboratorUid", target.uid);
            invite.put("thumbUrl",        thumbUrl != null ? thumbUrl : "");
            invite.put("status",          "pending");
            invite.put("createdAt",       now);

            updates.put("collabPostInvites/" + target.uid + "/" + inviteId, invite);
            updates.put("collabPostInvitesSent/" + myUid + "/" + inviteId, invite);

            Map<String, Object> collabEntry = new HashMap<>();
            collabEntry.put("uid",         target.uid);
            collabEntry.put("displayName", target.displayName);
            collabEntry.put("handle",      target.handle);
            collabEntry.put("avatarUrl",   target.avatarUrl);
            collabEntry.put("status",      "pending");
            collabEntry.put("inviteId",    inviteId);
            collabEntry.put("invitedAt",   now);
            updates.put("reels/" + reelId + "/collabMap/" + target.uid, collabEntry);
        }

        // Reel-level flags + legacy single-collaborator mirror (first invitee),
        // same convention as CollabPostInviteActivity.sendInvites().
        StagedCollaborator first = collaborators.get(0);
        updates.put("reels/" + reelId + "/isCollabPending",   true);
        updates.put("reels/" + reelId + "/isCollabPost",      false);
        updates.put("reels/" + reelId + "/collabInviteId",    inviteIds.isEmpty() ? "" : inviteIds.get(0));
        updates.put("reels/" + reelId + "/collabUid",         first.uid);
        updates.put("reels/" + reelId + "/collabDisplayName", first.displayName);
        updates.put("reels/" + reelId + "/collabAvatarUrl",   first.avatarUrl);

        root.updateChildren(updates, (error, ref) -> {
            if (error != null) {
                // 🐞 BUG FIX: this used to fail 100% silently — reel was already
                // posted (separate write) so the user saw "Reel posted!" with zero
                // sign that the collab invite write itself failed. No log, no
                // toast, nothing — meaning a transient DB error / rules rejection
                // would drop the invite with no trace, exactly matching the
                // "B never got the invite" report. Now it's logged + surfaced.
                android.util.Log.e("CollabInviteHelper",
                    "sendInvitesForNewReel: Firebase write FAILED for reelId=" + reelId
                        + " — " + error.getMessage());
                if (ctx != null) {
                    android.widget.Toast.makeText(ctx,
                        "Couldn't send collab invite: " + error.getMessage(),
                        android.widget.Toast.LENGTH_LONG).show();
                }
            } else {
                for (int i = 0; i < collaborators.size() && i < inviteIds.size(); i++) {
                    StagedCollaborator target = collaborators.get(i);
                    // 🐞 BUG FIX (real root cause): CollabRepostNotificationHelper is a
                    // LOCAL notification for the *Collab Repost* feature, not "Add
                    // Collaborators". NotificationManager.notify() always fires on the
                    // CALLING device — i.e. A's own phone, since this code runs on A's
                    // device right after A posts. So A saw a notification meant for B,
                    // titled "Collab Repost Invite", deep-linking to the wrong screen
                    // (Collab Repost Inbox — empty, since it's a different feature).
                    // B never got anything from this call regardless — it can only ever
                    // show on the sender's own device. Removed entirely; the real
                    // cross-device delivery is the FCM push below.
                    try {
                        // ✅ Cross-device FCM push via the server, so the collaborator
                        // gets notified even when their app is closed.
                        // 🐞 BUG FIX: log before/after so a failed push (e.g. B has no
                        // fcmToken saved → server returns 404 "no token") is visible
                        // in logcat under tag CollabInviteHelper/PushNotify instead of
                        // vanishing silently.
                        android.util.Log.d("CollabInviteHelper",
                            "Sending collab_request push -> toUid=" + target.uid
                                + " reelId=" + reelId + " inviteId=" + inviteIds.get(i));
                        PushNotify.notifyCollabRequest(
                            target.uid, myUid, myName != null ? myName : "Someone", "",
                            reelId, thumbUrl != null ? thumbUrl : "", inviteIds.get(i));
                    } catch (Exception e) {
                        android.util.Log.e("CollabInviteHelper",
                            "notifyCollabRequest threw for uid=" + target.uid + ": " + e.getMessage());
                    }
                }
            }
            if (callback != null) callback.onDone();
        });
    }
}
