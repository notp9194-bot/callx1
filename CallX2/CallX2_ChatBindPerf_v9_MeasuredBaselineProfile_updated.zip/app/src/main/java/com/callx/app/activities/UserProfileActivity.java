package com.callx.app.activities;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentManager;
import androidx.appcompat.app.AppCompatActivity;


import com.callx.app.R;
import com.callx.app.databinding.ActivityUserProfileBinding;
import com.callx.app.utils.FirebaseUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;
import com.callx.app.db.AppDatabase;
import com.callx.app.db.entity.UserEntity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.callx.app.profile.ReelUserProfileSheet;
import com.callx.app.profile.UserReelsActivity;
import com.callx.app.conversation.ChatActivity;
import com.callx.app.cache.AvatarVersionSyncManager;
import com.callx.app.cache.ProfileAvatarBinder;

/**
 * UserProfileActivity — Chat header avatar click ya 3-dot "View Profile" se open hoti hai.
 *
 * Intent extras:
 *   "uid"       — partner ka UID (required)
 *   "name"      — partner ka naam (fallback, Firebase se refresh hoga)
 *   "photo"     — partner ka full photo URL (fallback)
 *   "chatId"    — back-to-chat ke liye (optional)
 */
public class UserProfileActivity extends AppCompatActivity {

    private ActivityUserProfileBinding binding;

    // Partner data
    private String partnerUid;
    // Bumped by AvatarVersionSyncManager whenever partnerUid's avatarVersion
    // changes — fed into AvatarUrlBuilder (via ProfileAvatarBinder) so every
    // bind below shares one cache key with every OTHER screen showing this
    // same user (reel player, chat list, comments...), and so a genuinely
    // new avatar is never served a stale CDN-edge 304 by mistake. See
    // UserEntity#avatarVersion for the full rationale.
    private long partnerAvatarVersion = 0;
    // FIX (isVisible gate, screen-scoped — see ProfileAvatarBinder): true
    // only between onResume()/onPause(). partnerAvatarVersionListener's
    // watch() stays alive across pause/resume (unwatched only in
    // onDestroy()), so a fresh avatarVersion push can land while this
    // screen is sitting paused underneath something else — bindGated()
    // uses this flag to skip the network in that case.
    private boolean screenVisible = false;

    private String partnerName;
    private String partnerPhoto;
    private String chatId;

    // Delta-sync (see AvatarVersionSyncManager): live avatarVersion watch for
    // the profile being VIEWED — so if the partner uploads a new avatar
    // while this screen is open, ivAvatarLarge refreshes without the viewer
    // needing to back out and reopen the screen.
    private final AvatarVersionSyncManager.Listener partnerAvatarVersionListener = (uid, newVersion) -> {
        if (isFinishing() || isDestroyed() || !uid.equals(partnerUid)) return;
        partnerAvatarVersion = newVersion;
        String url = (partnerPhoto != null && !partnerPhoto.isEmpty()) ? partnerPhoto : null;
        if (url == null) return;
        // PERF (deep avatar pipeline parity — see ProfileAvatarBinder#bindGated):
        // this listener can fire while the screen is paused in the back
        // stack — gate the real network fetch behind screenVisible so a
        // push landing while backgrounded only warms the disk tier.
        ProfileAvatarBinder.bindGated(UserProfileActivity.this, binding.ivAvatarLarge,
            url, partnerAvatarVersion, ProfileAvatarBinder.LARGE_TIER, R.drawable.ic_person, screenVisible);
    };

    // Mute state (sync from ChatActivity isMuted logic)
    private boolean isMuted = false;
    private boolean isBlocked = false;

    // ── Avatar peek animation fields ──────────────────────────────────────
    private CircleImageView ivAnimReel, ivAnimX, ivAnimYoutube;
    private final Handler   animHandler = new Handler(Looper.getMainLooper());
    private Runnable        animRunnable;
    private boolean         animRunning = false;

    // Offline-first: Room DB se profile load karne ke liye
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // ── Intent extras ──────────────────────────────────────────────
        partnerUid   = getIntent().getStringExtra("uid");
        partnerName  = getIntent().getStringExtra("name");
        partnerPhoto = getIntent().getStringExtra("photo");
        chatId       = getIntent().getStringExtra("chatId");

        if (partnerUid == null || partnerUid.isEmpty()) {
            Toast.makeText(this, "Profile load nahi ho saka", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // ── Toolbar setup ───────────────────────────────────────────────
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        // Collapsing toolbar title = partner name
        if (partnerName != null && !partnerName.isEmpty()) {
            binding.collapsingToolbar.setTitle(partnerName);
        }

        // ── Avatar: fast load from intent photo ────────────────────────
        // PERF (deep avatar pipeline parity — see ProfileAvatarBinder):
        // shared-tier URL + L2/L3 fast-path + blur-up thumbnail, instead of
        // a flat un-tiered ".override(720,720)".
        if (partnerPhoto != null && !partnerPhoto.isEmpty()) {
            ProfileAvatarBinder.bind(this, binding.ivAvatarLarge,
                partnerPhoto, partnerAvatarVersion, ProfileAvatarBinder.LARGE_TIER, R.drawable.ic_person);
        }

        // Avatar click → fullscreen zoom
        binding.ivAvatarLarge.setOnClickListener(v -> showAvatarZoom(v, partnerPhoto));

        // ── Action buttons ─────────────────────────────────────────────
        binding.btnActionReel.setOnClickListener(v -> openUserReels());
        binding.btnActionX.setOnClickListener(v -> openUserX());
        binding.btnActionProfileSheet.setOnClickListener(v -> openSocialProfileSheet());
        binding.btnActionYoutube.setOnClickListener(v -> openUserYoutube());
        binding.btnActionVoice.setOnClickListener(v -> startCall(false));
        binding.btnActionVideo.setOnClickListener(v -> startCall(true));

        // ── Avatar anim views ──────────────────────────────────────────
        ivAnimReel    = binding.ivAnimReel;
        ivAnimX       = binding.ivAnimX;
        ivAnimYoutube = binding.ivAnimYoutube;

        // ── Options ────────────────────────────────────────────────────
        binding.btnMute.setOnClickListener(v -> toggleMute());
        binding.btnBlock.setOnClickListener(v -> confirmBlock());
        binding.btnReport.setOnClickListener(v -> confirmReport());

        // ── Offline-first: Room se turant load karo (no network needed) ──
        loadFromRoom();

        // ── Load fresh data from Firebase ──────────────────────────────
        loadProfile();
        loadMuteState();
        loadBlockState();
        loadAvatarAndStartAnimation();
        if (partnerUid != null && !partnerUid.isEmpty()) {
            AvatarVersionSyncManager.getInstance(this).watch(partnerUid, partnerAvatarVersionListener);
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // OFFLINE-FIRST: Room se instant load
    // ──────────────────────────────────────────────────────────────────────

    /**
     * Room DB se cached profile instantly dikhao — network ka wait nahi.
     * Firebase loadProfile() baad mein fresh data se override kar dega.
     * Agar Room mein kuch nahi hai toh kuch nahi hoga (silent, no crash).
     */
    private void loadFromRoom() {
        if (partnerUid == null || partnerUid.isEmpty()) return;
        dbExecutor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            UserEntity cached = db.userDao().getUser(partnerUid);
            if (cached == null) return; // Pehli baar hai — Room mein kuch nahi

            // UI thread pe update karo
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;

                // Step 3 (display swap): tv_name (top, bold) is the
                // primary line — show the @username handle there, same as
                // FollowConnectionsActivity/UserReelsActivity's headers.
                // tv_username (bottom, secondary) now shows the display
                // name instead, only when it differs from the handle.
                boolean cachedHasUsername = cached.username != null && !cached.username.isEmpty();
                String cachedPrimary = cachedHasUsername ? "@" + cached.username
                        : (cached.name != null ? cached.name : partnerUid);
                binding.tvName.setText(cachedPrimary);
                binding.collapsingToolbar.setTitle(cachedPrimary);
                if (cached.name != null && !cached.name.isEmpty()) {
                    partnerName = cached.name;
                }
                boolean cachedNameDiffers = cached.name != null && !cached.name.isEmpty()
                        && (!cachedHasUsername || !cached.name.equalsIgnoreCase(cached.username));
                if (cachedNameDiffers) {
                    binding.tvUsername.setText(cached.name);
                    binding.tvUsername.setVisibility(View.VISIBLE);
                } else if (cachedHasUsername) {
                    binding.tvUsername.setVisibility(View.GONE);
                }

                // About
                if (cached.about != null && !cached.about.isEmpty()) {
                    binding.tvAbout.setText(cached.about);
                    binding.cardAbout.setVisibility(View.VISIBLE);
                }

                // Avatar — thumb pehle (fast), phir full photo
                String avatarUrl = null;
                if (cached.thumbUrl != null && !cached.thumbUrl.isEmpty()) {
                    avatarUrl = cached.thumbUrl;
                } else if (cached.photoUrl != null && !cached.photoUrl.isEmpty()) {
                    avatarUrl = cached.photoUrl;
                }
                if (avatarUrl != null) {
                    partnerPhoto = avatarUrl;
                    partnerAvatarVersion = cached.avatarVersion;
                    // PERF (deep avatar pipeline parity — see ProfileAvatarBinder)
                    ProfileAvatarBinder.bind(UserProfileActivity.this, binding.ivAvatarLarge,
                        avatarUrl, partnerAvatarVersion, ProfileAvatarBinder.LARGE_TIER, R.drawable.ic_person);
                }
            });
        });
    }

    // ──────────────────────────────────────────────────────────────────────
    // FIREBASE se aaya data → Room mein save karo (next time offline kaam aaye)
    // ──────────────────────────────────────────────────────────────────────

    private void saveToRoom(String name, String about, String username,
                            String photoUrl, String thumbUrl) {
        dbExecutor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            UserEntity existing = db.userDao().getUser(partnerUid);
            UserEntity entity = existing != null ? existing : new UserEntity();
            entity.uid      = partnerUid;
            if (name    != null && !name.isEmpty())    entity.name    = name;
            if (about   != null && !about.isEmpty())   entity.about   = about;
            if (username != null && !username.isEmpty()) entity.username = username;
            if (photoUrl != null && !photoUrl.isEmpty()) entity.photoUrl = photoUrl;
            if (thumbUrl != null && !thumbUrl.isEmpty()) entity.thumbUrl = thumbUrl;
            entity.cachedAt = System.currentTimeMillis();
            db.userDao().insertUser(entity);
        });
    }

    // ──────────────────────────────────────────────────────────────────────
    // MUTE + BLOCK STATE LOAD
    // ──────────────────────────────────────────────────────────────────────

    private void loadMuteState() {
        String myUid = FirebaseUtils.getCurrentUid();
        if (myUid == null || myUid.isEmpty()) return;
        FirebaseUtils.db().getReference("muted")
            .child(myUid).child(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot s) {
                    isMuted = Boolean.TRUE.equals(s.getValue(Boolean.class));
                    updateMuteLabel();
                }
                @Override public void onCancelled(DatabaseError e) {}
            });
    }

    private void loadBlockState() {
        String myUid = FirebaseUtils.getCurrentUid();
        if (myUid == null || myUid.isEmpty()) return;
        FirebaseUtils.getBlocksRef(myUid).child(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot s) {
                    isBlocked = Boolean.TRUE.equals(s.getValue(Boolean.class));
                    binding.tvBlockLabel.setText(isBlocked ? "🚫  Unblock" : "🚫  Block");
                }
                @Override public void onCancelled(DatabaseError e) {}
            });
    }

    // ──────────────────────────────────────────────────────────────────────
    // FIREBASE LOAD
    // ──────────────────────────────────────────────────────────────────────

    private void loadProfile() {
        FirebaseUtils.getUserRef(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot s) {
                    String name      = orEmpty(s.child("name").getValue(String.class));
                    String bio       = orEmpty(s.child("bio").getValue(String.class));
                    String about     = orEmpty(s.child("about").getValue(String.class));
                    String phone     = orEmpty(s.child("phone").getValue(String.class));
                    String whatsapp  = orEmpty(s.child("whatsapp").getValue(String.class));
                    String instagram = orEmpty(s.child("instagram").getValue(String.class));
                    String otherLink = orEmpty(s.child("otherLink").getValue(String.class));
                    String username  = orEmpty(s.child("username").getValue(String.class));
                    String photo     = orEmpty(s.child("photoUrl").getValue(String.class));
                    String thumb     = orEmpty(s.child("thumbUrl").getValue(String.class));
                    Long   avatarVer = s.child("avatarVersion").getValue(Long.class);

                    // Update stored photo
                    if (!photo.isEmpty()) partnerPhoto = photo;
                    if (!name.isEmpty())  partnerName  = name;
                    if (avatarVer != null) partnerAvatarVersion = avatarVer;

                    // Step 3 (display swap): tv_name (top, bold) is the
                    // primary @username handle; tv_username (secondary)
                    // now shows the display name, only when it differs
                    // from the handle. Same convention as
                    // FollowConnectionsActivity/UserReelsActivity headers.
                    boolean hasUsername = !username.isEmpty();
                    String resolvedName = name.isEmpty() ? orEmpty(partnerName) : name;
                    String primary = hasUsername ? "@" + username : (!resolvedName.isEmpty() ? resolvedName : partnerUid);
                    binding.tvName.setText(primary);
                    binding.collapsingToolbar.setTitle(primary);

                    // Username / secondary name line
                    boolean nameDiffers = !resolvedName.isEmpty()
                            && (!hasUsername || !resolvedName.equalsIgnoreCase(username));
                    if (nameDiffers) {
                        binding.tvUsername.setText(resolvedName);
                        binding.tvUsername.setVisibility(View.VISIBLE);
                    } else {
                        binding.tvUsername.setVisibility(View.GONE);
                    }

                    // Bio
                    if (!bio.isEmpty()) {
                        binding.tvBio.setText(bio);
                        binding.tvBio.setVisibility(View.VISIBLE);
                    }

                    // About
                    if (!about.isEmpty()) {
                        binding.tvAbout.setText(about);
                        binding.cardAbout.setVisibility(View.VISIBLE);
                    }

                    // Phone
                    if (!phone.isEmpty()) {
                        binding.tvPhone.setText(phone);
                        binding.cardPhone.setVisibility(View.VISIBLE);
                    }

                    // Social links
                    boolean hasSocial = false;
                    if (!whatsapp.isEmpty()) {
                        binding.tvWhatsapp.setText(whatsapp);
                        binding.rowWhatsapp.setVisibility(View.VISIBLE);
                        binding.rowWhatsapp.setOnClickListener(v -> openWhatsApp(whatsapp));
                        hasSocial = true;
                    }
                    if (!instagram.isEmpty()) {
                        binding.tvInstagram.setText("@" + instagram.replace("@", ""));
                        binding.rowInstagram.setVisibility(View.VISIBLE);
                        binding.rowInstagram.setOnClickListener(v -> openInstagram(instagram));
                        hasSocial = true;
                    }
                    if (!otherLink.isEmpty()) {
                        binding.tvOtherLink.setText(otherLink);
                        binding.rowOtherLink.setVisibility(View.VISIBLE);
                        binding.rowOtherLink.setOnClickListener(v -> openUrl(otherLink));
                        hasSocial = true;
                    }
                    if (hasSocial) binding.cardSocial.setVisibility(View.VISIBLE);

                    // Avatar — prefer full photo, fallback thumb
                    String displayUrl = !photo.isEmpty() ? photo : (!thumb.isEmpty() ? thumb : "");
                    if (!displayUrl.isEmpty()) {
                        // PERF (deep avatar pipeline parity — see ProfileAvatarBinder)
                        ProfileAvatarBinder.bind(UserProfileActivity.this, binding.ivAvatarLarge,
                            displayUrl, partnerAvatarVersion, ProfileAvatarBinder.LARGE_TIER, R.drawable.ic_person);
                    }

                    // Mute state from Firebase (same path as ChatActivity: /muted/{myUid}/{partnerUid})
                    // We load it separately after profile load

                    // Room mein save karo — agli baar offline mein kaam aayega
                    saveToRoom(name, about, username, photo, thumb);
                }

                @Override
                public void onCancelled(DatabaseError e) {}
            });
    }

    // ──────────────────────────────────────────────────────────────────────
    // ACTIONS
    // ──────────────────────────────────────────────────────────────────────

    /** Open 1-1 chat with this user */
    private void openChat() {
        try {
            // ChatActivity is in feature-chat module
            Intent i = new Intent().setClassName(this, "com.callx.app.conversation.ChatActivity");
            i.putExtra("partnerUid",   partnerUid);
            i.putExtra("partnerName",  partnerName  != null ? partnerName  : "");
            i.putExtra("partnerPhoto", partnerPhoto != null ? partnerPhoto : "");
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Chat open nahi ho saka", Toast.LENGTH_SHORT).show();
        }
    }

    /** Start voice or video call */
    private void startCall(boolean isVideo) {
        try {
            Intent i = new Intent().setClassName(this, "com.callx.app.call.CallActivity");
            i.putExtra("partnerUid",   partnerUid);
            i.putExtra("partnerName",  partnerName  != null ? partnerName  : "");
            i.putExtra("partnerPhoto", partnerPhoto != null ? partnerPhoto : "");
            i.putExtra("isCaller",     true);
            i.putExtra("video",        isVideo);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this,
                (isVideo ? "Video" : "Voice") + " call shuru nahi ho saka",
                Toast.LENGTH_SHORT).show();
        }
    }

    /** Return to chat in search mode */
    private void openChatSearch() {
        try {
            Intent i = new Intent().setClassName(this, "com.callx.app.conversation.ChatActivity");
            i.putExtra("partnerUid",   partnerUid);
            i.putExtra("partnerName",  partnerName  != null ? partnerName  : "");
            i.putExtra("partnerPhoto", partnerPhoto != null ? partnerPhoto : "");
            i.putExtra("openSearch",   true);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Search open nahi ho saka", Toast.LENGTH_SHORT).show();
        }
    }

    /** Toggle mute for this conversation — same path as ChatActivity */
    private void toggleMute() {
        String myUid = FirebaseUtils.getCurrentUid();
        if (myUid == null || myUid.isEmpty()) return;
        isMuted = !isMuted;
        updateMuteLabel();
        FirebaseUtils.db().getReference("muted")
            .child(myUid).child(partnerUid)
            .setValue(isMuted ? true : null);
        Toast.makeText(this,
            isMuted ? "Notifications mute ho gayi" : "Notifications unmute ho gayi",
            Toast.LENGTH_SHORT).show();
    }

    private void updateMuteLabel() {
        binding.tvMuteLabel.setText(isMuted ? "🔔  Unmute Notifications" : "🔔  Mute Notifications");
    }

    /** Block confirmation dialog */
    private void confirmBlock() {
        String msg = (partnerName != null && !partnerName.isEmpty())
            ? partnerName + " ko block karna chahte ho?"
            : "Is user ko block karna chahte ho?";
        com.callx.app.utils.AlertDialogStyler.showReusableConfirm(this,
                "user_profile_block", com.callx.app.utils.AlertDialogStyler.DialogSize.DEFAULT,
                isBlocked ? "Unblock" : "Block", msg,
                isBlocked ? "Unblock" : "Block", this::blockUser,
                null, null,
                "Cancel");
    }

    private void blockUser() {
        isBlocked = !isBlocked;
        String myUid = FirebaseUtils.getCurrentUid();
        FirebaseUtils.getBlocksRef(myUid).child(partnerUid)
            .setValue(isBlocked ? true : null);
        if (isBlocked) {
            binding.tvBlockLabel.setText("🚫  Unblock");
            Toast.makeText(this, "User block ho gaya", Toast.LENGTH_SHORT).show();
        } else {
            binding.tvBlockLabel.setText("🚫  Block");
            Toast.makeText(this, "User unblock ho gaya", Toast.LENGTH_SHORT).show();
        }
    }

    /** Report user dialog */
    private void confirmReport() {
        String[] reasons = {
            "Spam ya unwanted messages",
            "Inappropriate content",
            "Harassment ya bullying",
            "Fake account",
            "Kuch aur"
        };
        new AlertDialog.Builder(this)
            .setTitle("Report karo")
            .setItems(reasons, (d, which) -> {
                Toast.makeText(this, "Report submit ho gayi", Toast.LENGTH_SHORT).show();
                // Log the report to Firebase under /reports/{reportedUid}/{reportId}
                String myUid = FirebaseUtils.getCurrentUid();
                if (myUid != null && !myUid.isEmpty() && partnerUid != null) {
                    String reportId = com.google.firebase.database.FirebaseDatabase.getInstance()
                        .getReference("reports").child(partnerUid).push().getKey();
                    if (reportId != null) {
                        java.util.Map<String, Object> report = new java.util.HashMap<>();
                        report.put("reportedUid",  partnerUid);
                        report.put("reporterUid",  myUid);
                        report.put("reason",       reasons[which]);
                        report.put("reasonIndex",  which);
                        report.put("timestamp",    System.currentTimeMillis());
                        report.put("type",         "user");
                        com.google.firebase.database.FirebaseDatabase.getInstance()
                            .getReference("reports")
                            .child(partnerUid)
                            .child(reportId)
                            .setValue(report);
                    }
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ──────────────────────────────────────────────────────────────────────
    // SOCIAL LINK OPENERS
    // ──────────────────────────────────────────────────────────────────────

    private void openWhatsApp(String number) {
        String clean = number.replaceAll("[^0-9+]", "");
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/" + clean.replace("+", "")));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp nahi mila", Toast.LENGTH_SHORT).show();
        }
    }

    private void openInstagram(String handle) {
        String clean = handle.replace("@", "");
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://instagram.com/" + clean));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Instagram open nahi ho saka", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUrl(String url) {
        try {
            if (!url.startsWith("http")) url = "https://" + url;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Link open nahi ho saka", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUserReels() {
        // UserReelsActivity — exact same as Reels profile header mein click
        try {
            Class<?> cls = Class.forName("com.callx.app.profile.UserReelsActivity");
            Intent i = new Intent(this, cls);
            i.putExtra("uid",   partnerUid);
            i.putExtra("name",  orEmpty(partnerName));
            i.putExtra("photo", orEmpty(partnerPhoto));
            startActivity(i);
        } catch (ClassNotFoundException e) {
            Toast.makeText(this, "Reel profile not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUserX() {
        // XProfileSheet.showProfile() — same as Reels X button
        if (partnerUid == null || partnerUid.isEmpty()) return;
        try {
            Class<?> cls = Class.forName("com.callx.app.profile.XProfileSheet");
            java.lang.reflect.Method method = cls.getMethod(
                    "showProfile",
                    androidx.fragment.app.FragmentManager.class,
                    String.class);
            method.invoke(null, getSupportFragmentManager(), partnerUid);
        } catch (Exception e) {
            Toast.makeText(this, "X profile not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUserYoutube() {
        // YouTubeChannelActivity — same as Reels YouTube button
        if (partnerUid == null || partnerUid.isEmpty()) return;
        try {
            Class<?> cls = Class.forName("com.callx.app.channel.YouTubeChannelActivity");
            Intent i = new Intent(this, cls);
            i.putExtra("uid",  partnerUid);
            i.putExtra("name", orEmpty(partnerName));
            startActivity(i);
        } catch (ClassNotFoundException e) {
            Toast.makeText(this, "YouTube channel not available", Toast.LENGTH_SHORT).show();
        }
    }

    // ── SOCIAL PROFILE SHEET ─────────────────────────────────────────────
    // Reels following/followers/mutual me avatar click se jo sheet aati hai,
    // exactly wahi — ReelUserProfileSheet.show() — reflection se call karo
    // ─────────────────────────────────────────────────────────────────────
    private void openSocialProfileSheet() {
        if (partnerUid == null || partnerUid.isEmpty()) return;
        try {
            Class<?> sheetClass = Class.forName(
                "com.callx.app.profile.ReelUserProfileSheet");
            java.lang.reflect.Method showMethod = sheetClass.getMethod(
                "show",
                android.app.Activity.class,
                String.class, String.class, String.class);
            showMethod.invoke(null, this,
                partnerUid,
                partnerName  != null ? partnerName  : "",
                partnerPhoto != null ? partnerPhoto : "");
        } catch (ClassNotFoundException e) {
            android.widget.Toast.makeText(this, "Social profile not available",
                android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Could not open profile card",
                android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // AVATAR FULLSCREEN ZOOM
    // ──────────────────────────────────────────────────────────────────────

    private void showAvatarZoom(View sourceView, String photoUrl) {
        com.callx.app.utils.DialogFullscreenHelper.showAvatarZoom(
            this, sourceView, photoUrl, R.drawable.ic_person, R.drawable.ic_close);
    }

    // ──────────────────────────────────────────────────────────────────────
    // HELPERS
    // ──────────────────────────────────────────────────────────────────────

    private String orEmpty(String s) {
        return s == null ? "" : s;
    }

    // ──────────────────────────────────────────────────────────────────────
    // AVATAR PEEK ANIMATION — same as UserReelsActivity
    // ──────────────────────────────────────────────────────────────────────

    /**
     * 5 button avatars load karta hai:
     *   Reel    → reels/users/{uid}
     *   X       → x/users/{uid}
     *   YouTube → youtube/channels/{uid}
     *   Call    → users/{uid}  (main CallX profile)
     *   Video   → users/{uid}  (same as Call)
     */
    private void loadAvatarAndStartAnimation() {
        if (partnerUid == null || partnerUid.isEmpty()) return;

        final String DB = "https://sathix-97a76-default-rtdb.asia-southeast1.firebasedatabase.app";

        // 1) Reel avatar — reels/users/{uid}
        com.google.firebase.database.FirebaseDatabase.getInstance(DB)
            .getReference("reels/users").child(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snap) {
                    String thumb = snap.child("thumbUrl").getValue(String.class);
                    String photo = snap.child("photoUrl").getValue(String.class);
                    String url = (thumb != null && !thumb.isEmpty()) ? thumb
                               : (photo != null && !photo.isEmpty()) ? photo : null;
                    if (ivAnimReel == null) { startAvatarPeekLoop(); return; }
                    if (url != null) {
                        // PERF (deep avatar pipeline parity — see ProfileAvatarBinder):
                        // shared-tier URL + L2/L3 reuse + blur-up thumbnail chain,
                        // instead of a flat un-tiered ".override(240,240)". No
                        // avatarVersion known for this denormalized reels/users
                        // node, so 0 (unversioned — same as before this existed).
                        ProfileAvatarBinder.bind(UserProfileActivity.this, ivAnimReel,
                            url, 0, ProfileAvatarBinder.PEEK_TIER, R.drawable.ic_person);
                    }
                    startAvatarPeekLoop();
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {
                    startAvatarPeekLoop();
                }
            });

        // 2) X avatar — x/users/{uid}
        com.google.firebase.database.FirebaseDatabase.getInstance(DB)
            .getReference("x/users").child(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snap) {
                    String thumb = snap.child("thumbUrl").getValue(String.class);
                    String photo = snap.child("photoUrl").getValue(String.class);
                    String url = (thumb != null && !thumb.isEmpty()) ? thumb
                               : (photo != null && !photo.isEmpty()) ? photo : null;
                    if (ivAnimX == null || url == null) return;
                    // PERF (deep avatar pipeline parity — see ProfileAvatarBinder)
                    ProfileAvatarBinder.bind(UserProfileActivity.this, ivAnimX,
                        url, 0, ProfileAvatarBinder.PEEK_TIER, R.drawable.ic_person);
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            });

        // 3) YouTube avatar — youtube/channels/{uid}
        com.google.firebase.database.FirebaseDatabase.getInstance(DB)
            .getReference("youtube/channels").child(partnerUid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snap) {
                    String thumb = snap.child("thumbUrl").getValue(String.class);
                    String photo = snap.child("photoUrl").getValue(String.class);
                    String url = (thumb != null && !thumb.isEmpty()) ? thumb
                               : (photo != null && !photo.isEmpty()) ? photo : null;
                    if (ivAnimYoutube == null || url == null) return;
                    // PERF (deep avatar pipeline parity — see ProfileAvatarBinder)
                    ProfileAvatarBinder.bind(UserProfileActivity.this, ivAnimYoutube,
                        url, 0, ProfileAvatarBinder.PEEK_TIER, R.drawable.ic_person);
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {}
            });

    }

    /**
     * Loop: Reel → X → YouTube → Call → Video → Reel → ...
     * Each: peek out (450ms) → hold 3s → peek in (400ms) → wait 3s → next
     */
    private void startAvatarPeekLoop() {
        if (animRunning) return;
        animRunning = true;

        CircleImageView[] views = {ivAnimReel, ivAnimX, ivAnimYoutube};

        for (CircleImageView iv : views) {
            if (iv == null) continue;
            iv.setVisibility(View.INVISIBLE);
            iv.setScaleX(0f);
            iv.setScaleY(0f);
            iv.setAlpha(0f);
        }

        animRunnable = new Runnable() {
            int idx = 0;

            @Override public void run() {
                if (!animRunning || isFinishing() || isDestroyed()) return;

                CircleImageView iv = views[idx % views.length];
                idx++;

                if (iv == null) {
                    animHandler.postDelayed(this, 500);
                    return;
                }

                iv.setScaleX(0f);
                iv.setScaleY(0f);
                iv.setAlpha(0f);
                iv.setVisibility(View.VISIBLE);

                // Zoom IN: 0 → 1.05 overshoot → settle 1.0 (subtle peek, no over-zoom)
                ObjectAnimator scaleXIn = ObjectAnimator.ofFloat(iv, "scaleX", 0f, 1.05f, 1.0f);
                ObjectAnimator scaleYIn = ObjectAnimator.ofFloat(iv, "scaleY", 0f, 1.05f, 1.0f);
                ObjectAnimator alphaIn  = ObjectAnimator.ofFloat(iv, "alpha",  0f, 1f);
                scaleXIn.setDuration(450);
                scaleYIn.setDuration(450);
                alphaIn.setDuration(250);
                scaleXIn.setInterpolator(new android.view.animation.DecelerateInterpolator(2f));
                scaleYIn.setInterpolator(new android.view.animation.DecelerateInterpolator(2f));
                AnimatorSet zoomIn = new AnimatorSet();
                zoomIn.playTogether(scaleXIn, scaleYIn, alphaIn);

                // Zoom OUT: 1.0 → 0 (after 3s hold)
                ObjectAnimator scaleXOut = ObjectAnimator.ofFloat(iv, "scaleX", 1.0f, 0f);
                ObjectAnimator scaleYOut = ObjectAnimator.ofFloat(iv, "scaleY", 1.0f, 0f);
                ObjectAnimator alphaOut  = ObjectAnimator.ofFloat(iv, "alpha",  1f, 0f);
                scaleXOut.setDuration(400);
                scaleYOut.setDuration(400);
                alphaOut.setDuration(400);
                scaleXOut.setInterpolator(new android.view.animation.AccelerateInterpolator(1.5f));
                scaleYOut.setInterpolator(new android.view.animation.AccelerateInterpolator(1.5f));
                AnimatorSet zoomOut = new AnimatorSet();
                zoomOut.playTogether(scaleXOut, scaleYOut, alphaOut);
                zoomOut.setStartDelay(3000);

                AnimatorSet full = new AnimatorSet();
                full.playSequentially(zoomIn, zoomOut);
                full.addListener(new AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(Animator animation) {
                        iv.setVisibility(View.INVISIBLE);
                        iv.setScaleX(0f);
                        iv.setScaleY(0f);
                        iv.setAlpha(0f);
                        if (animRunning && !isFinishing() && !isDestroyed())
                            animHandler.postDelayed(animRunnable, 3000);
                    }
                });
                full.start();
            }
        };

        animHandler.postDelayed(animRunnable, 1500);
    }

    private void stopAvatarAnimation() {
        animRunning = false;
        if (animRunnable != null) animHandler.removeCallbacks(animRunnable);
        CircleImageView[] views = {ivAnimReel, ivAnimX, ivAnimYoutube};
        for (CircleImageView iv : views) {
            if (iv == null) continue;
            iv.setVisibility(View.INVISIBLE);
            iv.setScaleX(0f);
            iv.setScaleY(0f);
            iv.setAlpha(0f);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // FIX (isVisible gate, screen-scoped — see ProfileAvatarBinder): the
        // version-sync watch stays alive while paused, so any push that
        // lands from here on is gated to disk-cache-only until onResume.
        screenVisible = false;
        stopAvatarAnimation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        screenVisible = true;
        // FIX (isVisible gate, screen-scoped): upgrade whatever the gated
        // avatarVersion listener may have only disk-warmed while this
        // screen was paused to a real network-capable load now that it's
        // confirmed back on screen. No-op if nothing was pending.
        if (partnerPhoto != null && !partnerPhoto.isEmpty()) {
            ProfileAvatarBinder.promote(this, binding.ivAvatarLarge,
                partnerPhoto, partnerAvatarVersion, ProfileAvatarBinder.LARGE_TIER, R.drawable.ic_person);
        }
        if (partnerUid != null) loadAvatarAndStartAnimation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAvatarAnimation();
        dbExecutor.shutdown();
        // FIX (Lifecycle-aware cancel — see ProfileAvatarBinder#cancel):
        // stops any in-flight avatar request now that this screen is going
        // away for good.
        ProfileAvatarBinder.cancel(this, binding.ivAvatarLarge);
        if (partnerUid != null && !partnerUid.isEmpty()) {
            AvatarVersionSyncManager.getInstance(this).unwatch(partnerUid, partnerAvatarVersionListener);
        }
    }

    // ─── 3-dot overflow menu ─────────────────────────────────────
    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.user_profile_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_edit_profile) {
            // Open ProfileActivity (self edit) — same as before
            Intent i = new Intent(this, ProfileActivity.class);
            startActivity(i);
            return true;
        }
        if (id == R.id.action_media_links_docs) {
            openAllMediaLinksDocs();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /** Open WhatsApp-style Media, Links & Docs for this chat */
    private void openAllMediaLinksDocs() {
        if (chatId == null || chatId.isEmpty()) {
            // chatId nahi hai — build karo (current user + partner)
            String currentUid = com.google.firebase.auth.FirebaseAuth
                .getInstance().getUid();
            if (currentUid != null && partnerUid != null) {
                // Same logic as ChatActivity.buildChatId()
                chatId = currentUid.compareTo(partnerUid) < 0
                    ? currentUid + "_" + partnerUid
                    : partnerUid + "_" + currentUid;
            }
        }
        Intent i = new Intent(this, AllMediaLinksDocsActivity.class);
        i.putExtra("chatId",      chatId);
        i.putExtra("partnerName", partnerName);
        i.putExtra("isGroup",     false);
        startActivity(i);
    }
}
