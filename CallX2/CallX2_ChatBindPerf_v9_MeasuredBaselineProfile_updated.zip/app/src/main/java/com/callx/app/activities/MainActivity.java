package com.callx.app.activities;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.viewpager2.widget.ViewPager2;
import com.bumptech.glide.Glide;
import com.callx.app.cache.ChatAvatarBinder;
import com.callx.app.cache.AvatarVersionSyncManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.callx.app.R;
import com.callx.app.adapters.ViewPagerAdapter;
import com.callx.app.databinding.ActivityMainBinding;
import com.callx.app.utils.Constants;
import com.callx.app.utils.FirebaseUtils;
import com.google.android.material.badge.BadgeDrawable;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import com.google.firebase.messaging.FirebaseMessaging;
import com.callx.app.notifications.ReelNotificationsActivity;
import com.callx.app.workers.StoryNotificationWorker;
import com.callx.app.feed.ReelsFragment;
import com.callx.app.utils.AppUpdateManager;
import android.animation.ObjectAnimator;
import com.callx.app.upload.ReelUploadActivity;
import com.callx.app.profile.UserReelsActivity;
  import android.view.View;
  import android.widget.TextView;
  import android.widget.ImageButton;
  import com.bumptech.glide.Glide;
  import de.hdodenhof.circleimageview.CircleImageView;
  import com.callx.app.feed.XActivity;
  import com.callx.app.notifications.XNotificationWorker;
  import com.callx.app.utils.XFirebaseUtils;
  import com.callx.app.home.YouTubeActivity;
  import com.callx.app.notifications.YouTubeNotificationWorker;
  import com.callx.app.utils.YouTubeFirebaseUtils;
  import android.graphics.Bitmap;
  import android.graphics.BitmapShader;
  import android.graphics.Canvas;
  import android.graphics.Paint;
  import android.graphics.Shader;
  import android.graphics.drawable.BitmapDrawable;
  import com.bumptech.glide.request.target.CustomTarget;
  import com.bumptech.glide.request.transition.Transition;
  import androidx.annotation.Nullable;
import com.callx.app.group.NewGroupActivity;
import com.callx.app.services.CallForegroundService;
import com.callx.app.compose.NewStatusActivity;
import com.callx.app.hub.GamesHubActivity;
import com.callx.app.feed.ReelChatDockedPlayer;
import com.callx.app.feed.ReelDisplayModeListener;
import com.callx.app.social.ReelDisplayModeBottomSheet;
import com.callx.app.utils.ReelDisplayModePrefs;
import com.callx.app.utils.OptionalPermissionPrefs;
import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import com.callx.app.audio.GlobalVoicePlaybackManager;
import com.callx.app.conversation.ChatActivity;

public class MainActivity extends AppCompatActivity
        implements com.callx.app.feed.ReelDisplayModeListener,
                   com.callx.app.social.ReelDisplayModeBottomSheet.OnModeSelectedListener {

    private ActivityMainBinding binding;

    // v240 — splash-hold gate (see onCreate/installSplashScreen). Captured
    // as early as possible so the elapsed-time cap is measured from
    // Activity creation, not from further down onCreate.
    private static final long sProcessStartMs = android.os.SystemClock.elapsedRealtime();
    // Cap on how long the splash icon is allowed to stay up waiting for
    // AppDatabase's warm-up. Tuned to cover the common-case cold open
    // without risking the "app looks frozen" perception on a genuinely
    // slow device — past this, MainActivity proceeds and ChatsFragment
    // pays whatever DB-open cost is left, exactly like before this fix.
    private static final long SPLASH_MAX_HOLD_MS = 1200L;

    // My profile cache — for UserReelsActivity launch
    private String myName     = "";
    private String myPhotoUrl = "";

    // ── Chat-tab docked reel player ──────────────────────────────────────────
    /** Manages the mini floating reel overlay shown when user leaves Reels for Chat. */
    private ReelChatDockedPlayer dockedPlayer;
    /** Tracks the ViewPager2 page position BEFORE the current switch. */
    private int prevTabPosition = TAB_CHATS;

    // ── Voice-note mini player (WhatsApp-style persistent playback) ──────
    private final GlobalVoicePlaybackManager.Listener voiceMiniPlayerListener =
            new GlobalVoicePlaybackManager.Listener() {
        @Override public void onPlaybackStarted(String messageId, String chatId, String partnerUid,
                                                  String displayName, String avatarUrl, boolean outgoing) {
            runOnUiThread(() -> updateVoiceMiniPlayer());
        }
        @Override public void onPlaybackToggled(String messageId, boolean playing) {
            runOnUiThread(() -> updateVoiceMiniPlayer());
        }
        @Override public void onPlaybackStopped(String messageId) {
            runOnUiThread(() -> updateVoiceMiniPlayer());
        }
    };
    // PERF: resolved once in setupVoiceMiniPlayer() instead of re-running
    // findViewById() down the view tree on every updateVoiceMiniPlayer()
    // call (which fires on every toggle/start/stop AND every onResume).
    private View miniPlayerBanner;
    private ImageButton miniPlayerBtnPlay;
    private TextView miniPlayerTvName;
    private CircleImageView miniPlayerIvAvatar;
    // PERF: last avatar URL actually loaded into the mini player — skips
    // re-issuing a Glide request when a toggle/resume refresh has nothing
    // new to show (Glide's own memory cache makes a repeat load cheap, but
    // skipping the call entirely avoids even that lookup on a path that
    // can run several times a second while scrubbing play/pause).
    private String miniPlayerLoadedAvatarUrl;


      // ── X Module ────────────────────────────────────────────────────────────────
      private ValueEventListener xNotifBadgeListener;
      private int xUnreadCount = 0;

      // ── YouTube Module ───────────────────────────────────────────────────────
      private ValueEventListener ytNotifBadgeListener;
      private int ytUnreadCount = 0;

      // ── Games Module ─────────────────────────────────────────────────────────
      // No badge listener needed for now — Games has no notifications yet

    // Notification badge counter
    private int totalNotifUnread = 0;
    private int notifChatUnread   = 0;
    private int notifGroupUnread  = 0;
    private int notifReelUnread   = 0;
    private int notifCallUnread   = 0;
    // Status unseen count — included in the header notification ball
    private int notifStatusUnread = 0;
    private final java.util.Map<Integer, Integer> navBadgeCounts =
            new java.util.HashMap<>();
    private String lastNotificationBadgeText;
    private boolean badgeListenersAttached;
    private String badgeListenersUid;

    // Firebase listeners — attached only while MainActivity is started.
    private ValueEventListener unreadChatsListener;
    private ValueEventListener missedCallsListener;
    private ValueEventListener unseenStatusListener;
    private ValueEventListener unreadGroupsListener;
    private ValueEventListener unreadReelNotifsListener;
    private final java.util.Map<DatabaseReference, ChildEventListener>
            storyStatusListeners = new java.util.HashMap<>();
    private boolean storyListenersLoading;

    // Header/chrome views are resolved once from ViewBinding. These methods are
    // hit on tab changes and lifecycle callbacks, so walking the root view tree
    // there is unnecessary work.
    private View headerView;
    private View navContainerView;
    private TextView notificationBadgeView;
    private View returnToCallBannerView;
    private TextView returnToCallNameView;
    private TextView returnToCallTimerView;
    private ViewGroup.MarginLayoutParams viewPagerMargins;
    private int chromeBackgroundColor = Integer.MIN_VALUE;
    private boolean chromeNavVisible;
    private boolean chromeHeaderVisible;
    private boolean chromeStateInitialized;

    // Cached profile/avatar state prevents a Firebase + Glide round trip on
    // every onResume (which happens whenever a child Activity is closed).
    private static final String PREFS_MAIN_PROFILE_CACHE = "main_header_cache";
    private static final long HEADER_CACHE_TTL_MS = 6 * 60 * 60 * 1000L;
    private String reelsAvatarLoadedUrl;
    private com.bumptech.glide.request.target.CustomTarget<Bitmap> reelsAvatarTarget;

    // Direct callback from the foreground call service; no reflection or
    // 500ms service-state polling is needed.
    private final CallForegroundService.StateListener callStateListener =
            () -> runOnUiThread(this::updateReturnToCallBanner);

    // Track already-notified status IDs so we don't re-notify on re-attach
    private final java.util.Set<String> notifiedStatusIds = new java.util.HashSet<>();

    // ── Tab history for Instagram-style back navigation ──────────────────
    private final java.util.Deque<Integer> tabHistoryStack = new java.util.ArrayDeque<>();
    private static final int TAB_CHATS  = 0;
    private static final int TAB_REELS  = 1;
    private static final int TAB_STATUS = 2;
    private static final int TAB_GROUPS = 3;
    private static final int TAB_CALLS  = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ── FASTEST-OPEN FIX: install the system splash screen FIRST ──────
        // Must be called before super.onCreate(). This makes the OS keep
        // showing the Theme.CallX.Splash icon/background (already on
        // screen since before Application.onCreate even ran) instead of
        // tearing it down for a blank window while the rest of onCreate
        // below does its work. Default dismiss condition is "this
        // Activity's first frame is drawn", which — since we now gate
        // everything behind the auth check right below — means the splash
        // stays up either through the brief auth-check-and-redirect (not
        // logged in) or straight through to the real UI being ready to
        // paint (logged in), never a blank/white flash in between.
        androidx.core.splashscreen.SplashScreen.installSplashScreen(this)
                // v240 — PERF FIX: "chats tab first open is a 500ms-3sec
                // blank/loading wait" — root cause was that the splash's
                // default dismiss condition (this Activity's first frame
                // drawn) fires the moment ChatsFragment's layout inflates,
                // which happens LONG before AppDatabase's real file-open +
                // migration cost (paid on the db-warmup thread, see
                // CallxApp) finishes. So the splash vanished instantly and
                // the user watched an empty Chat List for the real wait
                // instead — same total time, but felt like the app was
                // slow/broken rather than "still launching".
                //
                // v392 WHATSAPP-LEVEL FIX — this gate was written before
                // ChatSnapshotCache's SharedPreferences instant snapshot
                // (v210) existed, and never got revisited afterwards. Once
                // v210 landed, "the user watched an empty Chat List" is no
                // longer actually true for the common case (any user who's
                // opened the app before): ChatsFragment can repaint a real
                // chat list INSTANTLY from that plain-SharedPreferences
                // snapshot regardless of whether the encrypted Room DB is
                // warm yet. Holding the branded splash icon up to
                // SPLASH_MAX_HOLD_MS in that case was pure redundant wait
                // stacked on top of a problem v210 already solved — exactly
                // the extra ~200ms-1.2s that still made cold start feel
                // slower than WhatsApp even after v390/v391. Now: if a
                // snapshot exists, dismiss the splash immediately and let
                // ChatsFragment's own instant-snapshot path (already wired,
                // see its onCreateView) take over the very next frame — the
                // DB-warmup wait below is now reserved for the one case it's
                // actually still needed: a genuinely first-ever open (no
                // snapshot yet) where there'd otherwise be nothing to paint.
                .setKeepOnScreenCondition(() ->
                        !com.callx.app.chatlist.ChatSnapshotCache.hasSnapshot(this)
                                && !com.callx.app.db.AppDatabase.isDbWarmupComplete()
                                && (android.os.SystemClock.elapsedRealtime() - sProcessStartMs) < SPLASH_MAX_HOLD_MS);

        // MUST be called before super.onCreate / setContentView so the window
        // is configured for edge-to-edge before any layout pass happens.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        // Cutout mode set ONCE here (not toggled per tab-switch) — repeatedly
        // calling getWindow().setAttributes() on every Reels<->tab switch was
        // forcing a window relayout race that intermittently left nav_container
        // mismeasured/invisible after returning from Reels.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            android.view.WindowManager.LayoutParams attrs = getWindow().getAttributes();
            attrs.layoutInDisplayCutoutMode =
                    android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R
                            ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                            : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(attrs);
        }

        super.onCreate(savedInstanceState);

        // ── FASTEST-OPEN FIX: auth check BEFORE inflating anything ────────
        // Old order inflated the ENTIRE ActivityMainBinding (toolbar,
        // ViewPager2 host, bottom nav, FAB, return-to-call banner, etc.)
        // and ran a full layout+draw pass EVERY cold start, even for a
        // logged-out user who was just about to get redirected straight to
        // AuthActivity anyway — pure wasted inflate + an extra Activity
        // hop on top. Checking first means the not-logged-in path (rare —
        // fresh install / after logout) redirects immediately with zero
        // wasted work, and the logged-in path (the common one) goes
        // straight into the real inflate below with nothing in front of it.
        // FirebaseAuth.getInstance().getCurrentUser() is a synchronous read
        // of the already-cached local auth state (no network call), so
        // this check itself costs effectively nothing.
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, AuthActivity.class));
            overridePendingTransition(0, 0); // no slide — this isn't a real tab/screen transition
            finish();
            return;
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        cacheHeaderViews();

        // v391 WHATSAPP-LEVEL FIX — moved off the critical cold-start path.
        // See requestPermissions()'s own doc + OptionalPermissionPrefs for
        // the full root-cause explanation: this used to run synchronously
        // right here, and two of its three checks could launch a full
        // system Settings screen on every cold start, hijacking the
        // Activity before the Chats tab ever got to draw. The
        // POST_NOTIFICATIONS dialog is cheap and harmless to keep eager
        // (it's a lightweight system dialog, not a screen navigation), but
        // the two Settings-redirect checks are now gated to ask once ever
        // AND deferred with post() so they run after this frame is already
        // queued to draw — never in front of it.
        requestNotificationPermission();
        binding.getRoot().post(this::requestOptionalSettingsPermissionsOnce);
        // Step 4 (Instagram-style rollout): one-time forced "choose your
        // username" prompt for accounts created before real usernames
        // existed (their `username` is still just the phone number).
        // Deferred with post() same as the line above — a Firebase read
        // here, not blocking the cold-start render.
        binding.getRoot().post(this::checkUsernameMigrationOnce);

        // ── Handle tap from system reel notification (Doze / killed state) ─────
        handleReelNotifIntent(getIntent());
        handleDeepLinkIntent(getIntent());  // Tab deep link
        // ──────────────────────────────────────────────────────────────────────

        setSupportActionBar(binding.toolbar);

          // v241: old toolbar X / YouTube / Games entry-strip buttons removed
          // (setupXEntryButton() / setupYouTubeEntryButton() / setupGamesEntryButton()
          // no longer called — those cards now live in the Chats tab quick-access
          // header instead). YouTube's background notification worker still needs
          // to run regardless of the button, so that one scheduling call is kept.
          YouTubeNotificationWorker.schedule(this);

        binding.btnSearchToolbar.setOnClickListener(v -> {
            startActivity(new Intent(this, SearchActivity.class));
            overridePendingTransition(0, 0); // Tab switch — instant 0ms
        });

        binding.btnNotificationsToolbar.setOnClickListener(v -> {
            startActivity(new Intent(this, AllNotificationsActivity.class));
            overridePendingTransition(0, 0); // Tab switch — instant 0ms
        });

        setupVoiceMiniPlayer();
        setupReturnToCallBanner();

        // v244: avatar removed from toolbar — Settings (AccountMenuActivity)
        // now opens from the 3-dot overflow menu instead (see onOptionsItemSelected).

        binding.viewPager.setAdapter(new ViewPagerAdapter(this));
        // Keep ViewPager2's default adaptive retention. A fixed limit of 1
        // eagerly creates the adjacent Reels fragment (and its player) on
        // every cold start; the default lets RecyclerView retain only what
        // the current layout actually needs.
        binding.viewPager.setOffscreenPageLimit(ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT);
        
        // Initialize tab history with starting tab (chats)
        tabHistoryStack.push(TAB_CHATS);
        // Bottom nav tap par instant switch (no scroll animation) — WhatsApp jaisa
        binding.viewPager.setUserInputEnabled(true);
        // FIX: multi-photo reel ke left/right swipe se tab switch ho jaata tha —
        // Reels feature (different module) is deterministic backstop ke through
        // is pager ka swipe on/off karta hai jab tak koi multi-photo reel screen
        // par visible hai. See ReelTabSwipeLock for the full explanation.
        com.callx.app.utils.ReelTabSwipeLock.setController(
            enabled -> binding.viewPager.setUserInputEnabled(enabled));
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int position) {
                // Add to history stack if different from current top
                if (tabHistoryStack.isEmpty() || tabHistoryStack.peek() != position) {
                    tabHistoryStack.push(position);
                }
                
                int[] ids = {
                    R.id.nav_chats,
                    R.id.nav_reels,
                    R.id.nav_status,
                    R.id.nav_groups,
                    R.id.nav_calls
                };
                if (position >= 0 && position < ids.length)
                    binding.bottomNav.setSelectedItemId(ids[position]);
                updateFab(position);
                // First time ever landing on the Reels tab: ask the user which
                // display mode they want (Immersive vs Normal) before applying
                // any chrome visibility change for this tab.
                if (position == TAB_REELS && !com.callx.app.utils.ReelDisplayModePrefs.hasBeenAsked(MainActivity.this)) {
                    showReelDisplayModeFirstVisitChooser();
                }
                // Hide app's own header + bottom nav when Reels tab is active
                // (always, in both display modes); phone status/nav bar
                // visibility depends on the chosen Reels display mode.
                applyReelsTabChrome(position == TAB_REELS);
                // WhatsApp-style: the app header (title/search/bell/avatar +
                // X/YouTube/Games entry) only belongs on the Chats tab. Status,
                // Groups and Calls each have their own top area (or none) —
                // Reels is skipped here since it already fully owns its chrome.
                // ── Reel playback: pause when leaving, resume when entering ──
                // Track previous tab so we know whether user is going TO or FROM Reels
                notifyReelsTabVisibility(position == TAB_REELS, position);
                prevTabPosition = position;
            }
        });

        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            // false = instant switch (no scroll animation) — WhatsApp/Instagram jaisa snap
            if      (id == R.id.nav_chats)  { binding.viewPager.setCurrentItem(TAB_CHATS, false); }
            else if (id == R.id.nav_status) {
                binding.viewPager.setCurrentItem(TAB_STATUS, false);
                clearBadge(R.id.nav_status);
                // Also clear status contribution from header notification ball
                notifStatusUnread = 0;
                updateNotifBadge();
            }
            else if (id == R.id.nav_groups) {
                binding.viewPager.setCurrentItem(TAB_GROUPS, false);
                clearBadge(R.id.nav_groups);
            }
            else if (id == R.id.nav_reels)  {
                binding.viewPager.setCurrentItem(TAB_REELS, false);
                clearBadge(R.id.nav_reels);
            }
            else if (id == R.id.nav_calls)  {
                binding.viewPager.setCurrentItem(TAB_CALLS, false);
                // Mark missed calls as seen
                getSharedPreferences("callx_prefs", MODE_PRIVATE).edit()
                    .putLong("last_seen_calls_ts", System.currentTimeMillis()).apply();
                clearBadge(R.id.nav_calls);
            }
            return true;
        });

        binding.fabAction.setOnClickListener(v -> {
            int pos = binding.viewPager.getCurrentItem();
            if      (pos == TAB_CHATS)  startActivity(new Intent(this, SearchActivity.class));
            else if (pos == TAB_STATUS) startActivity(new Intent(this, NewStatusActivity.class));
            else if (pos == TAB_GROUPS) startActivity(new Intent(this, NewGroupActivity.class));
            else if (pos == TAB_REELS)  startActivity(new Intent(this, ReelUploadActivity.class));
            else                        startActivity(new Intent(this, SearchActivity.class));
        });

        loadMyAvatar();
        loadReelsAvatarIntoNavTab();  // Reels nav tab mein Reels profile avatar dikhao
        refreshFcmToken();
        // ── In-App Update Check — Firebase se version compare karta hai ──
        AppUpdateManager.check(this);
    }

    // Called when app is ALREADY running and user taps a reel notification or deep link
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleReelNotifIntent(intent);
        handleDeepLinkIntent(intent);  // Deep link handling
    }

    /** Handle incoming deep links from DeepLinkRouterActivity or direct App Links */
    private void handleDeepLinkIntent(Intent intent) {
        if (intent == null) return;
        String tab = intent.getStringExtra("open_tab");
        if (tab == null) return;
        switch (tab) {
            case "chats":        binding.viewPager.setCurrentItem(TAB_CHATS,  false); break;
            case "reels":        binding.viewPager.setCurrentItem(TAB_REELS,  false); break;
            case "status":       binding.viewPager.setCurrentItem(TAB_STATUS, false); break;
            case "groups":       binding.viewPager.setCurrentItem(TAB_GROUPS, false); break;
            case "calls":        binding.viewPager.setCurrentItem(TAB_CALLS,  false); break;
        }
    }

    /** Navigate to ReelNotificationsActivity when user taps the system
     *  "notification" payload notification (Doze / extreme killed state).
     *  The FCM click_action "OPEN_REEL_NOTIFICATION" routes here via manifest
     *  intent-filter; the data extras carry reel_id etc. */
    private void handleReelNotifIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        boolean isReelNotif =
            "OPEN_REEL_NOTIFICATION".equals(action)
            || intent.hasExtra("reel_notif_type")
            || intent.hasExtra("reel_id");
        if (!isReelNotif) return;
        // Delay slightly so MainActivity finishes setup first
        binding.getRoot().post(() ->
            startActivity(new Intent(this, ReelNotificationsActivity.class)));
    }

    @Override protected void onResume() {
        super.onResume();
        int currentTab = binding.viewPager.getCurrentItem();
        boolean isReelsTab = currentTab == TAB_REELS;

        // v8: pick the docked mini reel player back up first — e.g. the user
        // just returned from ChatActivity with one still playing. Same
        // ExoPlayer instance, no reload, only the rendering surface moves.
        if (dockedPlayer != null && dockedPlayer.isActive() && !dockedPlayer.isShowing()) {
            dockedPlayer.attachToActivity(this);
        }

        // onResume doesn't represent a tab switch. If a docked session is
        // already active (just reattached above, or was already showing
        // before this pause/resume cycle) skip the normal dock/undock
        // transition below entirely — re-running it here would immediately
        // tear down the session we just reattached and rebuild a brand new
        // one from whatever ReelsFragment's internal pager happens to be on.
        boolean dockedAlreadyActive = dockedPlayer != null && dockedPlayer.isActive();
        if (!dockedAlreadyActive) {
            // Pass current tab as destination — onResume doesn't represent a "switch",
            // so we treat it as a no-op dock transition (normal resume path).
            notifyReelsTabVisibility(isReelsTab, currentTab);
        }
        applyReelsTabChrome(isReelsTab);
        // Feature 1: Return to Call Banner
        updateReturnToCallBanner();
        // Voice-note mini player — re-sync in case a clip started/stopped
        // while this Activity wasn't the one on screen (e.g. was paused
        // behind ChatActivity when playback state last changed).
        updateVoiceMiniPlayer();
    }

    @Override protected void onStart() {
        super.onStart();
        CallForegroundService.addStateListener(callStateListener);
        startBadgeListeners();
        updateReturnToCallBanner();
    }

    // ── Voice-note mini player ────────────────────────────────────────────
    // WhatsApp-style green strip — shown above the toolbar whenever
    // GlobalVoicePlaybackManager has an active voice note (playing OR
    // paused-but-still-active), which happens once the user leaves the
    // ChatActivity screen it was started from. See MessagePagingAdapter's
    // onDetachedFromRecyclerView for the hand-off that keeps it alive.
    private void cacheHeaderViews() {
        headerView = binding.appBarLayout;
        navContainerView = binding.navContainer;
        notificationBadgeView = binding.tvNotifBadge;
        returnToCallBannerView = binding.bannerReturnToCall;
        returnToCallNameView = binding.tvReturnToCallName;
        returnToCallTimerView = binding.tvReturnToCallTimer;
        viewPagerMargins = (ViewGroup.MarginLayoutParams) binding.viewPager.getLayoutParams();
        chromeStateInitialized = false;
    }

    private void setupReturnToCallBanner() {
        if (returnToCallBannerView == null) return;
        returnToCallBannerView.setOnClickListener(v -> {
            Intent i = new Intent(this, com.callx.app.call.CallActivity.class);
            i.putExtra("partnerUid", CallForegroundService.activePartnerUid);
            i.putExtra("partnerName", CallForegroundService.activePartnerName);
            i.putExtra("partnerPhoto", CallForegroundService.activePartnerPhoto);
            i.putExtra("partnerThumb", CallForegroundService.activePartnerThumb);
            i.putExtra("callId", CallForegroundService.activeCallId);
            i.putExtra("video", CallForegroundService.activeIsVideo);
            i.putExtra("isCaller", CallForegroundService.activeIsCaller);
            i.putExtra("isRestore", true);
            i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        });
    }

    private void setupVoiceMiniPlayer() {
        View banner = binding.bannerVoiceMiniPlayer;
        if (banner == null) return;
        // PERF: resolve every child view once here; updateVoiceMiniPlayer()
        // (the hot path — runs on every play/pause/start/stop and every
        // onResume) then just reads these fields instead of walking the
        // view tree again.
        miniPlayerBanner = banner;
        miniPlayerBtnPlay = banner.findViewById(R.id.btn_mini_player_play);
        miniPlayerTvName = banner.findViewById(R.id.tv_mini_player_name);
        miniPlayerIvAvatar = banner.findViewById(R.id.iv_mini_player_avatar);

        GlobalVoicePlaybackManager.getInstance().addListener(voiceMiniPlayerListener);

        miniPlayerBtnPlay.setOnClickListener(v ->
                GlobalVoicePlaybackManager.getInstance().togglePlayPause());

        banner.findViewById(R.id.btn_mini_player_close).setOnClickListener(v ->
                GlobalVoicePlaybackManager.getInstance().stopAndClear());

        // Tap anywhere else on the strip → reopen the chat this clip came
        // from, same as tapping the return-to-call banner reopens CallActivity.
        banner.setOnClickListener(v -> {
            String partnerUid = GlobalVoicePlaybackManager.getInstance().getCurrentPartnerUid();
            if (partnerUid == null || partnerUid.isEmpty()) return;
            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("partnerUid", partnerUid);
            if (!GlobalVoicePlaybackManager.getInstance().isOutgoing()) {
                String name = GlobalVoicePlaybackManager.getInstance().getDisplayName();
                String avatar = GlobalVoicePlaybackManager.getInstance().getAvatarUrl();
                if (name != null) i.putExtra("partnerName", name);
                if (avatar != null) i.putExtra("partnerPhoto", avatar);
            }
            startActivity(i);
            overridePendingTransition(0, 0);
        });
    }

    private void updateVoiceMiniPlayer() {
        if (miniPlayerBanner == null) return;

        GlobalVoicePlaybackManager mgr = GlobalVoicePlaybackManager.getInstance();
        if (!mgr.hasActiveMessage()) {
            if (miniPlayerBanner.getVisibility() != View.GONE) {
                miniPlayerBanner.setVisibility(View.GONE);
            }
            miniPlayerLoadedAvatarUrl = null;
            return;
        }

        if (miniPlayerBanner.getVisibility() != View.VISIBLE) {
            miniPlayerBanner.setVisibility(View.VISIBLE);
        }

        miniPlayerBtnPlay.setImageResource(mgr.isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);

        String name = mgr.getDisplayName();
        miniPlayerTvName.setText(name != null && !name.isEmpty() ? name : "Voice message");

        // PERF: only touch Glide when the avatar actually changed — a
        // play/pause toggle re-renders this method without a new avatar,
        // so re-issuing the same load request every time is wasted work.
        String avatarUrl = mgr.getAvatarUrl();
        if (!java.util.Objects.equals(avatarUrl, miniPlayerLoadedAvatarUrl)) {
            miniPlayerLoadedAvatarUrl = avatarUrl;
            // FIX (avatar optimization wiring): this mini-player avatar is the same
            // chat partner shown in ChatListAdapter/ChatActivity, but was a raw
            // Glide.load() with no tier bucketing, no L2/L3 write-through, and no
            // shared cache entry with the rest of chat's avatar pipeline — every
            // play/pause-triggered rebind (guarded above) paid a fresh decode even
            // if the SAME partner's avatar was already hot in ChatAvatarL2Cache
            // from the chat list/ChatActivity. Now routed through ChatAvatarBinder
            // (34dp tier) so it reuses those entries instead of a separate copy,
            // and picks up AvatarVersionSyncManager's cached version for a
            // mid-session avatar change the same way chat list rows do.
            String partnerUid = mgr.getCurrentPartnerUid();
            long version = (partnerUid != null && !partnerUid.isEmpty())
                    ? AvatarVersionSyncManager.getInstance(this).getCachedVersion(partnerUid) : 0L;
            if (avatarUrl != null && !avatarUrl.isEmpty()) {
                ChatAvatarBinder.bind(this, miniPlayerIvAvatar, avatarUrl, version, R.drawable.ic_person,
                        com.callx.app.utils.AvatarSizeTier.forViewSizeDp(34));
            } else {
                miniPlayerIvAvatar.setImageResource(R.drawable.ic_person);
            }
        }
    }

    // ── Feature 1: Return to Call Banner ─────────────────────────────────
    // WhatsApp-style green strip — tab dikhata hai jab user call mein ho aur
    // alag screen pe chala jaye. Tap karne par CallActivity wapas khul jaati hai.
    private final Handler bannerTickHandler = new Handler(Looper.getMainLooper());
    private Runnable bannerTickRunnable;

    private void updateReturnToCallBanner() {
        if (returnToCallBannerView == null) return;
        boolean callActive = CallForegroundService.isRunning;

        if (!callActive) {
            if (returnToCallBannerView.getVisibility() != View.GONE) {
                returnToCallBannerView.setVisibility(View.GONE);
            }
            bannerTickHandler.removeCallbacksAndMessages(null);
            return;
        }

        if (returnToCallBannerView.getVisibility() != View.VISIBLE) {
            returnToCallBannerView.setVisibility(View.VISIBLE);
        }
        String name = CallForegroundService.activePartnerName;
        if (returnToCallNameView != null) {
            String label = (name == null || name.isEmpty())
                    ? "Tap to return to call" : name + " · Tap to return";
            if (!label.contentEquals(returnToCallNameView.getText())) {
                returnToCallNameView.setText(label);
            }
        }

        // Only the visual timer is periodic; service state changes arrive via
        // StateListener, so this runnable never performs reflection/polling.
        bannerTickHandler.removeCallbacksAndMessages(null);
        bannerTickRunnable = new Runnable() {
            @Override public void run() {
                if (!CallForegroundService.isRunning) {
                    updateReturnToCallBanner();
                    return;
                }
                if (returnToCallTimerView != null) {
                    String[] dots = {"●○○", "○●○", "○○●"};
                    returnToCallTimerView.setText(
                            dots[(int) ((System.currentTimeMillis() / 500) % 3)]);
                }
                bannerTickHandler.postDelayed(this, 500);
            }
        };
        bannerTickHandler.post(bannerTickRunnable);
    }

    @Override protected void onPause() {
        super.onPause();
        bannerTickHandler.removeCallbacksAndMessages(null);
    }

    @Override protected void onStop() {
        CallForegroundService.removeStateListener(callStateListener);
        detachBadgeListeners();
        bannerTickHandler.removeCallbacksAndMessages(null);
        super.onStop();
        // Some OEMs skip onUserLeaveHint; retain the PiP fallback.
        if (dockedPlayer != null && dockedPlayer.isShowing()
                && !dockedPlayer.isInPipMode()
                && !isFinishing()) {
            dockedPlayer.enterPipIfSupported();
        }
    }

    // ── Feature 5: Picture-in-Picture support ─────────────────────────────
    //
    // Three-layer PiP trigger strategy (most → least reliable):
    //
    //  Layer 1 — API 31+  setAutoEnterEnabled(true): system handles gesture-home
    //             nav automatically; onUserLeaveHint is NOT needed on these devices.
    //  Layer 2 — onUserLeaveHint(): fires on back-button / power-button home.
    //             Covers API 26-30 and older gesture models.
    //  Layer 3 — onStop(): last-resort fallback for ROM variants that skip both
    //             of the above (observed on some Xiaomi / MIUI builds).
    //
    // expandForPip() is called INSIDE enterPipIfSupported() BEFORE the system call
    // so the video surface is already full-window when PiP clips it — this prevents
    // the jarring "mini player → PiP" size jump.

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        // Layer 2 fallback — covers hardware home button + API 26-30 gesture
        if (dockedPlayer != null && dockedPlayer.isShowing()
                && !dockedPlayer.isInPipMode()) {
            dockedPlayer.enterPipIfSupported();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPipMode,
                                              android.content.res.Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPipMode, newConfig);

        // NOTE: do NOT guard with dockedPlayer.isShowing() here.
        // expandForPip() sets inPipMode=true, which means isShowing() may behave
        // differently depending on implementation. Track PiP state via isInPipMode flag.
        if (dockedPlayer == null) return;

        if (isInPipMode) {
            // Safety net: expand again in case the system triggered PiP via autoEnter
            // before our enterPipIfSupported() could call expandForPip() first.
            dockedPlayer.expandForPip();
        } else {
            // User swiped PiP overlay away or returned to the app → restore corner
            if (dockedPlayer.isInPipMode()) {
                dockedPlayer.restoreFromPip();
            }
        }
    }

    @Override protected void onDestroy() {
        // FIX: detach so a destroyed Activity's binding.viewPager can't be
        // touched by a stray lock()/unlock() call from a Reels fragment
        // still finishing off its own lifecycle.
        com.callx.app.utils.ReelTabSwipeLock.setController(null);
        CallForegroundService.removeStateListener(callStateListener);
        detachBadgeListeners();
        GlobalVoicePlaybackManager.getInstance().removeListener(voiceMiniPlayerListener);
        // Clean up any active docked reel player to release the ExoPlayer surface
        if (dockedPlayer != null) {
            dockedPlayer.dismiss(false);
            dockedPlayer = null;
        }
        super.onDestroy();
    }

    private String currentUid() {
        return FirebaseAuth.getInstance().getCurrentUser() == null
            ? null : FirebaseUtils.getCurrentUid();
    }

    // ── Overlay permission callback — auto-retry SmallWindow ─────────────────
    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == com.callx.app.smallwindow.PrivacyDirectDialog.REQ_OVERLAY_PERMISSION) {
            // User returned from overlay permission settings
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M
                    && android.provider.Settings.canDrawOverlays(this)) {
                // Permission granted — auto-launch if pending data exists
                String uid    = getIntent().getStringExtra("_sw_pending_uid");
                String name   = getIntent().getStringExtra("_sw_pending_name");
                String status = getIntent().getStringExtra("_sw_pending_status");
                String photo  = getIntent().getStringExtra("_sw_pending_photo");

                if (uid != null || name != null) {
                    // Clean up pending extras
                    getIntent().removeExtra("_sw_pending_uid");
                    getIntent().removeExtra("_sw_pending_name");
                    getIntent().removeExtra("_sw_pending_status");
                    getIntent().removeExtra("_sw_pending_photo");

                    // Launch service
                    android.content.Intent svc = new android.content.Intent(
                        this, com.callx.app.smallwindow.SmallWindowService.class);
                    svc.putExtra(com.callx.app.smallwindow.SmallWindowService.EXTRA_USER_ID, uid);
                    svc.putExtra(com.callx.app.smallwindow.SmallWindowService.EXTRA_NAME,
                        name != null ? name : "");
                    svc.putExtra(com.callx.app.smallwindow.SmallWindowService.EXTRA_STATUS,
                        status != null ? status : "");
                    svc.putExtra(com.callx.app.smallwindow.SmallWindowService.EXTRA_PHOTO,
                        photo != null ? photo : "");

                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        startForegroundService(svc);
                    } else {
                        startService(svc);
                    }

                    android.widget.Toast.makeText(this,
                        "Small window open!", android.widget.Toast.LENGTH_SHORT).show();
                }
            } else {
                android.widget.Toast.makeText(this,
                    "Permission nahi mili — Settings mein jaake ON karo",
                    android.widget.Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * v391: split out of the old requestPermissions() — this half is a
     * standard system permission dialog (lightweight overlay, not a screen
     * navigation), so it's still fine to ask eagerly on every cold start
     * where it isn't yet granted/denied. Kept as its own method so the
     * (much heavier) Settings-redirect half below can be gated + deferred
     * independently — see requestOptionalSettingsPermissionsOnce() doc.
     */
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    /**
     * v391 WHATSAPP-LEVEL FIX — see OptionalPermissionPrefs's class doc for
     * the full root-cause explanation of why this used to make cold starts
     * feel "slow"/broken.
     *
     * Neither of these two permissions is needed for the Chats tab itself:
     * overlay is only for the small-window/chat-heads feature (already
     * requested contextually, right when actually needed, by
     * PrivacyDirectDialog / SmallWindowManager / ChatActivity /
     * NotificationActionReceiver); full-screen-intent only matters for the
     * incoming-call UI on Android 14+. So instead of forcing a Settings
     * screen in front of the user on every single cold start:
     *
     *  1. Each is asked at most ONCE EVER (OptionalPermissionPrefs — same
     *     one-time-prompt idiom as ReelDisplayModePrefs.hasBeenAsked()). A
     *     user who ignores or declines it isn't redirected again on their
     *     next relaunch.
     *  2. This whole method is only ever invoked via
     *     binding.getRoot().post(...) from onCreate() — i.e. after the
     *     current frame (the real Chats tab UI) is already queued to draw,
     *     so even the one time this does redirect to Settings, it can
     *     never again be the thing standing between a cold start and the
     *     user's first real view of their chat list.
     */
    private void requestOptionalSettingsPermissionsOnce() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                && !android.provider.Settings.canDrawOverlays(this)
                && !OptionalPermissionPrefs.hasAskedOverlay(this)) {
            OptionalPermissionPrefs.markAskedOverlay(this);
            try { startActivity(new Intent(
                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {}
            return; // don't stack a second Settings redirect on top of this one
        }
        if (Build.VERSION.SDK_INT >= 34
                && !OptionalPermissionPrefs.hasAskedFullScreenIntent(this)) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                OptionalPermissionPrefs.markAskedFullScreenIntent(this);
                try { startActivity(new Intent(
                    android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    android.net.Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {}
            }
        }
    }

    // Step 4 (Instagram-style rollout): SharedPreferences flag so, once an
    // account's username is confirmed to be a real chosen handle, this
    // never fires another Firebase read for that uid on later cold starts —
    // same "persist a known-good state so we can skip the check next time"
    // idiom as ChatActivity's chat_prune_check_state.
    private static final String PREFS_USERNAME_MIGRATION = "username_migration_state";

    /**
     * One-time forced "choose your username" gate for accounts created
     * before ProfileSetupActivity started asking for a real, independently-
     * chosen @username (see ProfileSetupActivity's class history) — those
     * accounts still have username == callxId (the phone number) or no
     * username at all. Fires at most once per uid: a confirmed-good result
     * is cached in SharedPreferences so this never re-reads Firebase for
     * that uid again.
     */
    private void checkUsernameMigrationOnce() {
        String uid = currentUid();
        if (uid == null) return;
        android.content.SharedPreferences prefs =
            getSharedPreferences(PREFS_USERNAME_MIGRATION, MODE_PRIVATE);
        if (prefs.getBoolean(uid, false)) return; // already confirmed good previously

        FirebaseUtils.getUserRef(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot s) {
                String username = s.child("username").getValue(String.class);
                String callxId  = s.child("callxId").getValue(String.class);
                boolean usernameMissing = username == null || username.trim().isEmpty();
                boolean usernameIsPhone = !usernameMissing && callxId != null
                        && !callxId.isEmpty() && username.equalsIgnoreCase(callxId);
                if (usernameMissing || usernameIsPhone) {
                    Intent i = new Intent(MainActivity.this, ProfileSetupActivity.class);
                    i.putExtra(ProfileSetupActivity.EXTRA_FORCE_USERNAME_MIGRATION, true);
                    startActivity(i);
                } else {
                    prefs.edit().putBoolean(uid, true).apply();
                }
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void updateFab(int position) {
        switch (position) {
            case TAB_CHATS:  binding.fabAction.setImageResource(R.drawable.ic_status_add); break;
            case TAB_STATUS: binding.fabAction.setImageResource(R.drawable.ic_camera);     break;
            case TAB_GROUPS: binding.fabAction.setImageResource(R.drawable.ic_group);      break;
            case TAB_REELS:  binding.fabAction.setImageResource(R.drawable.ic_add_reels);  break;
            case TAB_CALLS:  binding.fabAction.setImageResource(R.drawable.ic_phone);      break;
        }
    }

    private void loadMyAvatar() {
        String uid = currentUid();
        if (uid == null) return;
        android.content.SharedPreferences cache =
                getSharedPreferences(PREFS_MAIN_PROFILE_CACHE, MODE_PRIVATE);
        String prefix = uid + "_";
        myName = cache.getString(prefix + "name", "");
        myPhotoUrl = cache.getString(prefix + "photo", "");
        long cachedAt = cache.getLong(prefix + "updated_at", 0L);
        if (!myName.isEmpty() || !myPhotoUrl.isEmpty()) {
            if (cachedAt > 0
                    && System.currentTimeMillis() - cachedAt < HEADER_CACHE_TTL_MS) {
                return;
            }
        }
        FirebaseUtils.getUserRef(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                String name  = snap.child("name").getValue(String.class);
                String photo = snap.child("photoUrl").getValue(String.class);
                if (name  != null) myName     = name;
                if (photo != null) myPhotoUrl = photo;
                cache.edit()
                        .putString(prefix + "name", myName)
                        .putString(prefix + "photo", myPhotoUrl)
                        .putLong(prefix + "updated_at", System.currentTimeMillis())
                        .apply();
                // v244: toolbar avatar (ivAvatarMenu) removed — Settings now lives
                // in the 3-dot overflow menu instead. myName/myPhotoUrl fetched
                // above are still used elsewhere (e.g. openMyReelsProfile()), so
                // this method stays; only the Glide-into-view call is gone.
            }
            @Override public void onCancelled(DatabaseError e) {}
        });
    }

    private void openMyReelsProfile() {
        String uid = currentUid();
        if (uid == null) return;
        try {
            Class<?> cls = Class.forName("com.callx.app.profile.UserReelsActivity");
            Intent i = new Intent(this, cls);
            i.putExtra("uid",   uid);
            i.putExtra("name",  myName);
            i.putExtra("photo", myPhotoUrl);
            startActivity(i);
        } catch (ClassNotFoundException e) {
            startActivity(new Intent(this, AccountMenuActivity.class));
        }
    }

    // ── Badge System ────────────────────────────────────────────────────────
    private void startBadgeListeners() {
        String uid = currentUid();
        if (uid == null) return;
        if (badgeListenersAttached && uid.equals(badgeListenersUid)) return;
        detachBadgeListeners();
        badgeListenersAttached = true;
        badgeListenersUid = uid;

        // 1. Unread chats → nav_chats badge
        unreadChatsListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                long total = 0;
                int threads = 0;
                for (DataSnapshot c : snap.getChildren()) {
                    Long u = c.child("unread").getValue(Long.class);
                    if (u != null && u > 0) {
                        total += u;
                        threads++;
                    }
                }
                setBadge(R.id.nav_chats, (int) total);
                notifChatUnread = threads;
                updateNotifBadge();
                if (!storyListenersLoading && storyStatusListeners.isEmpty()) {
                    storyListenersLoading = true;
                    loadContactUidsForStoryNotif(uid, snap);
                }
            }
            @Override public void onCancelled(DatabaseError e) {}
        };
        FirebaseUtils.getContactsRef(uid).addValueEventListener(unreadChatsListener);

        // 2. Missed calls → nav_calls badge
        missedCallsListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                long seenTs = getSharedPreferences("callx_prefs", MODE_PRIVATE)
                    .getLong("last_seen_calls_ts", 0L);
                int missed = 0;
                for (DataSnapshot c : snap.getChildren()) {
                    String dir = c.child("direction").getValue(String.class);
                    String status = c.child("status").getValue(String.class);
                    Long ts    = c.child("timestamp").getValue(Long.class);
                    boolean isMissed = "missed".equals(dir) || "missed".equals(status);
                    if (isMissed && ts != null && ts > seenTs) missed++;
                }
                setBadge(R.id.nav_calls, missed);
                notifCallUnread = missed;
                updateNotifBadge();
            }
            @Override public void onCancelled(DatabaseError e) {}
        };
        FirebaseUtils.getCallsRef(uid).addValueEventListener(missedCallsListener);

        // 3. Unseen statuses → nav_status badge
        //    Cross-references statusSeen/{myUid}/{ownerUid}/{statusId} for accurate count.
        //    Only items whose timestamp is within 24 h AND not in statusSeen are "unseen".
        unseenStatusListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot allStatusSnap) {
                // Fetch our seen map first, then compute the badge count
                FirebaseUtils.getStatusSeenRef(uid).addListenerForSingleValueEvent(
                    new ValueEventListener() {
                        @Override public void onDataChange(DataSnapshot seenSnap) {
                            // Build: ownerUid → Set<statusId>
                            java.util.Map<String, java.util.Set<String>> seenMap
                                = new java.util.HashMap<>();
                            for (DataSnapshot ownerNode : seenSnap.getChildren()) {
                                java.util.Set<String> ids = new java.util.HashSet<>();
                                for (DataSnapshot idNode : ownerNode.getChildren())
                                    ids.add(idNode.getKey());
                                seenMap.put(ownerNode.getKey(), ids);
                            }
                            long cutoff = System.currentTimeMillis()
                                          - java.util.concurrent.TimeUnit.HOURS.toMillis(24);
                            int count = 0;
                            for (DataSnapshot ownerSnap : allStatusSnap.getChildren()) {
                                String ownerUid = ownerSnap.getKey();
                                if (uid.equals(ownerUid)) continue; // skip own statuses
                                java.util.Set<String> seen =
                                    seenMap.containsKey(ownerUid)
                                        ? seenMap.get(ownerUid) : new java.util.HashSet<>();
                                for (DataSnapshot statusItem : ownerSnap.getChildren()) {
                                    Long ts = statusItem.child("timestamp").getValue(Long.class);
                                    if (ts == null || ts <= cutoff) continue;
                                    String sid = statusItem.getKey();
                                    if (seen == null || !seen.contains(sid)) count++;
                                }
                            }
                            setBadge(R.id.nav_status, count);
                            // Also update the header notification ball
                            notifStatusUnread = count;
                            updateNotifBadge();
                        }
                        @Override public void onCancelled(DatabaseError e) {}
                    });
            }
            @Override public void onCancelled(DatabaseError e) {}
        };
        FirebaseUtils.getStatusRef().addValueEventListener(unseenStatusListener);

        // 4. Unread group messages → nav_groups badge (index shifted — was #4, now after 4b)
        unreadGroupsListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                int unread = 0;
                int threads = 0;
                for (DataSnapshot g : snap.getChildren()) {
                    Long u = g.child("unread").getValue(Long.class);
                    if (u != null && u > 0) {
                        unread += u;
                        threads++;
                    }
                }
                setBadge(R.id.nav_groups, unread);
                notifGroupUnread = threads;
                updateNotifBadge();
            }
            @Override public void onCancelled(DatabaseError e) {}
        };
        FirebaseUtils.getUserGroupsRef(uid).addValueEventListener(unreadGroupsListener);

        // 5. Unread reel notifications → nav_reels badge
        unreadReelNotifsListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                int unread = 0;
                for (DataSnapshot n : snap.getChildren()) {
                    Boolean read = n.child("read").getValue(Boolean.class);
                    if (read == null || !read) unread++;
                }
                setBadge(R.id.nav_reels, unread);
                notifReelUnread = unread;
                updateNotifBadge();
            }
            @Override public void onCancelled(DatabaseError e) {}
        };
        FirebaseUtils.db().getReference("reel_notifications")
            .child(uid).addValueEventListener(unreadReelNotifsListener);
    }

    private void detachBadgeListeners() {
        String uid = badgeListenersUid;
        if (uid != null) {
            if (unreadChatsListener != null) {
                FirebaseUtils.getContactsRef(uid).removeEventListener(unreadChatsListener);
            }
            if (missedCallsListener != null) {
                FirebaseUtils.getCallsRef(uid).removeEventListener(missedCallsListener);
            }
            if (unseenStatusListener != null) {
                FirebaseUtils.getStatusRef().removeEventListener(unseenStatusListener);
            }
            if (unreadGroupsListener != null) {
                FirebaseUtils.getUserGroupsRef(uid).removeEventListener(unreadGroupsListener);
            }
            if (unreadReelNotifsListener != null) {
                FirebaseUtils.db().getReference("reel_notifications").child(uid)
                        .removeEventListener(unreadReelNotifsListener);
            }
        }
        for (java.util.Map.Entry<DatabaseReference, ChildEventListener> entry
                : storyStatusListeners.entrySet()) {
            entry.getKey().removeEventListener(entry.getValue());
        }
        storyStatusListeners.clear();
        storyListenersLoading = false;
        unreadChatsListener = null;
        missedCallsListener = null;
        unseenStatusListener = null;
        unreadGroupsListener = null;
        unreadReelNotifsListener = null;
        badgeListenersAttached = false;
        badgeListenersUid = null;
    }

    /** Reels tab ke bottom nav icon mein Reels profile ka avatar load karo.
     *  Firebase path: reels/users/{uid} → photoUrl / thumbUrl */
    private void loadReelsAvatarIntoNavTab() {
        String uid = currentUid();
        if (uid == null) return;
        android.content.SharedPreferences cache =
                getSharedPreferences(PREFS_MAIN_PROFILE_CACHE, MODE_PRIVATE);
        String prefix = uid + "_reels_";
        String cachedUrl = cache.getString(prefix + "url", "");
        long cachedAt = cache.getLong(prefix + "updated_at", 0L);
        if (!cachedUrl.isEmpty()) {
            applyReelsAvatar(cachedUrl);
            if (cachedAt > 0
                    && System.currentTimeMillis() - cachedAt < HEADER_CACHE_TTL_MS) {
                return;
            }
        }
        com.google.firebase.database.FirebaseDatabase.getInstance()
            .getReference("reels/users").child(uid)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snap) {
                    String thumbUrl = snap.child("thumbUrl").getValue(String.class);
                    String photoUrl = snap.child("photoUrl").getValue(String.class);
                    String url = (thumbUrl != null && !thumbUrl.isEmpty()) ? thumbUrl : photoUrl;
                    if (url == null || url.isEmpty()) return;
                    cache.edit().putString(prefix + "url", url)
                            .putLong(prefix + "updated_at", System.currentTimeMillis())
                            .apply();
                    applyReelsAvatar(url);
                }
                @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError e) {}
            });
    }

    private void applyReelsAvatar(String url) {
        if (url == null || url.isEmpty() || url.equals(reelsAvatarLoadedUrl)) return;
        reelsAvatarLoadedUrl = url;
        int iconSizePx = (int) (24 * getResources().getDisplayMetrics().density);
        reelsAvatarTarget = new CustomTarget<Bitmap>() {
            @Override public void onResourceReady(
                    @NonNull Bitmap resource,
                    @Nullable Transition<? super Bitmap> transition) {
                android.view.MenuItem item = binding.bottomNav.getMenu()
                        .findItem(R.id.nav_reels);
                if (item == null) return;
                item.setIcon(new BitmapDrawable(getResources(), resource));
                // BottomNavigationView's default tint would grey out the avatar.
                if (binding.bottomNav.getChildCount() > 0
                        && binding.bottomNav.getChildAt(0)
                        instanceof com.google.android.material.bottomnavigation.BottomNavigationMenuView) {
                    com.google.android.material.bottomnavigation.BottomNavigationMenuView menuView =
                            (com.google.android.material.bottomnavigation.BottomNavigationMenuView)
                                    binding.bottomNav.getChildAt(0);
                    for (int i = 0; i < menuView.getChildCount(); i++) {
                        View child = menuView.getChildAt(i);
                        if (child instanceof com.google.android.material.bottomnavigation.BottomNavigationItemView) {
                            com.google.android.material.bottomnavigation.BottomNavigationItemView itemView =
                                    (com.google.android.material.bottomnavigation.BottomNavigationItemView) child;
                            if (itemView.getItemData() != null
                                    && itemView.getItemData().getItemId() == R.id.nav_reels) {
                                itemView.setIconTintList(null);
                                break;
                            }
                        }
                    }
                }
            }
            @Override public void onLoadCleared(@Nullable android.graphics.drawable.Drawable p) {}
        };
        Glide.with(this).asBitmap().load(url)
                .apply(new RequestOptions().circleCrop().override(iconSizePx, iconSizePx))
                .into(reelsAvatarTarget);
    }

    // v242: setupXEntryButton() / setupYouTubeEntryButton() / setupGamesEntryButton()
    // removed entirely — the old toolbar strip buttons (include_x_entry / include_yt_entry /
    // include_games_entry) no longer exist in activity_main.xml, so these methods (and their
    // R.id references) would fail to compile. That functionality now lives in the Chats-tab
    // quick-access card row instead. YouTubeNotificationWorker.schedule(this) — the one
    // non-UI side effect these methods had — is still called from onCreate() above.

    private void updateNotifBadge() {
        totalNotifUnread = notifChatUnread + notifGroupUnread + notifReelUnread + notifCallUnread + notifStatusUnread;
        TextView badge = notificationBadgeView;
        if (badge == null) return;
        if (totalNotifUnread > 0) {
            String text = totalNotifUnread > 99 ? "99+" : String.valueOf(totalNotifUnread);
            if (!text.equals(lastNotificationBadgeText)) {
                badge.setText(text);
                lastNotificationBadgeText = text;
            }
            if (badge.getVisibility() != View.VISIBLE) badge.setVisibility(View.VISIBLE);
        } else {
            lastNotificationBadgeText = null;
            if (badge.getVisibility() != View.GONE) badge.setVisibility(View.GONE);
        }
    }

    private void setBadge(int navItemId, int count) {
        Integer previous = navBadgeCounts.get(navItemId);
        if (previous != null && previous == count) return;
        navBadgeCounts.put(navItemId, count);
        if (count > 0) {
            BadgeDrawable badge = binding.bottomNav.getOrCreateBadge(navItemId);
            badge.setVisible(true);
            badge.setNumber(count);
            badge.setBackgroundColor(0xFFEF4444); // red badge
            badge.setBadgeTextColor(0xFFFFFFFF);
        } else {
            clearBadge(navItemId);
        }
    }

    private void clearBadge(int navItemId) {
        navBadgeCounts.put(navItemId, 0);
        binding.bottomNav.removeBadge(navItemId);
    }

    /**
     * Show or hide the main app header and bottom nav (the app's OWN tab
     * bar — Chats/Reels/Status/Groups/Calls), independent of the phone's
     * system status bar / navigation bar. See applyReelsTabChrome() below
     * for how these combine on the Reels tab.
     */
    private void setMainNavVisible(boolean visible) {
        setMainNavVisible(visible, visible);
    }

    private void setMainNavVisible(boolean navVisible, boolean headerVisible) {
        int navVisibility = navVisible ? View.VISIBLE : View.GONE;
        int headerVisibility = headerVisible ? View.VISIBLE : View.GONE;
        boolean changed = !chromeStateInitialized
                || chromeNavVisible != navVisible
                || chromeHeaderVisible != headerVisible;

        if (headerView != null && headerView.getVisibility() != headerVisibility) {
            headerView.setVisibility(headerVisibility);
            changed = true;
        }
        if (navContainerView != null
                && navContainerView.getVisibility() != navVisibility) {
            navContainerView.setVisibility(navVisibility);
            changed = true;
        }
        if (binding.fabAction.getVisibility() != navVisibility) {
            binding.fabAction.setVisibility(navVisibility);
            changed = true;
        }

        int density = Math.round(getResources().getDisplayMetrics().density);
        int topMargin = headerVisible ? 56 * density : 0;
        int bottomMargin = navVisible ? 58 * density : 0;
        if (viewPagerMargins == null) {
            viewPagerMargins = (ViewGroup.MarginLayoutParams)
                    binding.viewPager.getLayoutParams();
        }
        if (viewPagerMargins.topMargin != topMargin
                || viewPagerMargins.bottomMargin != bottomMargin) {
            viewPagerMargins.topMargin = topMargin;
            viewPagerMargins.bottomMargin = bottomMargin;
            binding.viewPager.setLayoutParams(viewPagerMargins);
            changed = true;
        }

        int background = navVisible ? 0xFFF5F6FA : 0xFF000000;
        if (chromeBackgroundColor != background) {
            binding.getRoot().setBackgroundColor(background);
            chromeBackgroundColor = background;
            changed = true;
        }
        chromeNavVisible = navVisible;
        chromeHeaderVisible = headerVisible;
        chromeStateInitialized = true;
        // Visibility/margin changes already schedule layout. Avoid the
        // unconditional requestLayout() that used to run on every tab event.
        if (changed) binding.viewPager.invalidate();
    }

    /**
     * WhatsApp-level behaviour: the app's own top header — title, search,
     * notification bell, avatar menu, and the X / YouTube / Games entry
     * chips — is Chats-specific chrome, not a generic app-wide bar. In
     * WhatsApp itself each tab (Chats, Updates/Status, Communities, Calls)
     * owns its own top area; here that means the shared header only shows
     * on the Chats tab and is hidden everywhere else (Status, Groups,
     * Calls each already render their own in-fragment top bar where
     * needed — e.g. Status's search field).
     *
     * The Reels tab is intentionally skipped: it already fully owns its
     * chrome (header AND bottom nav both hidden) via applyReelsTabChrome()
     * / setMainNavVisible(), so re-touching the header here would fight
     * that logic. Bottom nav is never touched by this method — it must
     * stay visible on every non-Reels tab so the user can still switch tabs.
     */
    private void updateHeaderVisibilityForTab(int position) {
        if (position == TAB_REELS) return; // Reels owns its own chrome fully
        setMainNavVisible(true, position == TAB_CHATS);
    }

    /**
     * Applies the correct combination of chrome for the current tab.
     *
     *  Non-Reels tabs: app header + app bottom nav VISIBLE, phone status bar
     *                  + phone navigation bar VISIBLE (fully normal).
     *
     *  Reels tab:      app header + app bottom nav ALWAYS HIDDEN — Reels is
     *                  always full-bleed edge-to-edge for its own chrome,
     *                  in BOTH display modes.
     *                    - Immersive mode: phone status bar + nav bar HIDDEN too
     *                      (true full-screen, swipe-to-reveal).
     *                    - Normal mode:    phone status bar + nav bar VISIBLE
     *                      (only the app's own header/tab-bar stay hidden).
     */
    private void applyReelsTabChrome(boolean isReelsTab) {
        if (!isReelsTab) {
            setMainNavVisible(true, binding.viewPager.getCurrentItem() == TAB_CHATS);
            setImmersiveMode(false);
            return;
        }
        setMainNavVisible(false, false);
        boolean showSystemBars = com.callx.app.utils.ReelDisplayModePrefs.isNormalMode(this);
        setReelsSystemBarsVisible(showSystemBars);
    }

    /**
     * Reels-tab-only system bar toggle (used by applyReelsTabChrome). Unlike
     * setImmersiveMode(), this always keeps status/nav bar ICONS light —
     * Reels' background is black in both display modes, so dark icons would
     * be invisible against it even when the bars themselves are visible.
     */
    private void setReelsSystemBarsVisible(boolean visible) {
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (visible) {
            // Normal mode: phone status bar + nav bar VISIBLE, light (white)
            // icons/buttons so they read over the black Reels background.
            WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
            controller.show(WindowInsetsCompat.Type.statusBars()
                | WindowInsetsCompat.Type.navigationBars());
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_DEFAULT);
            getWindow().setStatusBarColor(android.graphics.Color.BLACK);
            getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        } else {
            // Immersive mode: both bars HIDDEN, edge-to-edge, swipe to reveal.
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            controller.hide(WindowInsetsCompat.Type.statusBars()
                | WindowInsetsCompat.Type.navigationBars());
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
        }
    }

    /**
     * Enable or disable full-screen immersive (edge-to-edge) mode.
     * When enabled (Reels tab) — true full-screen TikTok style:
     *   - Status bar AND navigation bar are both HIDDEN.
     *   - User can swipe from top/bottom edge to temporarily reveal them.
     *   - Content draws behind both bars (edge-to-edge).
     * When disabled (other tabs), normal system chrome is fully restored.
     */
    private void setImmersiveMode(boolean immersive) {
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (immersive) {
            // Content draws behind status bar + nav bar (edge-to-edge)
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

            // Status bar: HIDDEN (same as ChatActivity) — swipe from top to reveal temporarily
            controller.hide(WindowInsetsCompat.Type.statusBars());
            // White icons on status bar so they are readable over dark video (on swipe-reveal)
            controller.setAppearanceLightStatusBars(false);
            // Navigation bar: hide so video extends to bottom
            controller.hide(WindowInsetsCompat.Type.navigationBars());
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
        } else {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), true);

            controller.show(WindowInsetsCompat.Type.statusBars()
                | WindowInsetsCompat.Type.navigationBars());
            controller.setAppearanceLightStatusBars(true);
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_DEFAULT);
            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        }
    }

    /**
     * Called once — the very first time the user ever lands on the Reels tab.
     * Shown non-cancelable so the user picks a real answer; MainActivity itself
     * is the listener since it shows the sheet on its own FragmentManager.
     */
    private void showReelDisplayModeFirstVisitChooser() {
        ReelDisplayModeBottomSheet sheet = ReelDisplayModeBottomSheet.newInstance(
            ReelDisplayModePrefs.MODE_IMMERSIVE, true);
        sheet.show(getSupportFragmentManager(), ReelDisplayModeBottomSheet.TAG);
    }

    /** ReelDisplayModeBottomSheet.OnModeSelectedListener — first-visit chooser answered. */
    @Override
    public void onModeSelected(String mode) {
        ReelDisplayModePrefs.setMode(this, mode);
        ReelDisplayModePrefs.markAsked(this);
        applyReelDisplayModeIfOnReelsTab();
    }

    /**
     * ReelDisplayModeListener — the user changed their mind from the Reels
     * 3-dot menu while still sitting on the Reels tab (no tab-switch to
     * trigger the usual re-check), so re-apply chrome visibility right now.
     */
    @Override
    public void onReelDisplayModeChanged(String mode) {
        applyReelDisplayModeIfOnReelsTab();
    }

    private void applyReelDisplayModeIfOnReelsTab() {
        if (binding.viewPager.getCurrentItem() == TAB_REELS) {
            applyReelsTabChrome(true);
        }
    }

    /**
     * Called by ReelsFragment back button to return to the Chats tab.
     */
    public void exitReelsTab() {
        binding.viewPager.setCurrentItem(TAB_CHATS, true);
    }

    /**
     * Notifies the ReelsFragment whether it is the currently visible tab.
     *
     * When the user navigates AWAY from Reels to the Chat tab specifically,
     * the current reel's ExoPlayer surface is transferred to a small floating
     * overlay (ReelChatDockedPlayer) so playback continues uninterrupted while
     * the user reads/sends messages.
     *
     * When the user returns to Reels, the surface is transferred back and
     * playback resumes seamlessly.
     *
     * For any other tab switch (Status, Groups, Calls), normal pause applies.
     *
     * @param isReelsTabActive true when the Reels tab is the newly selected tab.
     * @param newTabPosition   the ViewPager2 position that was just selected.
     */
    @OptIn(markerClass = UnstableApi.class)
    private void notifyReelsTabVisibility(boolean isReelsTabActive, int newTabPosition) {
        androidx.fragment.app.Fragment f = getSupportFragmentManager()
                .findFragmentByTag("f" + binding.viewPager.getAdapter().getItemId(TAB_REELS));
        if (!(f instanceof ReelsFragment)) return;
        ReelsFragment reelsFragment = (ReelsFragment) f;

        if (isReelsTabActive) {
            // ── Returning to Reels ────────────────────────────────────────────
            if (dockedPlayer != null && dockedPlayer.isActive()) {
                // Transfer ExoPlayer surface back to fragment BEFORE resuming playback.
                // collapseBack() calls originalFragmentPlayerView.setPlayer(player),
                // so when onTabResumed() → startPlayback() runs, the view is ready.
                // v11: isActive() (not isShowing()) — must still hand the surface
                // back even if the docked overlay happens to be mid cross-Activity
                // handoff (detached but session still alive) right now.
                dockedPlayer.collapseBack();
                dockedPlayer = null;
            }
            reelsFragment.onTabResumed();

        } else {
            // ── Leaving Reels ─────────────────────────────────────────────────
            boolean isGoingToChat = (newTabPosition == TAB_CHATS)
                && com.callx.app.docked.DockedPlayerSettings.isEnabled(this);

            if (isGoingToChat) {
                // ── Chat-tab docking: keep reel playing in mini overlay ────────
                // Dismiss any stale docked player first (e.g. from a previous switch)
                if (dockedPlayer != null && dockedPlayer.isActive()) {
                    dockedPlayer.dismiss(false);
                }
                dockedPlayer = new ReelChatDockedPlayer(this);
                final ReelChatDockedPlayer dockedRef = dockedPlayer;

                reelsFragment.onTabPausedForChat((player, fragmentPlayerView, thumbUrl) -> {
                    // Safety: activity might have been destroyed by the time the
                    // callback fires (synchronous in practice, but guard anyway)
                    if (isDestroyed() || isFinishing()) return;

                    dockedRef.show(player, fragmentPlayerView, thumbUrl,
                            new ReelChatDockedPlayer.Callback() {

                        @Override
                        public void onDockedPlayerDismissed() {
                            // User closed the mini-player → disable PiP then release.
                            dockedRef.disableAutoEnterPip();
                            if (dockedPlayer == dockedRef) dockedPlayer = null;
                            reelsFragment.onTabPaused();
                        }

                        @Override
                        public void onDockedPlayerExpandRequested() {
                            // Feature 2: Double-tap → collapse surface back + switch to Reels.
                            dockedRef.disableAutoEnterPip();
                            dockedRef.collapseBack();
                            if (dockedPlayer == dockedRef) dockedPlayer = null;
                            binding.viewPager.setCurrentItem(TAB_REELS, false);
                        }

                        @Override
                        public void onDockedPlayerNextReel() {
                            // Feature 4: Swipe-up → advance to next reel in mini player.
                            reelsFragment.advanceToNextForDockedPlayer(dockedRef);
                        }
                    });

                    // Feature 5 — register PiP params immediately after show().
                    // API 31+: setAutoEnterEnabled(true) handles gesture-home nav
                    //          without needing onUserLeaveHint() at all.
                    // API 26-30: params pre-registered for reliable onUserLeaveHint.
                    dockedRef.enableAutoEnterPip();
                });

            } else {
                // ── Other tab (Status, Groups, Calls): normal pause ───────────
                // If a docked player is showing (user switches from Chat → Groups),
                // dismiss it properly so we don't leak the player surface.
                if (dockedPlayer != null && dockedPlayer.isActive()) {
                    dockedPlayer.dismiss(false);
                    dockedPlayer = null;
                    // Normal pause handles player release
                }
                reelsFragment.onTabPaused();
            }
        }
    }

    /**
     * Loads the current user's contact UIDs, then attaches a ChildEventListener on
     * statuses/{contactUid} for each contact. When a new child is added (new status
     * posted), enqueues StoryNotificationWorker to show a notification kill-safely.
     */
    private void loadContactUidsForStoryNotif(String myUid, DataSnapshot snap) {
        for (DataSnapshot c : snap.getChildren()) {
                        String contactUid = c.getKey();
                        if (contactUid == null) continue;

                        // Fetch contact's name + photo for the notification
                        FirebaseUtils.getUserRef(contactUid).addListenerForSingleValueEvent(
                            new ValueEventListener() {
                                @Override public void onDataChange(DataSnapshot userSnap) {
                                    if (!badgeListenersAttached) return;
                                    String cName  = userSnap.child("name").getValue(String.class);
                                    String cThumb = userSnap.child("thumbUrl").getValue(String.class);
                                    String cPhotoFull = userSnap.child("photoUrl").getValue(String.class);
                                    String cPhoto = (cThumb != null && !cThumb.isEmpty()) ? cThumb : cPhotoFull;

                                    // Listen for new status items from this contact
                                    DatabaseReference statusRef =
                                            FirebaseUtils.getUserStatusRef(contactUid);
                                    ChildEventListener statusListener =
                                        new ChildEventListener() {
                                            @Override public void onChildAdded(
                                                    DataSnapshot statusSnap, String prev) {
                                                String sid = statusSnap.getKey();
                                                if (sid == null
                                                    || notifiedStatusIds.contains(sid)) return;
                                                // Only notify for fresh statuses (< 60 s old)
                                                Long ts = statusSnap
                                                    .child("timestamp").getValue(Long.class);
                                                if (ts == null
                                                    || System.currentTimeMillis() - ts > 60_000)
                                                    return;
                                                notifiedStatusIds.add(sid);

                                                String type = statusSnap.child("type")
                                                    .getValue(String.class);
                                                String text = statusSnap.child("text")
                                                    .getValue(String.class);
                                                String media= statusSnap.child("mediaUrl")
                                                    .getValue(String.class);

                                                StoryNotificationWorker.enqueue(
                                                    MainActivity.this,
                                                    contactUid,
                                                    cName,
                                                    cPhoto,
                                                    type != null ? type : "text",
                                                    text  != null ? text  : "",
                                                    media != null ? media : "");
                                            }
                                            @Override public void onChildChanged(DataSnapshot s, String p) {}
                                            @Override public void onChildRemoved(DataSnapshot s) {}
                                            @Override public void onChildMoved(DataSnapshot s, String p) {}
                                            @Override public void onCancelled(DatabaseError e) {}
                                        };

                                    if (!badgeListenersAttached) return;
                                    storyStatusListeners.put(statusRef, statusListener);
                                    statusRef.addChildEventListener(statusListener);
                                }
                                @Override public void onCancelled(DatabaseError e) {}
                            });
        }
    }

    private void refreshFcmToken() {
        String uid = currentUid();
        if (uid == null) return;
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            if (token == null) return;
            FirebaseDatabase.getInstance(Constants.DB_URL)
                .getReference("users").child(uid)
                .child("fcmToken").setValue(token);
        });
    }

    @Override
    public void onBackPressed() {
        // Instagram-style tab history navigation:
        // If we have more than one tab in history, pop the current and go to previous
        if (!tabHistoryStack.isEmpty()) {
            tabHistoryStack.pop();  // Remove current tab
        }
        
        if (!tabHistoryStack.isEmpty()) {
            // Navigate to the previous tab without adding to history again
            int previousTab = tabHistoryStack.peek();
            binding.viewPager.setCurrentItem(previousTab, false);
        } else {
            // No history, fall back to default behavior (close app)
            super.onBackPressed();
        }
    }

    // ── v21: Overflow menu — Delete All Chats ────────────────────────────

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(android.view.Menu menu) {
        int pos = binding.viewPager.getCurrentItem();
        // "Delete All Chats" sirf Chat tab pe visible ho
        android.view.MenuItem deleteAll = menu.findItem(R.id.action_delete_all_chats);
        if (deleteAll != null) deleteAll.setVisible(pos == TAB_CHATS);
        // "Broadcast List" sirf Chat tab pe visible ho
        android.view.MenuItem broadcast = menu.findItem(R.id.action_broadcast_list);
        if (broadcast != null) broadcast.setVisible(pos == TAB_CHATS);
        // "Performance" report sirf Chat tab pe visible ho
        android.view.MenuItem performance = menu.findItem(R.id.action_performance_report);
        if (performance != null) performance.setVisible(pos == TAB_CHATS);
        // "Ultra Advanced Diagnostics" sirf Chat tab pe visible ho
        android.view.MenuItem ultraDiag = menu.findItem(R.id.action_ultra_diagnostics);
        if (ultraDiag != null) ultraDiag.setVisible(pos == TAB_CHATS);
        // v251: X / YouTube / Games — moved here from the Chats tab quick-access
        // row, so sirf Chat tab pe hi visible ho (same as the row used to be).
        android.view.MenuItem openX = menu.findItem(R.id.action_open_x);
        if (openX != null) openX.setVisible(pos == TAB_CHATS);
        android.view.MenuItem openYoutube = menu.findItem(R.id.action_open_youtube);
        if (openYoutube != null) openYoutube.setVisible(pos == TAB_CHATS);
        android.view.MenuItem openGames = menu.findItem(R.id.action_open_games);
        if (openGames != null) openGames.setVisible(pos == TAB_CHATS);
        // "About" sirf Chat tab pe visible ho
        android.view.MenuItem about = menu.findItem(R.id.action_about);
        if (about != null) about.setVisible(pos == TAB_CHATS);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        int id = item.getItemId();

        // ── Broadcast List entry point ──────────────────────────────────────
        if (id == R.id.action_broadcast_list) {
            startActivity(new Intent(this,
                com.callx.app.broadcast.BroadcastListsActivity.class));
            return true;
        }

        if (id == R.id.action_performance_report) {
            startActivity(new Intent(this, PerformanceReportActivity.class));
            return true;
        }

        if (id == R.id.action_ultra_diagnostics) {
            startActivity(new Intent(this, UltraDiagnosticsActivity.class));
            return true;
        }

        // v251: X / YouTube / Games — moved here from the Chats tab
        // quick-access row (header_quick_access removed from
        // fragment_chats.xml). Same target Activities the row used to open.
        if (id == R.id.action_open_x) {
            try {
                startActivity(new Intent(this, com.callx.app.feed.XActivity.class));
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "X not available",
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        if (id == R.id.action_open_youtube) {
            try {
                startActivity(new Intent(this, com.callx.app.home.YouTubeActivity.class));
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "YouTube not available",
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        if (id == R.id.action_open_games) {
            try {
                startActivity(new Intent(this, com.callx.app.hub.GamesHubActivity.class));
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "Games coming soon!",
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        if (id == R.id.action_about) {
            // Kotlin AboutActivity — app module ka pehla Kotlin screen
            startActivity(new Intent(this, com.callx.app.activities.AboutActivity.class));
            return true;
        }

        if (id == R.id.action_settings) {
            startActivity(new Intent(this, AccountMenuActivity.class));
            overridePendingTransition(0, 0);
            return true;
        }

        if (id == R.id.action_payments) {
            startActivity(new Intent(this,
                    com.callx.app.payments.ui.PaymentsHomeActivity.class));
            overridePendingTransition(0, 0);
            return true;
        }

        if (id == R.id.action_delete_all_chats) {
            // ChatsFragment ko reflect karo aur confirmDeleteAll() call karo
            try {
                androidx.fragment.app.Fragment frag =
                    getSupportFragmentManager()
                        .findFragmentByTag("f" + binding.viewPager.getAdapter().getItemId(TAB_CHATS));
                if (frag != null) {
                    java.lang.reflect.Method m = frag.getClass().getMethod("confirmDeleteAll");
                    m.invoke(frag);
                }
            } catch (Exception e) {
                android.widget.Toast.makeText(this,
                    "Delete All not available", android.widget.Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
