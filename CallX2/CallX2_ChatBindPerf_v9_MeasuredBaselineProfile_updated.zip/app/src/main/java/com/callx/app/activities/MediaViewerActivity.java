package com.callx.app.activities;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.github.chrisbanes.photoview.PhotoView;
import com.callx.app.databinding.ActivityMediaViewerBinding;
import com.callx.app.utils.FirebaseUtils;
import com.callx.app.utils.MediaCache;
import com.callx.app.utils.MediaSwipeReplyCloseHelper;
import com.callx.app.utils.MediaViewerSourceRect;
import com.callx.app.utils.PhotoViewZoomUtils;
import com.google.firebase.database.DatabaseReference;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MediaViewerActivity — Full-screen media viewer.
 *
 * Features:
 *  • Pinch-to-zoom for images (PhotoView)
 *  • Tap image → toggle top bar (WhatsApp style)
 *  • Swipe down gesture → dismiss (via PhotoView scale + back)
 *  • Video with ExoPlayer (cache-first)
 *  • Share button in top bar
 *  • Video playback presence — while a video opened FROM a chat is actually
 *    playing, publishes chatPlayback/{chatId}/{uid}=messageId (same node
 *    ChatPlaybackPresenceController watches) so the partner's chat list
 *    shows a live "▶ watching…" badge on that bubble. No-op if this viewer
 *    was opened without chatId/messageId extras (e.g. from a non-chat caller).
 */
public class MediaViewerActivity extends AppCompatActivity {

    private ActivityMediaViewerBinding binding;
    private ExoPlayer player;
    private boolean uiVisible = true;
    private String sharedUrl;

    // BUG FIX — top-bar tap-to-toggle reliability (see dispatchTouchEvent's
    // comment for the full root cause). A single GestureDetector, fed every
    // touch event at the dispatch level, is now the ONE place toggleUI()
    // gets called from — replaces the old per-view wiring (PhotoView's
    // setOnViewTapListener, player's setOnClickListener, the gallery
    // adapter's tap callback), all of which routed through mechanisms that
    // could silently eat a second, close-together tap instead of toggling.
    private GestureDetector tapToggleDetector;

    // Local-first single-item mode (see onCreate doc + LocalMediaAvailability).
    private String singleItemLocalPath;
    // BUG FIX (Voice Caption on Photo — image can't be opened after send):
    // a Media-E2E image's `url` extra is CIPHERTEXT (resource_type=raw).
    // Previously this activity had no way to decrypt it at all — only the
    // sender's own singleItemLocalPath fallback ever rendered correctly.
    // showMediaActionSheet now derives the full-res subkey and passes it
    // here (see MessagePagingAdapter#sheetMediaKeyB64) so a receiver's
    // View/Edit actually decrypts instead of trying to decode raw
    // ciphertext bytes as an image.
    private byte[] mediaDecryptKey;

    // ── Gallery mode (swipeable grouped-media viewer) ────────────────────
    private GalleryPagerAdapter galleryAdapter;
    private List<Map<String, Object>> galleryItems;
    private int galleryActivePos = -1;

    // #2 Windowed loading — chatId this gallery belongs to (null when
    // opened via the single-item/single-group fallback path, in which
    // case none of the edge-expansion below ever fires), the global index
    // of galleryItems.get(0) within the chat's full media list, the
    // chat's total media count, and in-flight guards so a fast swipe
    // can't fire two overlapping loads off the same edge.
    private String galleryChatId;
    private int galleryWindowStart;
    private int galleryTotalCount;
    private boolean galleryLoadingBefore;
    private boolean galleryLoadingAfter;
    private static final int GALLERY_EDGE_THRESHOLD = 10;
    private static final java.util.concurrent.ExecutorService GALLERY_WINDOW_EXECUTOR =
            java.util.concurrent.Executors.newSingleThreadExecutor();

    // ── Swipe-down-to-close / swipe-up-to-reply (single + gallery mode) ──
    // Common core helper — works for single-media mode now too, not just
    // the grouped-media gallery.
    private String replyChatId;
    private String replyMessageId;
    private MediaSwipeReplyCloseHelper swipeHelper;

    // ── Telegram-style open/close animation ───────────────────────────
    // The tapped chat-bubble thumbnail's on-screen rect (null if the
    // caller didn't supply one — falls back to the plain fade/translate
    // close everywhere below). `activeDragView` is whichever content view
    // is actually on screen for the current mode (ivFull / player /
    // mediaPager) — set once in setupSwipeHelper() and reused by both the
    // open and close animations.
    private Rect sourceRect;
    private View activeDragView;

    // ── Video playback presence (see class doc above) ───────────────────
    private String playbackChatId;
    private String playbackMessageId;
    private DatabaseReference playbackRef;
    private boolean playbackPublished = false;

    // ── "Edit" action (WhatsApp-style: view a photo → edit → resend) ────
    private ActivityResultLauncher<Intent> mediaEditLauncher;

    // Whether the current user sent this message — set from the
    // "isOwnMessage" intent extra (see MessagePagingAdapter#openChatMediaViewer).
    // Gates the "Delete" row in showMoreOptionsMenu(), same as the old
    // pre-viewer bottom sheet's own own-message guard on its Delete row.
    private boolean isOwnMessage;

    // ── Feature: Voice Caption on Photo — fullscreen viewer ──────────────
    // Reuses the exact same play-badge drawables the chat bubble uses
    // (bg_voice_duration_pill / bg_voice_play_badge / ic_play / ic_pause —
    // see fl_voice_on_image_viewer in activity_media_viewer.xml) and the
    // same local-preview player class the voice-recorder's pause/preview
    // screen uses (VoicePreviewPlayer) — no new playback engine needed,
    // this is just a decrypt-then-play over a remote/E2E URL instead of a
    // local temp file. Only ever non-null in single-image mode; the
    // grouped gallery has its own per-page message and isn't wired up yet
    // (see showMediaActionSheet's hasVoiceCaption gate).
    private String voiceCaptionUrl;
    private byte[] voiceCaptionKey;
    private boolean voiceCaptionFetching = false;
    private com.callx.app.conversation.controllers.VoicePreviewPlayer voiceCaptionPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen immersive
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        // MEDIA_VIEWER_TELEGRAM_CLOSE — belt-and-suspenders alongside the
        // Theme.CallX.Fullscreen.Translucent manifest theme: makes sure the
        // Window itself paints nothing behind binding.getRoot(), so the
        // live-drag scrim fade in MediaSwipeReplyCloseHelper actually
        // reveals the calling screen (chat) instead of an opaque backdrop.
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        binding = ActivityMediaViewerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        hideSystemUI();

        // See tapToggleDetector's field doc + dispatchTouchEvent for why
        // this replaces the old per-view toggle wiring. onSingleTapUp fires
        // the instant the finger lifts, with none of the double-tap
        // disambiguation delay PhotoView's own tap listener imposes — and
        // never consumes the event, so pinch/double-tap-zoom underneath is
        // untouched.
        tapToggleDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapUp(MotionEvent e) {
                toggleUI();
                return false;
            }
        });

        String url  = getIntent().getStringExtra("url");
        String type = getIntent().getStringExtra("type");
        sharedUrl   = url;

        // Telegram-style open/close animation — see field doc above.
        sourceRect = MediaViewerSourceRect.read(getIntent());

        // WhatsApp-style local-first: when the chat bubble passed along the
        // original local file/content Uri (still present on the device),
        // render straight from it here — full quality, no network — instead
        // of the (possibly compressed) remote mediaUrl. Falls back to `url`
        // automatically if the file's gone (see LocalMediaAvailability).
        singleItemLocalPath = getIntent().getStringExtra("localPath");

        // Media E2E — see mediaDecryptKey field doc above.
        String mediaKeyB64 = getIntent().getStringExtra("mediaKeyB64");
        if (mediaKeyB64 != null && !mediaKeyB64.isEmpty()) {
            try {
                mediaDecryptKey = android.util.Base64.decode(mediaKeyB64, android.util.Base64.NO_WRAP);
            } catch (Exception ignored) {
                mediaDecryptKey = null;
            }
        }

        // Optional — only present when opened from a grouped-media message
        // tap. Used to send a swipe-up "reply" request back to the chat
        // screen via GalleryReplyBridge. Both null disables that gesture's
        // action (the swipe-down-to-close part always works regardless).
        replyChatId    = getIntent().getStringExtra("chatId");
        replyMessageId = getIntent().getStringExtra("messageId");

        // Optional — only present when opened from a chat bubble. Both
        // null is the normal/expected case for other callers (status
        // viewer, all-media grid, etc.) and simply disables presence.
        playbackChatId    = getIntent().getStringExtra("chatId");
        playbackMessageId = getIntent().getStringExtra("messageId");
        isOwnMessage      = getIntent().getBooleanExtra("isOwnMessage", false);

        // Close button
        binding.btnClose.setOnClickListener(v -> closeViewer());

        // Share button
        binding.btnShare.setOnClickListener(v -> shareMedia(sharedUrl));

        // #3 fix — Save to gallery (previously only Share was available)
        binding.btnSave.setOnClickListener(v -> saveCurrentToGallery());

        // #4/#2 fix — More options now opens a real menu (per-item delete/
        // star/caption-edit for grouped media, or just Save+Share fallback
        // for single-media mode) instead of being a dead placeholder.
        binding.btnMoreOptions.setOnClickListener(v -> showMoreOptionsMenu());

        // "Edit" — WhatsApp-style: view a photo OR video in the chat, tweak
        // it in the same full-screen editor the attach sheet uses, and
        // resend it as a new message (see GalleryEditBridge for the handoff
        // back to ChatActivity / GroupChatActivity).
        mediaEditLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) return;
                    ArrayList<String> resultUris = result.getData().getStringArrayListExtra(
                            com.callx.app.conversation.controllers.MediaEditActivity.RESULT_URIS);
                    if (resultUris == null || resultUris.isEmpty()) return;
                    String caption = result.getData().getStringExtra(
                            com.callx.app.conversation.controllers.MediaEditActivity.RESULT_CAPTION);
                    boolean editedHD = result.getData().getBooleanExtra(
                            com.callx.app.conversation.controllers.MediaEditActivity.RESULT_HD, false);
                    if (replyChatId != null) {
                        com.callx.app.conversation.GalleryEditBridge.requestSend(
                                replyChatId, resultUris.get(0), caption, editedHD);
                    }
                    finish();
                    overridePendingTransition(0, 0);
                });
        binding.btnEdit.setOnClickListener(v -> onEditClicked());

        // #1 fix — selection-mode toolbar wiring
        binding.btnSelectClose.setOnClickListener(v -> exitSelectMode());
        binding.btnSelectForward.setOnClickListener(v -> forwardSelection());
        binding.btnSelectDelete.setOnClickListener(v -> deleteSelection());
        binding.btnSelectStar.setOnClickListener(v -> starSelection());

        // WhatsApp-style "Edit" shortcut — set by showImageActionSheet's Edit
        // option so the viewer jumps straight into MediaEditActivity instead
        // of making the user tap the pencil a second time once the viewer is
        // open. Works for video too now — MediaEditActivity fully supports
        // video (trim/stickers/text/draw, baked into the actual video on send).
        boolean autoEdit = getIntent().getBooleanExtra("autoEdit", false);

        // #2 Windowed loading — see ChatMediaGalleryBuilder: MessagePagingAdapter
        // only hands us a ±WINDOW_RADIUS slice, plus where that slice sits
        // within the chat's full media list so we can grow it on demand.
        galleryChatId = getIntent().getStringExtra("galleryChatId");
        galleryWindowStart = getIntent().getIntExtra("galleryWindowStart", 0);
        galleryTotalCount = getIntent().getIntExtra("galleryTotalCount", 0);

        String mediaItemsJson = getIntent().getStringExtra("mediaItemsJson");
        // #5 Serialization skip: the chat-wide gallery path now hands its
        // list across via GalleryIntentHolder (no JSON string on the
        // Intent at all) — check that first. mediaItemsJson stays as the
        // path for the smaller grouped-media-tap fallback, which already
        // had a plain JSON string sitting in Room and never needed a
        // separate serialize step.
        int galleryToken = getIntent().getIntExtra("galleryItemsToken", -1);
        List<Map<String, Object>> tokenItems = galleryToken >= 0
                ? com.callx.app.utils.GalleryIntentHolder.take(galleryToken) : null;
        if (tokenItems != null && !tokenItems.isEmpty()) {
            setupGalleryMode(tokenItems, getIntent().getIntExtra("startIndex", 0));
            if (autoEdit) {
                binding.getRoot().post(this::onEditClicked);
            }
            return;
        }
        if (mediaItemsJson != null && !mediaItemsJson.isEmpty()) {
            setupGalleryMode(mediaItemsJson, getIntent().getIntExtra("startIndex", 0));
            if (autoEdit) {
                binding.getRoot().post(this::onEditClicked);
            }
            return;
        }

        if (url == null) { finish(); return; }

        // WhatsApp-style GIF delivery: a "gif" message whose mediaUrl is
        // actually a small mp4 rendition (see ChatGifPickerActivity's class
        // doc + Message#gifIsVideo) plays through the same ExoPlayer path
        // as a real video, just looped and muted with no scrub controls —
        // that's the whole point of sending an mp4 instead of a raw .gif.
        // A "gif" message without this flag (old raw-.gif sends, or a Tenor
        // result that genuinely had no video rendition) falls through to
        // the plain-image branch below exactly as before.
        boolean gifIsVideo = "gif".equals(type) && getIntent().getBooleanExtra("gifIsVideo", false);

        if ("video".equals(type) || gifIsVideo) {
            binding.player.setVisibility(View.VISIBLE);
            binding.ivFull.setVisibility(View.GONE);
            binding.btnEdit.setVisibility(gifIsVideo ? View.GONE : View.VISIBLE);
            playVideo(url, singleItemLocalPath, gifIsVideo);
            if (autoEdit && !gifIsVideo) {
                binding.getRoot().post(this::onEditClicked);
            }

            if (gifIsVideo) {
                // No scrub bar/play-pause chrome for a GIF — it just loops
                // silently, same as WhatsApp. Tap still toggles the top bar.
                binding.player.setUseController(false);
            }
            // Tap-to-toggle for video now goes through tapToggleDetector in
            // dispatchTouchEvent (see its doc) instead of a click listener
            // here — no separate wiring needed.

            // Video isn't zoomable, so no pinch-zoom guard needed here.
            setupSwipeHelper(binding.player, null, null);
            animateOpenFromSource(binding.player, sourceRect);

        } else {
            binding.ivFull.setVisibility(View.VISIBLE);
            binding.player.setVisibility(View.GONE);
            binding.btnEdit.setVisibility(View.VISIBLE);
            if (autoEdit) {
                binding.getRoot().post(this::onEditClicked);
            }

            String thumbUrl = getIntent().getStringExtra("thumbUrl");
            loadImageProgressive(url, thumbUrl, singleItemLocalPath);
            setupVoiceCaptionOverlay();

            // Tap-to-toggle for the image now goes through tapToggleDetector
            // in dispatchTouchEvent (see its doc) instead of PhotoView's own
            // setOnViewTapListener — that callback is gated behind Android's
            // double-tap disambiguation delay (~300ms, to tell it apart from
            // double-tap-to-zoom), so a second deliberate tap landing inside
            // that window could get swallowed as a double-tap instead of
            // toggling the bar back on.

            // #single-media fix — swipe-up-to-reply / swipe-down-to-close
            // now works here too (previously gallery-mode only), guarded
            // against pinch-zoom via the shared PhotoViewZoomUtils check.
            setupSwipeHelper(binding.ivFull, null,
                    () -> PhotoViewZoomUtils.isZoomedIn(binding.ivFull));
            animateOpenFromSource(binding.ivFull, sourceRect);
        }
    }

    // ── Feature: Voice Caption on Photo — fullscreen viewer ──────────────
    /** Shows the play-badge overlay iff this image carries a "voiceUrl"
     *  intent extra (see MessagePagingAdapter#showMediaActionSheet's
     *  hasVoiceCaption gate) — a plain image with no voice note leaves
     *  fl_voice_on_image_viewer gone, exactly as it starts in the XML. */
    private void setupVoiceCaptionOverlay() {
        voiceCaptionUrl = getIntent().getStringExtra("voiceUrl");
        if (voiceCaptionUrl == null || voiceCaptionUrl.isEmpty()) return;
        String durationText = getIntent().getStringExtra("voiceDurationText");
        String voiceKeyB64 = getIntent().getStringExtra("voiceKeyB64");
        if (voiceKeyB64 != null && !voiceKeyB64.isEmpty()) {
            try {
                voiceCaptionKey = android.util.Base64.decode(voiceKeyB64, android.util.Base64.NO_WRAP);
            } catch (Exception ignored) {
                voiceCaptionKey = null;
            }
        }
        binding.flVoiceOnImageViewer.setVisibility(View.VISIBLE);
        if (durationText != null) {
            binding.tvVoiceDurationOnImageViewer.setText(durationText);
        }
        binding.flVoiceOnImageViewer.setOnClickListener(v -> toggleVoiceCaptionPlayback());
    }

    /** Tap handler for fl_voice_on_image_viewer — decrypts/downloads (via
     *  the same MediaCache the chat bubble's voice caption and this
     *  viewer's own image already use) on first tap, then just play()/
     *  pause() the already-prepared clip on every tap after that. */
    private void toggleVoiceCaptionPlayback() {
        if (voiceCaptionUrl == null) return;
        if (voiceCaptionPlayer != null && voiceCaptionPlayer.isPrepared()) {
            if (voiceCaptionPlayer.isPlaying()) {
                voiceCaptionPlayer.pause();
                binding.ivVoicePlayOnImageViewer.setImageResource(com.callx.app.R.drawable.ic_play);
            } else {
                voiceCaptionPlayer.play();
                binding.ivVoicePlayOnImageViewer.setImageResource(com.callx.app.R.drawable.ic_pause);
            }
            return;
        }
        if (voiceCaptionFetching) return; // already fetching — ignore repeat taps
        voiceCaptionFetching = true;
        MediaCache.Callback cb = new MediaCache.Callback() {
            @Override public void onReady(File file) {
                voiceCaptionFetching = false;
                if (isFinishing() || isDestroyed()) return;
                startVoiceCaptionPlayback(file.getAbsolutePath());
            }
            @Override public void onError(String reason) {
                voiceCaptionFetching = false;
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(MediaViewerActivity.this,
                        "Couldn't play voice note: " + reason, Toast.LENGTH_SHORT).show();
            }
        };
        if (voiceCaptionKey != null) {
            MediaCache.get(this, voiceCaptionUrl, voiceCaptionKey, cb);
        } else {
            MediaCache.get(this, voiceCaptionUrl, cb);
        }
    }

    private void startVoiceCaptionPlayback(String path) {
        if (voiceCaptionPlayer == null) {
            voiceCaptionPlayer = new com.callx.app.conversation.controllers.VoicePreviewPlayer();
            voiceCaptionPlayer.setListener(new com.callx.app.conversation.controllers.VoicePreviewPlayer.Listener() {
                @Override public void onProgress(float progress0to1) {}
                @Override public void onPlaybackFinished() {
                    runOnUiThread(() -> binding.ivVoicePlayOnImageViewer
                            .setImageResource(com.callx.app.R.drawable.ic_play));
                }
            });
        }
        if (voiceCaptionPlayer.prepare(path)) {
            voiceCaptionPlayer.play();
            binding.ivVoicePlayOnImageViewer.setImageResource(com.callx.app.R.drawable.ic_pause);
        }
    }

    /**
     * Common wiring for MediaSwipeReplyCloseHelper — used by both
     * single-media mode (image/video) and gallery mode.
     *
     * @param dragView            view that translates/fades during the drag
     * @param viewToCancelOnDrag  horizontal-scrolling view to cancel once a
     *                            vertical drag is confirmed (ViewPager2 in
     *                            gallery mode, null in single-media mode)
     * @param zoomedStateProvider guard against pinch-zoom conflicts, null
     *                            when the content isn't zoomable (video)
     */
    private void setupSwipeHelper(View dragView, View viewToCancelOnDrag,
                                   MediaSwipeReplyCloseHelper.ZoomedStateProvider zoomedStateProvider) {
        activeDragView = dragView;
        swipeHelper = new MediaSwipeReplyCloseHelper(
                this, dragView, binding.getRoot(), viewToCancelOnDrag, zoomedStateProvider,
                new MediaSwipeReplyCloseHelper.Callback() {
                    @Override public void onSwipeUpReply() {
                        // Retired — MediaSwipeReplyCloseHelper now routes
                        // BOTH swipe-up and swipe-down to onSwipeDownClose()
                        // (see that class), so this never actually fires
                        // anymore. Left in place only because the interface
                        // still declares it.
                    }
                    @Override public void onSwipeDownClose(float velocityY) {
                        closeViewer(velocityY);
                    }
                });
        // Top bar / select-toolbar / page-counter now fade LIVE with the
        // drag itself (not just once release triggers the close animation)
        // — see MediaSwipeReplyCloseHelper's class doc.
        swipeHelper.setChromeViews(binding.llTopBar, binding.llSelectToolbar, binding.tvPageCounter);
    }

    /** Bubble media corner radius (MessageBubbleCanvasView#MEDIA_CORNER_RADIUS_DP) — kept in sync so the
     *  docking animation's final rounding matches the actual chat-bubble thumbnail exactly. */
    private static final float BUBBLE_MEDIA_CORNER_RADIUS_DP = 18f;
    /** Base duration for the dock-to-source / expand-from-source animation, before velocity adjusts it. */
    private static final long DOCK_ANIM_BASE_MS = 300L;
    private static final long DOCK_ANIM_MIN_MS = 170L;
    // Material "emphasized" easing — fast out, gentle settle. Reads far more
    // premium than a plain DecelerateInterpolator for a docking/undocking
    // motion like this.
    private static final android.view.animation.Interpolator DOCK_EASE =
            new android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f);

    /**
     * Closes the viewer. If a source thumbnail rect was supplied (see
     * MediaViewerSourceRect), animates the visible content shrinking back
     * into that exact spot — Telegram-style "chipakna" — instead of just
     * cutting away. Safe no-op fallback (plain instant close) when there's
     * no rect or no content view to animate.
     *
     * @param velocityY signed px/sec from the swipe gesture that triggered
     *                  this close (0 for close-button/back-press), used to
     *                  shorten the dock animation on a fast fling so it
     *                  reads as a continuation of the throw, not a reset.
     */
    private void closeViewer(float velocityY) {
        if (sourceRect != null && activeDragView != null && !isFinishing()) {
            animateCloseToSource(sourceRect, velocityY);
        } else {
            finishNow();
        }
    }

    private void closeViewer() {
        closeViewer(0f);
    }

    private void finishNow() {
        finish();
        overridePendingTransition(0, 0);
    }

    /**
     * Shrinks+moves `activeDragView` from its current on-screen spot (which
     * may already be mid-drag — scaled/translated/rounded by
     * MediaSwipeReplyCloseHelper's live gesture) into `target`, then
     * finishes. Everything — position, scale, corner radius, content alpha,
     * chrome alpha, background scrim — is driven off a single ValueAnimator
     * fraction so nothing can drift out of sync with anything else.
     */
    private void animateCloseToSource(Rect target, float velocityY) {
        final View v = activeDragView;
        v.animate().cancel();
        // PERF (ultra-advanced pass): same GPU-layer caching trick already
        // used by the avatar-zoom dock animation (DialogFullscreenHelper) —
        // this animator drives translation+scale+alpha+outline-clip on `v`
        // together every frame, which without a hardware layer means a full
        // re-draw (and, for video, a full re-composite) of the content each
        // frame. Caching it once up front turns every subsequent frame into
        // a cheap GPU-composited transform instead. Matters most for the
        // close-button/back-press/tap-outside paths, where no swipe drag
        // happened first — in that case `v` was never layered by
        // MediaSwipeReplyCloseHelper's live-drag gesture, so without this it
        // would run completely un-cached for the whole animation. Released
        // in onAnimationEnd, right before the Activity finishes anyway.
        if (v.getLayerType() != View.LAYER_TYPE_HARDWARE) {
            v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        float startScaleX = v.getScaleX();
        float startScaleY = v.getScaleY();
        float curCenterX = loc[0] + (v.getWidth() * startScaleX) / 2f;
        float curCenterY = loc[1] + (v.getHeight() * startScaleY) / 2f;
        float targetCenterX = target.left + target.width() / 2f;
        float targetCenterY = target.top + target.height() / 2f;

        float startTx = v.getTranslationX();
        float startTy = v.getTranslationY();
        float endTx = startTx + (targetCenterX - curCenterX);
        float endTy = startTy + (targetCenterY - curCenterY);
        float endScaleX = v.getWidth()  > 0 ? target.width()  / (float) v.getWidth()  : 1f;
        float endScaleY = v.getHeight() > 0 ? target.height() / (float) v.getHeight() : 1f;

        float startAlpha = v.getAlpha();
        float startBgAlpha = Color.alpha(currentBgAlphaOr(255));
        float startChromeAlpha = binding.llTopBar.getAlpha();
        float startOnScreenRadius = swipeHelper != null ? swipeHelper.getCurrentOnScreenRadiusPx() : 0f;
        float endOnScreenRadius = dp(BUBBLE_MEDIA_CORNER_RADIUS_DP);

        // A fast fling should feel like the photo is being THROWN into the
        // thumbnail slot — shorten the animation proportionally instead of
        // always running the same fixed duration regardless of how hard the
        // user flicked.
        long duration = velocityAdjustedDuration(velocityY);

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(duration);
        anim.setInterpolator(DOCK_EASE);
        anim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            v.setTranslationX(lerp(startTx, endTx, t));
            v.setTranslationY(lerp(startTy, endTy, t));
            float sx = lerp(startScaleX, endScaleX, t);
            float sy = lerp(startScaleY, endScaleY, t);
            v.setScaleX(sx);
            v.setScaleY(sy);
            v.setAlpha(lerp(startAlpha, 1f, t));
            if (swipeHelper != null) {
                swipeHelper.setLiveCornerRadius(lerp(startOnScreenRadius, endOnScreenRadius, t), sx);
            }
            int bgAlpha = Math.round(lerp(startBgAlpha, 0f, t));
            binding.getRoot().setBackgroundColor(Color.argb(bgAlpha, 0, 0, 0));
            float chromeAlpha = lerp(startChromeAlpha, 0f, t);
            binding.llTopBar.setAlpha(chromeAlpha);
            binding.llSelectToolbar.setAlpha(chromeAlpha);
            binding.tvPageCounter.setAlpha(chromeAlpha);
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                v.setLayerType(View.LAYER_TYPE_NONE, null);
                finishNow();
            }
        });
        anim.start();
    }

    /** Starts `v` scaled/translated/rounded to look like it's still `source`, then docks up to full-screen. */
    private void animateOpenFromSource(View v, Rect source) {
        if (source == null || v == null) return;
        v.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (v.getWidth() == 0 || v.getHeight() == 0) return;
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            float targetCenterX = loc[0] + v.getWidth() / 2f;
            float targetCenterY = loc[1] + v.getHeight() / 2f;
            float srcCenterX = source.left + source.width() / 2f;
            float srcCenterY = source.top + source.height() / 2f;

            float startScaleX = source.width()  / (float) v.getWidth();
            float startScaleY = source.height() / (float) v.getHeight();
            float startTx = srcCenterX - targetCenterX;
            float startTy = srcCenterY - targetCenterY;
            float startOnScreenRadius = dp(BUBBLE_MEDIA_CORNER_RADIUS_DP);

            v.setScaleX(startScaleX);
            v.setScaleY(startScaleY);
            v.setTranslationX(startTx);
            v.setTranslationY(startTy);
            if (swipeHelper != null) swipeHelper.setLiveCornerRadius(startOnScreenRadius, startScaleX);
            // PERF (ultra-advanced pass): see animateCloseToSource's identical
            // comment — cache `v` into a GPU layer for the open animation's
            // duration too, released once it settles into its idle state.
            if (v.getLayerType() != View.LAYER_TYPE_HARDWARE) {
                v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            }

            binding.getRoot().setBackgroundColor(Color.TRANSPARENT);
            binding.llTopBar.setAlpha(0f);
            binding.tvPageCounter.setAlpha(0f);

            ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(DOCK_ANIM_BASE_MS);
            anim.setInterpolator(DOCK_EASE);
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    // Open dock finished — view is now idle (pinch-zoomable /
                    // paging) until the next drag/close, so release the GPU
                    // layer; the swipe helper re-acquires it itself the
                    // moment a new drag starts.
                    v.setLayerType(View.LAYER_TYPE_NONE, null);
                }
            });
            anim.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                v.setTranslationX(lerp(startTx, 0f, t));
                v.setTranslationY(lerp(startTy, 0f, t));
                float sx = lerp(startScaleX, 1f, t);
                float sy = lerp(startScaleY, 1f, t);
                v.setScaleX(sx);
                v.setScaleY(sy);
                if (swipeHelper != null) {
                    swipeHelper.setLiveCornerRadius(lerp(startOnScreenRadius, 0f, t), sx);
                }
                int bgAlpha = Math.round(lerp(0f, 255f, t));
                binding.getRoot().setBackgroundColor(Color.argb(bgAlpha, 0, 0, 0));
            });
            anim.start();
            // Chrome eases in slightly after the content starts moving —
            // matches the reference Telegram timing (chrome never leads).
            binding.llTopBar.animate().alpha(1f).setDuration(220).setStartDelay(90).start();
        });
    }

    private long velocityAdjustedDuration(float velocityY) {
        float speedDpPerSec = Math.abs(velocityY) / getResources().getDisplayMetrics().density;
        // 0 dp/s → base duration; ~2500 dp/s (a hard flick) → floor duration.
        float speedFactor = Math.min(1f, speedDpPerSec / 2500f);
        long duration = Math.round(lerp(DOCK_ANIM_BASE_MS, DOCK_ANIM_MIN_MS, speedFactor));
        return Math.max(DOCK_ANIM_MIN_MS, duration);
    }

    private static float lerp(float start, float end, float t) {
        return start + (end - start) * t;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    /** Best-effort read of the root's current background alpha (falls back to `fallback` if not a solid color). */
    private int currentBgAlphaOr(int fallback) {
        android.graphics.drawable.Drawable bg = binding.getRoot().getBackground();
        if (bg instanceof android.graphics.drawable.ColorDrawable) {
            return Color.alpha(((android.graphics.drawable.ColorDrawable) bg).getColor());
        }
        return fallback;
    }

    /**
     * PERF (aggressive preload window): fires MediaCache.get() for the
     * immediate previous/next gallery items while the current page is
     * still displaying. MediaCache already de-dupes/no-ops on an
     * already-cached or already-in-flight URL, so this is a cheap,
     * fire-and-forget background-thread warm-up — by the time the user
     * actually swipes, the neighbor's file is very likely already on disk,
     * so bindVideo()/Glide.load() resolve instantly instead of kicking off
     * a fresh network fetch at swipe time.
     */
    private void prefetchAdjacentMedia(int position) {
        if (galleryItems == null) return;
        for (int neighbor : new int[]{position - 1, position + 1}) {
            if (neighbor < 0 || neighbor >= galleryItems.size()) continue;
            // BUG FIX (swipe auto-download): only warm neighbours that would load
            // on their own anyway (sent by me / user-approved). A RECEIVED item the
            // user hasn't downloaded from the chat bubble must NOT be fetched here —
            // its page shows a tap-to-download pill instead (see GalleryPagerAdapter).
            if (galleryAdapter == null || !galleryAdapter.mayPrefetch(this, neighbor)) continue;
            String url = safeStr(galleryItems.get(neighbor).get("url"));
            if (url.isEmpty() || MediaCache.getCached(this, url) != null) continue;
            MediaCache.get(this, url, new MediaCache.Callback() {
                @Override public void onReady(File file) {}
                @Override public void onError(String reason) {}
            });
        }
        // PERF (video prefetch — conservative half of the ask): reach one
        // page further, position±2, for VIDEO items only, with a plain
        // file-level MediaCache.get() — same de-duped/no-op-if-cached
        // warm-up as above, nothing ExoPlayer-related.
        //
        // Deliberately NOT pre-building an extra ExoPlayer at position±2:
        // with offscreenPageLimit=1, the immediate neighbor (±1) already
        // gets its ExoPlayer built+prepare()'d as soon as its page is bound
        // (see GalleryPagerAdapter.bindVideo) — so it's already silently
        // buffering before the user swipes there, which is the main win.
        // Extending real player pre-buffering to ±2 would mean holding a
        // 3rd ExoPlayer beyond ExoPlayerPool's MAX_POOL_SIZE=2, plus needing
        // teardown handling for "user swiped back before reaching it" — real
        // risk for a page that's still two swipes away, so left out.
        for (int neighbor : new int[]{position - 2, position + 2}) {
            if (neighbor < 0 || neighbor >= galleryItems.size()) continue;
            if (galleryAdapter == null || !galleryAdapter.mayPrefetch(this, neighbor)) continue; // same gate as ±1 above
            Map<String, Object> item = galleryItems.get(neighbor);
            if (!"video".equals(item.get("mediaType"))) continue;
            String url = safeStr(item.get("url"));
            if (url.isEmpty() || MediaCache.getCached(this, url) != null) continue;
            MediaCache.get(this, url, new MediaCache.Callback() {
                @Override public void onReady(File file) {}
                @Override public void onError(String reason) {}
            });
        }
    }

    // ── Gallery mode — swipeable multi-image/video viewer ────────────────
    private void setupGalleryMode(String json, int startIndex) {
        setupGalleryMode(parseMediaItems(json), startIndex);
    }

    private void setupGalleryMode(List<Map<String, Object>> items, int startIndex) {
        galleryItems = items;
        if (galleryItems.isEmpty()) { finish(); return; }
        int start = Math.max(0, Math.min(startIndex, galleryItems.size() - 1));

        binding.ivFull.setVisibility(View.GONE);
        binding.player.setVisibility(View.GONE);
        binding.mediaPager.setVisibility(View.VISIBLE);
        binding.tvPageCounter.setVisibility(galleryItems.size() > 1 ? View.VISIBLE : View.GONE);

        galleryAdapter = new GalleryPagerAdapter(galleryItems, this::toggleUI);
        // BUG FIX (swipe auto-download): tell the adapter who "me" is so it can leave
        // received-but-not-downloaded pages as tap-to-download instead of fetching them.
        // The item the user opened the viewer on was explicitly chosen (they tapped it),
        // so it always loads; everything reached by swiping only loads if it's sent by me,
        // already on the device, or the user taps its Download pill.
        galleryAdapter.setCurrentUid(FirebaseUtils.getCurrentUid());
        galleryAdapter.setDefaultSent(isOwnMessage);
        galleryAdapter.allowLoad(safeStr(galleryItems.get(start).get("url")));
        galleryAdapter.setLongPressListener(pos -> enterSelectMode(pos));
        galleryAdapter.setSelectionToggleListener(pos -> updateSelectToolbar());
        // PERF (priority tuning): set before setAdapter() so the very first
        // bind already knows which page is active.
        galleryAdapter.setActivePosition(start);
        binding.mediaPager.setAdapter(galleryAdapter);
        binding.mediaPager.setCurrentItem(start, false);
        // PERF (aggressive preload window): keep exactly one page ahead/behind
        // alive in ViewPager2's own view cache — the sweet spot for a swipe
        // gallery. Higher wastes memory on pages the user may never reach;
        // 0 makes ViewPager2 tear down/rebuild every neighbor on each swipe.
        binding.mediaPager.setOffscreenPageLimit(1);
        updatePageCounter(start);
        sharedUrl = safeStr(galleryItems.get(start).get("url"));
        binding.btnEdit.setVisibility(View.VISIBLE);
        prefetchAdjacentMedia(start);

        binding.mediaPager.registerOnPageChangeCallback(new androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int position) {
                pauseAllExcept(position);
                galleryActivePos = position;
                galleryAdapter.setActivePosition(position);
                sharedUrl = safeStr(galleryItems.get(position).get("url"));
                updatePageCounter(position);
                binding.btnEdit.setVisibility(View.VISIBLE);
                prefetchAdjacentMedia(position);
                maybeGrowGalleryWindow(position);
            }
        });
        galleryActivePos = start;
        maybeGrowGalleryWindow(start);
        // Slight delay so RecyclerView has a bound ViewHolder to play on first open
        binding.mediaPager.post(() -> pauseAllExcept(start));

        // Same shared helper as single-media mode — swipe up to reply
        // (quoting the specific tapped item via galleryActivePos), swipe
        // down to close. ViewPager2 is passed as viewToCancelOnDrag so it
        // stops trying to interpret the vertical drag as a horizontal page
        // swipe once we've claimed it.
        setupSwipeHelper(binding.mediaPager, binding.mediaPager,
                () -> PhotoViewZoomUtils.isZoomedIn(currentGalleryPhotoView()));
        // Only meaningful when the gallery opened directly on the tapped
        // item (grouped-media grid tap) — sourceRect corresponds to that
        // one cell, so the animation only looks right for the page that's
        // actually showing at `start`. Fine either way: it's a no-op when
        // sourceRect is null.
        animateOpenFromSource(binding.mediaPager, sourceRect);
    }

    /**
     * #2 Windowed loading: called on every page settle. When the user has
     * paged within {@link #GALLERY_EDGE_THRESHOLD} pages of either end of
     * the current window — and the chat's full media list (still sitting
     * in ChatMediaGalleryBuilder's cache) has more on that side — pulls
     * the next chunk and appends/prepends it to {@link #galleryItems},
     * completely off the DB (it's an in-memory slice of what's already
     * cached from this chat's first-open query).
     */
    private void maybeGrowGalleryWindow(int position) {
        if (galleryChatId == null || galleryAdapter == null) return;

        if (!galleryLoadingBefore && position <= GALLERY_EDGE_THRESHOLD && galleryWindowStart > 0) {
            galleryLoadingBefore = true;
            int newFrom = Math.max(0, galleryWindowStart - com.callx.app.utils.ChatMediaGalleryBuilder.WINDOW_RADIUS);
            int oldWindowStart = galleryWindowStart;
            GALLERY_WINDOW_EXECUTOR.execute(() -> {
                List<Map<String, Object>> chunk =
                        com.callx.app.utils.ChatMediaGalleryBuilder.slice(galleryChatId, newFrom, oldWindowStart);
                runOnUiThread(() -> {
                    galleryLoadingBefore = false;
                    if (chunk == null || chunk.isEmpty() || galleryAdapter == null) return;
                    galleryItems.addAll(0, chunk);
                    galleryWindowStart = newFrom;
                    galleryAdapter.notifyItemRangeInserted(0, chunk.size());
                    // Items shifted right by chunk.size() — keep the pager
                    // pointed at the same logical page (no visible jump).
                    galleryActivePos += chunk.size();
                    binding.mediaPager.setCurrentItem(galleryActivePos, false);
                });
            });
        }

        if (!galleryLoadingAfter
                && position >= galleryItems.size() - 1 - GALLERY_EDGE_THRESHOLD
                && galleryWindowStart + galleryItems.size() < galleryTotalCount) {
            galleryLoadingAfter = true;
            int oldWindowEnd = galleryWindowStart + galleryItems.size();
            int newTo = Math.min(galleryTotalCount,
                    oldWindowEnd + com.callx.app.utils.ChatMediaGalleryBuilder.WINDOW_RADIUS);
            GALLERY_WINDOW_EXECUTOR.execute(() -> {
                List<Map<String, Object>> chunk =
                        com.callx.app.utils.ChatMediaGalleryBuilder.slice(galleryChatId, oldWindowEnd, newTo);
                runOnUiThread(() -> {
                    galleryLoadingAfter = false;
                    if (chunk == null || chunk.isEmpty() || galleryAdapter == null) return;
                    int insertAt = galleryItems.size();
                    galleryItems.addAll(chunk);
                    galleryAdapter.notifyItemRangeInserted(insertAt, chunk.size());
                });
            });
        }
    }

    /** Currently-active page's PhotoView, or null (video page / not bound yet). */
    private PhotoView currentGalleryPhotoView() {
        if (binding.mediaPager.getChildCount() == 0) return null;
        View v0 = binding.mediaPager.getChildAt(0);
        if (!(v0 instanceof androidx.recyclerview.widget.RecyclerView)) return null;
        androidx.recyclerview.widget.RecyclerView rv = (androidx.recyclerview.widget.RecyclerView) v0;
        for (int i = 0; i < rv.getChildCount(); i++) {
            androidx.recyclerview.widget.RecyclerView.ViewHolder vh =
                    rv.getChildViewHolder(rv.getChildAt(i));
            if (vh instanceof GalleryPagerAdapter.PageVH
                    && vh.getAdapterPosition() == galleryActivePos) {
                return ((GalleryPagerAdapter.PageVH) vh).photoView;
            }
        }
        return null;
    }

    /** Plays the video on `activePos` (if it's a video page) and pauses every other bound page. */
    private void pauseAllExcept(int activePos) {
        androidx.recyclerview.widget.RecyclerView rv =
                (androidx.recyclerview.widget.RecyclerView) binding.mediaPager.getChildAt(0);
        if (rv == null) return;
        for (int i = 0; i < rv.getChildCount(); i++) {
            android.view.View child = rv.getChildAt(i);
            androidx.recyclerview.widget.RecyclerView.ViewHolder vh = rv.getChildViewHolder(child);
            if (vh instanceof GalleryPagerAdapter.PageVH) {
                GalleryPagerAdapter.PageVH pvh = (GalleryPagerAdapter.PageVH) vh;
                galleryAdapter.setActive(pvh, pvh.getAdapterPosition() == activePos);
            }
        }
    }

    private void updatePageCounter(int position) {
        if (galleryItems == null) return;
        binding.tvPageCounter.setText((position + 1) + " / " + galleryItems.size());
    }

    private List<Map<String, Object>> parseMediaItems(String json) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                Map<String, Object> item = new HashMap<>();
                java.util.Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    item.put(k, obj.opt(k));
                }
                result.add(item);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private static String safeStr(Object o) { return (o instanceof String) ? (String) o : ""; }

    // ── Swipe down (close) / swipe up (reply) — single + gallery mode ────
    // Delegates to the shared MediaSwipeReplyCloseHelper (core module) so
    // the exact same gesture logic backs both modes instead of being
    // duplicated. The helper internally guards against a predominantly-
    // horizontal drag (so ViewPager2 paging isn't hijacked) and against an
    // active pinch-zoom (so PhotoView's own gesture always wins first).
    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        boolean gallerySelecting = galleryAdapter != null && galleryAdapter.isSelectMode();
        if (swipeHelper != null && !gallerySelecting && swipeHelper.onTouch(ev)) {
            return true;
        }
        // BUG FIX — top-bar tap-to-toggle reliability. Root cause: the old
        // per-view wiring (PhotoView's setOnViewTapListener for images,
        // which itself waits out Android's ~300ms double-tap disambiguation
        // before firing; the gallery adapter's root.setOnClickListener,
        // which PhotoView's own internal touch handling can simply never
        // let bubble up to the parent for a tap ON the photo — only video
        // items forwarded their click) meant a tap could easily fail to
        // toggle the bar, most noticeably on the very next tap right after
        // one that just hid it.
        // FIX: feed every touch event here, at the very top of dispatch,
        // into one GestureDetector for the whole Activity. onSingleTapUp
        // fires immediately on lift-off — no disambiguation wait — and
        // this never consumes the event (always returns false from
        // onSingleTapUp), so it doesn't affect the underlying PhotoView's
        // own pinch/double-tap-zoom or the gallery pager's paging at all.
        // Skipped during gallery multi-select, where a tap should only
        // toggle that item's selection checkbox, not the bar.
        if (!gallerySelecting && tapToggleDetector != null) {
            tapToggleDetector.onTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (galleryAdapter != null && galleryAdapter.isSelectMode()) {
            exitSelectMode();
            return;
        }
        // Same shrink-into-thumbnail animation as swipe/close-button — see
        // closeViewer(). Falls back to a plain finish() when there's no
        // sourceRect (super.onBackPressed()'s old behavior).
        closeViewer();
    }

    // ── #1 — Multi-select / forward from gallery ─────────────────────────
    private void enterSelectMode(int startPos) {
        if (galleryAdapter == null) return;
        galleryAdapter.setSelectMode(true);
        galleryAdapter.toggleSelected(startPos);
        binding.llTopBar.setVisibility(View.GONE);
        binding.llSelectToolbar.setVisibility(View.VISIBLE);
        updateSelectToolbar();
    }

    private void exitSelectMode() {
        if (galleryAdapter == null) return;
        galleryAdapter.setSelectMode(false);
        binding.llSelectToolbar.setVisibility(View.GONE);
        binding.llTopBar.setVisibility(View.VISIBLE);
    }

    private void updateSelectToolbar() {
        if (galleryAdapter == null) return;
        int count = galleryAdapter.getSelectedCount();
        if (count == 0) { exitSelectMode(); return; }
        binding.tvSelectCount.setText(count + " selected");
    }

    private void forwardSelection() {
        if (galleryAdapter == null || replyChatId == null || replyMessageId == null) {
            android.widget.Toast.makeText(this, "Can't forward — not opened from a chat", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        java.util.List<Integer> selected = galleryAdapter.getSelectedPositions();
        com.callx.app.conversation.GalleryForwardBridge.requestForward(replyChatId, replyMessageId, selected);
        exitSelectMode();
        finish();
        overridePendingTransition(0, 0);
    }

    private void deleteSelection() {
        if (galleryAdapter == null || replyChatId == null || replyMessageId == null) return;
        java.util.List<Integer> selected = new ArrayList<>(galleryAdapter.getSelectedPositions());
        if (selected.isEmpty()) return;
        com.callx.app.utils.AlertDialogStyler.showReusableConfirm(this,
                "media_viewer_delete_selection", com.callx.app.utils.AlertDialogStyler.DialogSize.DEFAULT,
                selected.size() == 1 ? "Delete this item?" : "Delete " + selected.size() + " items?",
                "This can't be undone.",
                "Delete", () -> {
                    // Highest index first so earlier indices stay valid as
                    // each delete request is queued (bridge is one-shot, so
                    // queue them with small delays — same pattern used for
                    // multi-forward sends elsewhere in this codebase).
                    java.util.Collections.sort(selected, java.util.Collections.reverseOrder());
                    for (int idx = 0; idx < selected.size(); idx++) {
                        final int pos = selected.get(idx);
                        binding.getRoot().postDelayed(() ->
                            com.callx.app.conversation.GalleryItemActionBridge.request(
                                replyChatId, replyMessageId, pos,
                                com.callx.app.conversation.GalleryItemActionBridge.ACTION_DELETE_ITEM, null),
                            idx * 50L);
                    }
                    exitSelectMode();
                    finish();
                    overridePendingTransition(0, 0);
                },
                null, null,
                "Cancel");
    }

    private void starSelection() {
        if (galleryAdapter == null || replyChatId == null || replyMessageId == null) return;
        java.util.List<Integer> selected = galleryAdapter.getSelectedPositions();
        for (int idx = 0; idx < selected.size(); idx++) {
            final int pos = selected.get(idx);
            binding.getRoot().postDelayed(() ->
                com.callx.app.conversation.GalleryItemActionBridge.request(
                    replyChatId, replyMessageId, pos,
                    com.callx.app.conversation.GalleryItemActionBridge.ACTION_STAR_ITEM, null),
                idx * 50L);
        }
        android.widget.Toast.makeText(this, "Starred", android.widget.Toast.LENGTH_SHORT).show();
        exitSelectMode();
    }

    // ── #4/#2 — single-item more-options menu (forward / star / delete /
    // edit caption). Forward/Star/Delete used to live ONLY in the chat's
    // pre-viewer bottom sheet (showMediaActionSheet); that sheet is gone
    // now — tapping media opens straight into this viewer, so those three
    // actions moved here, into the existing "more options" (ℹ) menu. Save
    // and Share were already top-bar icons and stay there unchanged.
    private void showMoreOptionsMenu() {
        boolean isGalleryMode = galleryItems != null && !galleryItems.isEmpty();
        java.util.List<String> labels = new ArrayList<>();
        labels.add("Save to gallery");
        labels.add("Share");
        if (isGalleryMode && replyChatId != null && replyMessageId != null) {
            labels.add("Forward");
            labels.add("Star this item");
            labels.add("Select multiple");
            labels.add("Edit caption for this item");
            // Delete — only for a message the current user actually sent,
            // same guard the old sheet's "🗑 Delete" row used.
            if (isOwnMessage) labels.add("Delete");
        }
        new android.app.AlertDialog.Builder(this)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    String chosen = labels.get(which);
                    switch (chosen) {
                        case "Save to gallery": saveCurrentToGallery(); break;
                        case "Share": shareMedia(sharedUrl); break;
                        case "Forward": forwardSingleActiveItem(); break;
                        case "Select multiple": enterSelectMode(galleryActivePos); break;
                        case "Delete": deleteSingleActiveItem(); break;
                        case "Star this item": starSingleActiveItem(); break;
                        case "Edit caption for this item": editCaptionForActiveItem(); break;
                        default: break;
                    }
                })
                .show();
    }

    // Forward just the currently-active item — same handoff GalleryForwardBridge
    // already uses for a multi-select forward, just with a single-item index list.
    private void forwardSingleActiveItem() {
        if (galleryActivePos < 0 || replyChatId == null || replyMessageId == null) return;
        java.util.List<Integer> selected = new ArrayList<>();
        selected.add(galleryActivePos);
        com.callx.app.conversation.GalleryForwardBridge.requestForward(replyChatId, replyMessageId, selected);
        finish();
        overridePendingTransition(0, 0);
    }

    private void deleteSingleActiveItem() {
        if (galleryActivePos < 0 || replyChatId == null || replyMessageId == null) return;
        com.callx.app.utils.AlertDialogStyler.showReusableConfirm(this,
                "media_viewer_delete_single", com.callx.app.utils.AlertDialogStyler.DialogSize.DEFAULT,
                "Delete this item?", "This can't be undone.",
                "Delete", () -> {
                    com.callx.app.conversation.GalleryItemActionBridge.request(
                            replyChatId, replyMessageId, galleryActivePos,
                            com.callx.app.conversation.GalleryItemActionBridge.ACTION_DELETE_ITEM, null);
                    finish();
                    overridePendingTransition(0, 0);
                },
                null, null,
                "Cancel");
    }

    private void starSingleActiveItem() {
        if (galleryActivePos < 0 || replyChatId == null || replyMessageId == null) return;
        com.callx.app.conversation.GalleryItemActionBridge.request(
                replyChatId, replyMessageId, galleryActivePos,
                com.callx.app.conversation.GalleryItemActionBridge.ACTION_STAR_ITEM, null);
        android.widget.Toast.makeText(this, "Starred", android.widget.Toast.LENGTH_SHORT).show();
    }

    private void editCaptionForActiveItem() {
        if (galleryActivePos < 0 || replyChatId == null || replyMessageId == null) return;
        final android.widget.EditText input = new android.widget.EditText(this);
        Object existing = galleryItems.get(galleryActivePos).get("caption");
        if (existing instanceof String) input.setText((String) existing);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Caption for this photo")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String newCaption = input.getText() != null ? input.getText().toString().trim() : "";
                    com.callx.app.conversation.GalleryItemActionBridge.request(
                            replyChatId, replyMessageId, galleryActivePos,
                            com.callx.app.conversation.GalleryItemActionBridge.ACTION_EDIT_CAPTION, newCaption);
                    // Reflect immediately in this still-open viewer too.
                    galleryItems.get(galleryActivePos).put("caption", newCaption);
                    if (galleryAdapter != null) galleryAdapter.notifyItemChanged(galleryActivePos);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── "Edit" — view a photo/video, tweak it in MediaEditActivity, resend ─
    private void onEditClicked() {
        if (replyChatId == null || replyMessageId == null) {
            Toast.makeText(this, "Can't edit — not opened from a chat", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = sharedUrl;
        if (url == null || url.isEmpty()) return;
        boolean isVideo = isGalleryActiveVideo();

        // MediaEditActivity reads via ContentResolver, so a remote http(s)
        // URL won't work directly — resolve to the same locally-cached
        // File that Save/Share already use, downloading first if needed.
        File cached = MediaCache.getCached(this, url);
        if (cached != null) {
            launchEditorFor(cached, isVideo);
            return;
        }
        showLoading(true);
        MediaCache.get(this, url, new MediaCache.Callback() {
            @Override public void onReady(File file) {
                showLoading(false);
                launchEditorFor(file, isVideo);
            }
            @Override public void onError(String reason) {
                showLoading(false);
                Toast.makeText(MediaViewerActivity.this, "Couldn't load media for editing", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void launchEditorFor(File file, boolean isVideo) {
        Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        grantUriPermission(getPackageName(), contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);

        Intent intent = new Intent(this, com.callx.app.conversation.controllers.MediaEditActivity.class);
        ArrayList<String> uris = new ArrayList<>();
        uris.add(contentUri.toString());
        ArrayList<Integer> videoFlags = new ArrayList<>();
        videoFlags.add(isVideo ? 1 : 0);
        intent.putStringArrayListExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_URIS, uris);
        intent.putIntegerArrayListExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_IS_VIDEO, videoFlags);
        intent.putExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_CAPTION, "");
        intent.putExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_HD, false);
        mediaEditLauncher.launch(intent);
    }

    // ── #3 — Save current media to device gallery ────────────────────────
    private void saveCurrentToGallery() {
        if (sharedUrl == null || sharedUrl.isEmpty()) return;
        boolean isVideo = isGalleryActiveVideo();
        android.widget.Toast.makeText(this, "Saving…", android.widget.Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                File cached = MediaCache.getCached(this, sharedUrl);
                File source;
                if (cached != null) {
                    source = cached;
                } else if (mediaDecryptKey != null) {
                    // Media E2E: sharedUrl is ciphertext — a raw byte-copy
                    // (the old fallback below) would save undecodable
                    // garbage to the gallery. Route through the decrypting
                    // MediaCache instead, same fix as loadImageProgressive.
                    final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
                    final File[] result = new File[1];
                    MediaCache.get(this, sharedUrl, mediaDecryptKey, new MediaCache.Callback() {
                        @Override public void onReady(File f) { result[0] = f; latch.countDown(); }
                        @Override public void onError(String r) { latch.countDown(); }
                    });
                    latch.await();
                    if (result[0] == null) throw new java.io.IOException("Decrypt failed");
                    source = result[0];
                } else {
                    // Blocking download fallback (off main thread already).
                    java.io.InputStream in = new java.net.URL(sharedUrl).openStream();
                    File tmp = File.createTempFile("save_", isVideo ? ".mp4" : ".jpg", getCacheDir());
                    try (java.io.OutputStream out = new java.io.FileOutputStream(tmp)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    }
                    in.close();
                    source = tmp;
                }
                String displayName = "CallX2_" + System.currentTimeMillis() + (isVideo ? ".mp4" : ".jpg");
                android.content.ContentValues values = new android.content.ContentValues();
                values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, displayName);
                values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, isVideo ? "video/mp4" : "image/jpeg");
                Uri collection;
                if (isVideo) {
                    values.put(android.provider.MediaStore.Video.Media.RELATIVE_PATH, "Movies/CallX2");
                    collection = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else {
                    values.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CallX2");
                    collection = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                }
                Uri dest = getContentResolver().insert(collection, values);
                if (dest != null) {
                    try (java.io.InputStream in = new java.io.FileInputStream(source);
                         java.io.OutputStream out = getContentResolver().openOutputStream(dest)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    }
                    runOnUiThread(() -> android.widget.Toast.makeText(this, "Saved to gallery", android.widget.Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() -> android.widget.Toast.makeText(this, "Save failed", android.widget.Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> android.widget.Toast.makeText(this, "Save failed", android.widget.Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private boolean isGalleryActiveVideo() {
        if (galleryItems != null && galleryActivePos >= 0 && galleryActivePos < galleryItems.size()) {
            return "video".equals(galleryItems.get(galleryActivePos).get("mediaType"));
        }
        String type = getIntent().getStringExtra("type");
        // A WhatsApp-style GIF-as-mp4 (see onCreate's gifIsVideo) is a real
        // video file on disk — Save-to-gallery/Edit must treat it as one
        // (mp4 extension, video MediaStore collection), not fall through to
        // the image path and write video bytes into a ".jpg".
        boolean gifIsVideo = "gif".equals(type) && getIntent().getBooleanExtra("gifIsVideo", false);
        return "video".equals(type) || gifIsVideo;
    }

    private void toggleUI() {
        uiVisible = !uiVisible;
        LinearLayout topBar = binding.llTopBar;
        if (uiVisible) {
            topBar.setVisibility(View.VISIBLE);
            topBar.animate().alpha(1f).setDuration(200).start();
        } else {
            topBar.animate().alpha(0f).setDuration(200).withEndAction(
                () -> topBar.setVisibility(View.GONE)
            ).start();
        }
    }

    // ── Progressive image load ────────────────────────────────────
    private void loadImageProgressive(String fullUrl, String thumbUrl) {
        loadImageProgressive(fullUrl, thumbUrl, null);
    }

    // ── Black-screen protection (single-media mode) ──────────────────────
    // A failed Glide load used to be silent: the PhotoView just stayed empty on the
    // black background. Every load below now reports through singleImageListener().
    private static final int IMG_CACHE = 0, IMG_LOCAL = 1, IMG_REMOTE = 2;
    private boolean localImageFallbackTried;
    private boolean localVideoFallbackTried;
    private String currentVideoUrl;

    private com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable> singleImageListener(
            final String fullUrl, final String thumbUrl, final int kind) {
        return new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
            @Override public boolean onLoadFailed(
                    @androidx.annotation.Nullable com.bumptech.glide.load.engine.GlideException e,
                    Object model,
                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                    boolean isFirstResource) {
                boolean oom = false;
                if (e != null && e.getRootCauses() != null) {
                    for (Throwable t : e.getRootCauses()) {
                        if (t instanceof OutOfMemoryError) { oom = true; break; }
                    }
                }
                final boolean outOfMemory = oom;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (kind == IMG_LOCAL && !localImageFallbackTried) {
                        // Device copy vanished / permission revoked after the availability probe —
                        // fall back to the normal cache/remote path instead of a black screen.
                        localImageFallbackTried = true;
                        loadImageProgressive(fullUrl, thumbUrl, null);
                        return;
                    }
                    if (kind == IMG_CACHE && !isOwnMessage && !outOfMemory) {
                        // "Downloaded" but undecodable (truncated / ciphertext cached without its key):
                        // drop it so the chat bubble reads "not downloaded" again and can re-fetch it.
                        MediaCache.invalidate(MediaViewerActivity.this, fullUrl);
                        Toast.makeText(MediaViewerActivity.this,
                                "This photo's file was damaged and has been removed. Download it again from the chat.",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    Toast.makeText(MediaViewerActivity.this, "Couldn't load photo", Toast.LENGTH_SHORT).show();
                });
                return false;
            }
            @Override public boolean onResourceReady(
                    android.graphics.drawable.Drawable resource, Object model,
                    com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                    com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                return false;
            }
        };
    }

    private void loadImageProgressive(String fullUrl, String thumbUrl, String localPath) {
        PhotoView pv = binding.ivFull;

        // WhatsApp-style local-first: original local file still on the
        // device → show it directly, full quality, and skip the remote
        // load entirely. Falls back to the normal progressive-load path
        // below the moment the file's gone.
        if (localPath != null && !localPath.isEmpty()
                && com.callx.app.utils.LocalMediaAvailability.isAvailable(this, localPath)) {
            Glide.with(this)
                .load(Uri.parse(localPath))
                .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                        com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .listener(singleImageListener(fullUrl, thumbUrl, IMG_LOCAL))
                .into(pv);
            return;
        }

        if (thumbUrl != null && !thumbUrl.isEmpty()) {
            Glide.with(this)
                .load(thumbUrl)
                .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                        com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .override(400, 400)
                .into(pv);

            Glide.with(this)
                .load(fullUrl)
                .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                        com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                .thumbnail(Glide.with(this)
                    .load(thumbUrl)
                    .diskCacheStrategy(DiskCacheStrategy.ALL))
                .listener(singleImageListener(fullUrl, thumbUrl, IMG_REMOTE))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .transition(com.bumptech.glide.load.resource.drawable
                    .DrawableTransitionOptions.withCrossFade(500))
                .into(pv);
        } else {
            File cachedImg = MediaCache.getCached(this, fullUrl);
            if (cachedImg != null) {
                Glide.with(this).load(cachedImg)
                    .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                            com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(singleImageListener(fullUrl, thumbUrl, IMG_CACHE))
                    .into(pv);
            } else if (mediaDecryptKey != null) {
                // Media E2E: fullUrl is ciphertext (resource_type=raw) — it
                // can't be Glide-loaded directly (that used to happen here
                // unconditionally, showing a broken image). Decrypt via
                // MediaCache first, then load the resulting plaintext file.
                MediaCache.get(this, fullUrl, mediaDecryptKey, new MediaCache.Callback() {
                    @Override public void onReady(File f) {
                        if (isFinishing() || isDestroyed()) return;
                        Glide.with(MediaViewerActivity.this).load(f)
                            .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                                    com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .listener(singleImageListener(fullUrl, thumbUrl, IMG_CACHE))
                            .into(pv);
                    }
                    @Override public void onError(String r) {
                        Toast.makeText(MediaViewerActivity.this,
                                "Couldn't decrypt photo: " + r, Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Glide.with(this).load(fullUrl)
                    .apply(com.bumptech.glide.request.RequestOptions.formatOf(
                            com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .listener(singleImageListener(fullUrl, thumbUrl, IMG_REMOTE))
                    .into(pv);
                MediaCache.get(this, fullUrl, new MediaCache.Callback() {
                    @Override public void onReady(File f) {}
                    @Override public void onError(String r) {}
                });
            }
        }
    }

    // ── Video playback (cache-first) ──────────────────────────────
    private void playVideo(String url) {
        playVideo(url, null, false);
    }

    private void playVideo(String url, String localPath) {
        playVideo(url, localPath, false);
    }

    /**
     * @param loopMuted true for a WhatsApp-style GIF-as-mp4 (see the
     *                  gifIsVideo branch in onCreate): loops forever with
     *                  the volume at 0, instead of a normal one-shot video
     *                  with audio and a scrub bar.
     */
    private void playVideo(String url, String localPath, boolean loopMuted) {
        currentVideoUrl = url;
        // WhatsApp-style local-first: original local file still on the
        // device → play it directly, full quality, no download at all.
        // Falls back to the normal cache-first remote path the moment
        // the file's gone (deleted from gallery, storage cleared, etc).
        if (localPath != null && !localPath.isEmpty()
                && com.callx.app.utils.LocalMediaAvailability.isAvailable(this, localPath)) {
            startExoPlayer(Uri.parse(localPath), loopMuted);
            return;
        }

        File cached = MediaCache.getCached(this, url);
        if (cached != null) {
            startExoPlayer(Uri.fromFile(cached), loopMuted);
            return;
        }
        showLoading(true);
        MediaCache.get(this, url, new MediaCache.Callback() {
            @Override public void onReady(File file) {
                showLoading(false);
                startExoPlayer(Uri.fromFile(file), loopMuted);
            }
            @Override public void onError(String reason) {
                showLoading(false);
                startExoPlayer(Uri.parse(url), loopMuted);
            }
        });
    }

    private void startExoPlayer(Uri uri) {
        startExoPlayer(uri, false);
    }

    private void startExoPlayer(Uri uri, boolean loopMuted) {
        if (isFinishing() || isDestroyed()) return;
        if (player != null) { player.release(); player = null; } // fallback re-entry must not leak the failed player
        player = new ExoPlayer.Builder(this).build();
        binding.player.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(uri));
        if (loopMuted) {
            player.setRepeatMode(Player.REPEAT_MODE_ALL);
            player.setVolume(0f);
        }
        player.prepare();
        player.setPlayWhenReady(true);

        // Black-screen protection: a playback error used to leave an empty black player with
        // no message. Local-file failure falls back to the cache/stream path once; a cached
        // file whose CONTAINER can't be parsed (truncated / ciphertext) is dropped so the
        // bubble shows "Download" again; anything else (codec, network) just tells the user.
        final boolean uriIsCacheFile = "file".equals(uri.getScheme())
                && uri.getPath() != null && uri.getPath().contains("callx_media_cache");
        final boolean uriIsLocal = !uriIsCacheFile && !"http".equals(uri.getScheme()) && !"https".equals(uri.getScheme());
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
                if (isFinishing() || isDestroyed()) return;
                boolean badFile = error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                        || error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED;
                if (uriIsLocal && !localVideoFallbackTried && currentVideoUrl != null) {
                    localVideoFallbackTried = true;
                    playVideo(currentVideoUrl, null, loopMuted);
                    return;
                }
                if (uriIsCacheFile && badFile && !isOwnMessage && currentVideoUrl != null) {
                    MediaCache.invalidate(MediaViewerActivity.this, currentVideoUrl);
                    Toast.makeText(MediaViewerActivity.this,
                            "This video's file was damaged and has been removed. Download it again from the chat.",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MediaViewerActivity.this, "Couldn't play video", Toast.LENGTH_SHORT).show();
            }
        });

        // Mirror actual play/pause state into chatPlayback — onIsPlayingChanged
        // fires for user pause/resume AND for buffering stalls, which is
        // exactly the granularity we want for a "watching…" badge. Skipped
        // for a looping muted GIF — there's no meaningful "watching" state
        // for something that's just silently looping in the background.
        if (!loopMuted && playbackChatId != null && messageIdPresent()) {
            player.addListener(new Player.Listener() {
                @Override public void onIsPlayingChanged(boolean isPlaying) {
                    publishPlaybackPresence(isPlaying);
                }
            });
        }
    }

    private boolean messageIdPresent() {
        return playbackMessageId != null && !playbackMessageId.isEmpty();
    }

    private void publishPlaybackPresence(boolean playing) {
        if (playbackChatId == null || !messageIdPresent()) return;
        String uid = FirebaseUtils.getCurrentUid();
        if (uid == null || uid.isEmpty()) return;
        if (playbackRef == null) {
            playbackRef = FirebaseUtils.getChatPlaybackRef(playbackChatId).child(uid);
        }
        if (playing == playbackPublished) return;
        playbackPublished = playing;
        if (playing) {
            playbackRef.setValue(playbackMessageId);
            // Safety net: if the app dies mid-playback, Firebase clears it for us.
            playbackRef.onDisconnect().removeValue();
        } else {
            playbackRef.removeValue();
            playbackRef.onDisconnect().cancel();
        }
    }

    // ── Share ─────────────────────────────────────────────────────
    private void shareMedia(String url) {
        if (url == null) return;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    private void showLoading(boolean show) {
        runOnUiThread(() -> binding.pbLoading.setVisibility(show ? View.VISIBLE : View.GONE));
    }

    private void hideSystemUI() {
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        if (voiceCaptionPlayer != null) { voiceCaptionPlayer.release(); voiceCaptionPlayer = null; }
        if (binding != null && binding.mediaPager.getChildCount() > 0
                && binding.mediaPager.getChildAt(0) instanceof androidx.recyclerview.widget.RecyclerView) {
            androidx.recyclerview.widget.RecyclerView rv =
                    (androidx.recyclerview.widget.RecyclerView) binding.mediaPager.getChildAt(0);
            for (int i = 0; i < rv.getChildCount(); i++) {
                androidx.recyclerview.widget.RecyclerView.ViewHolder vh =
                        rv.getChildViewHolder(rv.getChildAt(i));
                if (vh instanceof GalleryPagerAdapter.PageVH && galleryAdapter != null) {
                    galleryAdapter.releasePlayer((GalleryPagerAdapter.PageVH) vh);
                }
            }
        }
        // Viewer is closing — clear the "watching…" badge immediately rather
        // than waiting on onDisconnect (that's only the crash/kill safety net).
        publishPlaybackPresence(false);
        super.onDestroy();
    }
}
