package com.callx.app.compose;
import com.callx.app.utils.AlertDialogStyler;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.*;
import android.view.View;
import android.widget.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.*;
import com.bumptech.glide.Glide;
import com.callx.app.status.R;
import com.callx.app.status.databinding.ActivityNewStatusBinding;
import com.callx.app.models.StatusItem;
import com.callx.app.utils.*;
import androidx.annotation.NonNull;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.*;
import com.callx.app.privacy.StatusPrivacyBottomSheet;
import com.callx.app.utils.StatusCustomExpiryHelper;
import com.callx.app.utils.StatusLinkPreviewHelper;
import com.callx.app.utils.StatusMentionHelper;
import com.callx.app.utils.StatusNotificationHelper;
import com.callx.app.utils.StatusPrivacyManager;
import com.callx.app.stickers.StatusStickerPickerSheet;
import com.callx.app.stickers.StatusStickerOverlayView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
/**
 * NewStatusActivity v26 — Fully comprehensive status creation + Interactive Stickers.
 *
 * ORIGINAL features:
 *   ✅ Text status + 10 bg color presets + font styles
 *   ✅ Image status (gallery pick) + caption
 *   ✅ Video status (gallery pick) + caption
 *   ✅ Privacy mode selector
 *   ✅ Upload progress display + draft save
 *
 * v25 features:
 *   ✅ Camera capture (photo + video) — direct capture without gallery
 *   ✅ Link preview — type/paste URL → OG card preview
 *   ✅ GIF / Sticker via URL input (extensible to Giphy)
 *   ✅ Custom expiry timer — 1h/3h/6h/12h/24h/48h/72h
 *   ✅ Close Friends toggle (post only to close friends list)
 *   ✅ @mention support in text and caption
 *   ✅ Gradient background for text statuses
 *   ✅ Text alignment options (left/center/right)
 *   ✅ Font size slider
 *   ✅ Privacy bottom sheet (full selector with contact picker)
 *   ✅ Image/Video compression with progress
 *   ✅ Cloudinary upload with retry
 *   ✅ Character counter (700 max)
 *
 * NEW v26 features — Interactive Stickers for Status/Stories:
 *   ✅ 🎵 Music Sticker   — show song + artist + animated equaliser bars
 *   ✅ ⏳ Countdown Timer — live ticking countdown card to any future date
 *   ✅ 🧠 Quiz Sticker    — multiple-choice question with one correct answer
 *   ✅ 💬 Question Box    — open-ended question box for viewer replies
 *   ✅ Stickers draggable on the status preview
 *   ✅ Long-press sticker to remove it
 *   ✅ Multiple stickers supported simultaneously
 *   ✅ Sticker JSON serialized and stored with the status post
 */
public class NewStatusActivity extends AppCompatActivity {

    /** Extra: sticker JSON to auto-attach on open (used by the ➕ Add Yours chain flow). */
    public static final String EXTRA_PREFILL_STICKER_JSON = "prefillStickerJson";
    /** Extra: optional toast message to show once the prefilled sticker is attached. */
    public static final String EXTRA_PREFILL_TOAST = "prefillToast";
    private static final String PREFS_DRAFT = "status_draft";
    private static final String KEY_DRAFT   = "draft_text";
    private static final int[] BG_COLORS = {
        0xFF6200EE, 0xFF03DAC5, 0xFFE53935, 0xFF43A047,
        0xFF1E88E5, 0xFFFF6F00, 0xFF8E24AA, 0xFF00ACC1,
        0xFF6D4C41, 0xFF263238
    };
    private static final int[] TEXT_COLORS_FOR_BG = {
        0xFFFFFFFF, 0xFF000000, 0xFFFFFFFF, 0xFFFFFFFF,
        0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,
        0xFFFFFFFF, 0xFFFFFFFF
    };
    private ActivityNewStatusBinding binding;
    private Uri    pickedImage, pickedVideo, cameraImageUri;
    private int    selectedBgColor   = BG_COLORS[0];
    private int    selectedTextColor = TEXT_COLORS_FOR_BG[0];
    private String selectedFontStyle  = "default";
    private String selectedPrivacy    = StatusPrivacyManager.PRIVACY_CONTACTS;
    private Set<String> privacyUids   = new HashSet<>();
    private int    selectedExpiryHours = 24;
    private boolean isCloseFriends    = false;
    private String  selectedTextAlign  = "center";
    /** Whether viewers may repost this status to their own story (mirrors WA "Allow sharing"). Default: on. */
    private boolean allowSharing      = true;
    // Per-story creator control for the level-stabilizer (see
    // StorySpinViewController). OPT-IN, default OFF: only a story where the
    // creator explicitly flips this toggle on gets the stabilizer — every
    // other story stays off, and it's never carried into Highlights either
    // (StatusViewerActivity forces it off in highlight mode regardless).
    private boolean stabilizerEnabled = false;
    /** Custom avatar-ring color/mode for this status (picked via the same
     *  HighlightRingColorPickerBottomSheet used for Highlight albums).
     *  Null = use the app's default seen/unseen ring. */
    private String  selectedRingColor = null;
    private String  selectedRingMode  = null;
    // ── Scheduling (v27) ────────────────────────────────────────────────
    // > 0 when the user picked "Schedule" instead of posting immediately —
    // read once by saveStatus()/saveBatchStatus() and reset after use.
    private long    pendingScheduledAt = 0;
    // Link preview state
    private String detectedLinkUrl;
    private StatusLinkPreviewHelper.LinkPreview fetchedPreview;
    private ActivityResultLauncher<String>  imagePicker;
    private ActivityResultLauncher<String>  videoPicker;
    private ActivityResultLauncher<Uri>     cameraCapture;
    private ActivityResultLauncher<String>  cameraVideoCapture;
    // NEW: launches feature-reels' ReelCameraActivity (the same rich camera
    // used by the Reels tab's + / Create button — filters, effects, speed,
    // stickers, text, trending audio) and receives the finished video back.
    // Launched via class-name Intent (no compile dependency — feature-status
    // cannot depend on feature-reels since feature-reels already depends on
    // feature-status).
    private ActivityResultLauncher<Intent>  reelCameraLauncher;
    // Result of the full-screen editor opened from the attach-sheet's "Edit"
    // action — see showStatusAddSheet()'s onMediaEdit callback.
    private ActivityResultLauncher<Intent>  statusMediaEditLauncher;
    // NEW: caption typed in the attach sheet before tapping "Edit" on a
    // single picked video — reelCameraLauncher/handleReelCameraResult is
    // shared with the plain camera flow (which has no preset caption), so
    // this is only non-null while a pencil-edit-video round-trip through
    // ReelEditorActivity is in flight; handleReelCameraResult consumes and
    // clears it once used as a fallback for the editor's own text overlay.
    private String pendingSingleVideoEditCaption;
    /**
     * ✅ FIX: ReelEditorActivity's Thumbnail tool let the person pick a custom
     * cover frame (RESULT_THUMB_PATH → a real PNG already saved to disk), but
     * this screen always regenerated its own first-frame thumbnail on upload
     * regardless — the pick was accepted in the editor UI and then silently
     * thrown away. Carries the picked file from handleReelCameraResult()
     * through to uploadAndSave(); cleared in showVideoPreview()/discardMedia()
     * so a later unrelated video pick can't accidentally reuse a stale one.
     */
    private java.io.File pendingCustomThumbnailFile;
    // v216: Layout picker result launcher — receives selected URIs + layout style.
    private ActivityResultLauncher<Intent>  layoutPickerLauncher;
    // v237: Receives the result of editing the flattened layout collage in
    // MediaEditActivity — see openLayoutEditor()/its registration below.
    // Kept completely separate from statusMediaEditLauncher (which still
    // serves the plain multi-select attach-sheet "N separate photos" flow
    // via postStatusBatch) so the single-collage layout flow can never
    // accidentally get routed into the batch poster, and so a single
    // composed collage can never turn back into N individual photos.
    private ActivityResultLauncher<Intent>  layoutMediaEditLauncher;

    /** FrameLayout that holds the status preview + sticker overlays */
    private android.widget.FrameLayout stickerOverlayFrame;
    /** JSON array of all added sticker configs (serialised for post metadata) */
    private final java.util.List<String> addedStickerJsons = new java.util.ArrayList<>();
    /** Small/Medium/Large size-control row shown above whichever sticker was last tapped */
    private LinearLayout stickerSizeBar;
    private com.callx.app.stickers.StatusStickerOverlayView selectedSticker;

    /** Reel-style three-step status composer state. */
    private int wizardStep = 0;
    /** Short step name shown in tv_step_name, next to the "Step X of Y" pill
     *  (all-caps via android:textAllCaps, so plain-case names are given here)
     *  — same pattern as Reel Editor / Reel Upload / Reel Photo Editor. */
    private static final String[] STEP_NAMES = {"Create", "Edit", "Publish"};
    private android.animation.ObjectAnimator activeStepRingSpin;
    /**
     * True only while a video picked on the Create step is being sent through
     * the "Advance Editing" round trip (ReelEditorActivity → its own
     * MediaEditActivity fallback). Set right before launching that intent and
     * consumed the moment the result lands back on the preview — see
     * btn_advance_editing's click listener and showSinglePickedPreview().
     * Kept separate from pendingSingleVideoEditCaption (which the attach
     * sheet's pencil-edit action also uses) so a normal pencil-edit round
     * trip never accidentally jumps the wizard to the Edit step.
     */
    private boolean pendingAdvanceEditWizardJump = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNewStatusBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setupToolbar();
        setupMediaPickers();
        setupCameraCapture();
        reelCameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::handleReelCameraResult);
        statusMediaEditLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> handleMediaEditActivityResult(result.getResultCode(), result.getData()));
        setupBgColorPicker();
        setupFontStylePicker();
        setupPrivacyButton();
        setupExpiryButton();
        setupCloseFriendsToggle();
        setupAllowSharingToggle();
        setupStabilizerToggle();
        setupRingColorButton();
        setupTextAlignButtons();
        setupTextInput();
        setupStickerOverlayFrame();
        setupWizard();
        // v216: Layout picker launcher — receives URIs + layoutStyle from StatusLayoutPickerActivity.
        //
        // BUG FIX (the original root cause of "layout badal ke ek-ek photo ho
        // jata hai / N photos = N status posts"): this used to forward the
        // picked URIs straight into MediaEditActivity — a generic per-photo
        // swipe editor with zero concept of a collage. That's exactly why
        // the arranged layout visibly fell apart into individual swipeable
        // photos the instant this screen opened, why the pinch/zoom/pan
        // arrangement never made it into the post (MediaEditActivity strips
        // it and hands back brand-new baked file:// Uris that don't match
        // the original Uris the arrangement was keyed by), and why the flow
        // through a screen built for "edit N separate photos" was
        // fundamentally the wrong detour for "post one collage".
        //
        // v237: the fix is NOT to skip MediaEditActivity — the person wants
        // to be able to edit the chosen layout too. The fix is to flatten
        // the collage FIRST (StatusLayoutComposer, WYSIWYG with the arrange
        // screen since it also takes the pinch/zoom/pan data) so there is
        // exactly ONE baked image file, and only THEN send that single file
        // into MediaEditActivity as a one-item list (see openLayoutEditor()
        // below). Because MediaEditActivity only ever sees one item:
        //   - there is nothing left for it to swipe between → the layout
        //     can never visibly fall apart into individual photos again,
        //   - its own "delete" action already refuses to delete the last
        //     remaining item, so the collage can't be discarded down to zero
        //     images either,
        //   - it can only ever return that same one edited image back out,
        //     so post() still only ever uploads ONE file.
        // The edited collage is then routed into the exact same pickedImage
        // + showImagePreview() pipeline every normal single-photo status
        // already uses, exactly as before — caption, privacy, stickers and
        // the existing Post button all just keep working unchanged.
        layoutPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null) return;
                    java.util.ArrayList<String> uriStrings = result.getData().getStringArrayListExtra(
                            StatusLayoutPickerActivity.EXTRA_RESULT_URIS);
                    if (uriStrings == null || uriStrings.isEmpty()) return;
                    int layoutStyle = result.getData().getIntExtra(
                            StatusLayoutPickerActivity.EXTRA_RESULT_LAYOUT,
                            StatusLayoutPreviewView.STYLE_GRID_2X2);
                    float[] scales = result.getData().getFloatArrayExtra(StatusLayoutPickerActivity.EXTRA_RESULT_SCALE);
                    float[] panXs  = result.getData().getFloatArrayExtra(StatusLayoutPickerActivity.EXTRA_RESULT_PAN_X);
                    float[] panYs  = result.getData().getFloatArrayExtra(StatusLayoutPickerActivity.EXTRA_RESULT_PAN_Y);

                    java.util.List<Uri> uris = new java.util.ArrayList<>();
                    for (String s : uriStrings) uris.add(Uri.parse(s));

                    setPosting(true);
                    setHint("Creating layout…");
                    new Thread(() -> {
                        try {
                            java.io.File composed = StatusLayoutComposer.compose(
                                    this, uris, layoutStyle, scales, panXs, panYs);
                            Uri composedUri = androidx.core.content.FileProvider.getUriForFile(
                                    this, getPackageName() + ".fileprovider", composed);
                            runOnUiThread(() -> {
                                setPosting(false);
                                openLayoutEditor(composedUri);
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> {
                                setPosting(false);
                                toast("Failed to build layout: " + e.getMessage());
                            });
                        }
                    }).start();
                });
        // v237: MediaEditActivity result for the single flattened layout
        // collage — see openLayoutEditor(). Always exactly one URI in/out,
        // so this never touches postStatusBatch: it drops the (possibly
        // edited) collage into the normal single-image preview instead,
        // same as every other single-photo status.
        layoutMediaEditLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null) return;
                    java.util.ArrayList<String> uriStrings = result.getData().getStringArrayListExtra(
                            com.callx.app.conversation.controllers.MediaEditActivity.RESULT_URIS);
                    if (uriStrings == null || uriStrings.isEmpty()) return;
                    // Only one item was ever sent in, and MediaEditActivity's own
                    // "delete" guard refuses to delete the last remaining item, so
                    // there will always be exactly one URI here — the edited (or
                    // untouched) layout collage, never split back into pieces.
                    Uri editedCollage = Uri.parse(uriStrings.get(0));
                    pickedImage = editedCollage;
                    pickedVideo = null;
                    showImagePreview(pickedImage);
                    String editedCaption = result.getData().getStringExtra(
                            com.callx.app.conversation.controllers.MediaEditActivity.RESULT_CAPTION);
                    if (editedCaption != null && !editedCaption.isEmpty() && binding.etCaption != null) {
                        binding.etCaption.setText(editedCaption);
                    }
                });
        restoreDraft();
        applyPrefillStickerIfAny();
        // v216: "Upload" button now opens the WhatsApp-style "Add status" sheet
        //       (Text / Music / Layout / Voice / AI Images + Recents grid) instead
        //       of the old plain Camera/Gallery alert dialog.
        binding.btnPickImage.setOnClickListener(v -> showStatusAddSheet());
        binding.btnPost.setOnClickListener(v -> post());
        // Long-press "Post" to schedule this status for later instead of
        // posting it immediately — mirrors the WhatsApp/Instagram pattern of
        // holding the send button for extra options.
        binding.btnPost.setOnLongClickListener(v -> { showScheduleDialog(); return true; });
        androidx.appcompat.widget.TooltipCompat.setTooltipText(binding.btnPost, "Hold to schedule for later");
        binding.btnDiscardMedia.setOnClickListener(v -> discardMedia());
        if (binding.btnAdvanceEditing != null) {
            binding.btnAdvanceEditing.setOnClickListener(v -> openAdvanceEditingForPickedMedia());
        }
        // GIF / Sticker button
        View btnGif = binding.getRoot().findViewWithTag("btn_gif");
        if (btnGif != null) btnGif.setOnClickListener(v -> showGifInputDialog());
        // ── NEW: Interactive Sticker picker button ────────────────────────
        View btnSticker = binding.getRoot().findViewWithTag("btn_add_sticker");
        if (btnSticker != null) btnSticker.setOnClickListener(v -> openStickerPicker());
    }

    // ── Reel-style status wizard ─────────────────────────────────────────

    /**
     * Keeps the editor options in clear steps without losing the live story
     * preview. The preview card is outside the step-specific controls, so it
     * remains visible for text-only, media, and publish screens alike.
     */
    private void setupWizard() {
        binding.btnStepBack.setOnClickListener(v -> {
            if (wizardStep > 0) showWizardStep(wizardStep - 1);
            else finish();
        });
        binding.btnStepNext.setOnClickListener(v -> {
            if (wizardStep < 2) {
                if (wizardStep == 0 && !hasComposerContent()) {
                    toast("Pehle text ya media add karo");
                    return;
                }
                showWizardStep(wizardStep + 1);
            } else {
                post();
            }
        });
        // ✅ NEW: tapping a step dot jumps back to an already-visited step;
        // tapping ahead does nothing — only btnStepNext may move forward
        // (and still runs the hasComposerContent() check as before). Shared
        // across every stepper screen — see StepDotsNavigationHelper.
        TextView[] stepDots = {binding.stepDot1, binding.stepDot2, binding.stepDot3};
        com.callx.app.utils.StepDotsNavigationHelper.bindStepDots(stepDots,
            new com.callx.app.utils.StepDotsNavigationHelper.StepNavigator() {
                @Override public int getCurrentStep() { return wizardStep; }
                @Override public void goToStep(int step) { showWizardStep(step); }
            });
        showWizardStep(0);
    }

    private boolean hasComposerContent() {
        String text = binding.etText.getText() == null
                ? "" : binding.etText.getText().toString().trim();
        return pickedImage != null || pickedVideo != null
                || !text.isEmpty() || fetchedPreview != null;
    }

    private void showWizardStep(int step) {
        wizardStep = Math.max(0, Math.min(2, step));

        for (int i = 0; i < binding.statusFormContent.getChildCount(); i++) {
            View child = binding.statusFormContent.getChildAt(i);
            String section = child.getTag() instanceof String
                    ? (String) child.getTag() : "";
            boolean visible = true;

            if ("wizard_step_text".equals(section)) {
                visible = wizardStep == 0;
            } else if ("wizard_step_media".equals(section)) {
                visible = wizardStep == 1;
            } else if ("wizard_step_publish".equals(section)) {
                visible = wizardStep == 2;
            } else if ("btn_gif".equals(section) || "btn_add_sticker".equals(section)
                    || child.getId() == R.id.media_preview_frame) {
                visible = wizardStep == 1;
            } else if (child.getId() == R.id.btn_pick_image) {
                // Upload is the entry action on Create; the selected media
                // itself is reviewed on the following Edit step.
                visible = wizardStep == 0;
            } else if (child.getId() == R.id.status_step_preview_card) {
                // ✅ BUG FIX: this persistent preview card was showing on
                // EVERY step, including Edit (wizardStep == 1) — which has
                // its own full media_preview_frame (image/video + stickers +
                // discard button). That meant two previews of the same photo
                // stacked on screen right after upload. Hide the persistent
                // card only on the Edit step, where media_preview_frame is
                // already the single preview; keep it on Create (text-only
                // preview before media is picked) and Publish (final review).
                visible = wizardStep != 1;
            }

            // The link card keeps its own async visibility state, but belongs
            // to the Create step when it is actually shown.
            if ("link_preview_card".equals(section)) visible = wizardStep == 0;
            child.setVisibility(visible ? View.VISIBLE : View.GONE);
        }

        // ✅ tv_step_eyebrow now hosts the shared premium "Step X of Y" pill
        // (@drawable/bg_step_indicator_pill, same R.string.editor_step_pill_format
        // used by Reel Editor / Reel Upload) instead of the old
        // "CREATE YOUR STATUS" label + separate "1 of 3" counter TextView.
        String[] next = {"Continue", "Review", "Post now"};
        binding.tvStepEyebrow.setText(getString(R.string.editor_step_pill_format,
                wizardStep + 1, 3));
        if (binding.tvStepName != null && wizardStep < STEP_NAMES.length) {
            binding.tvStepName.setText(STEP_NAMES[wizardStep]);
        }
        binding.btnStepNext.setText(next[wizardStep]);
        binding.btnStepBack.setText(wizardStep == 0 ? "Cancel" : "Back");

        updateWizardProgress();
        refreshStepPreview();
        if (wizardStep == 0 && pickedImage == null && pickedVideo == null) {
            binding.bgColorPickerRow.setVisibility(View.VISIBLE);
        }

        binding.statusFormContent.post(() -> {
            View parent = (View) binding.statusFormContent.getParent();
            if (parent instanceof androidx.core.widget.NestedScrollView) {
                ((androidx.core.widget.NestedScrollView) parent).smoothScrollTo(0, 0);
            }
        });
    }

    private void updateWizardProgress() {
        TextView[] dots = {binding.stepDot1, binding.stepDot2, binding.stepDot3};
        for (int i = 0; i < dots.length; i++) {
            boolean active = i <= wizardStep;
            dots[i].setBackgroundResource(active
                    ? R.drawable.bg_trim_gradient_button
                    : R.drawable.bg_trim_circle_btn);
            dots[i].setTextColor(ContextCompat.getColor(this,
                    active ? R.color.white : R.color.trim_text_secondary));
        }
        binding.stepLine1.setBackgroundColor(ContextCompat.getColor(this,
                wizardStep >= 1 ? R.color.trim_gradient_start : R.color.trim_divider));
        binding.stepLine2.setBackgroundColor(ContextCompat.getColor(this,
                wizardStep >= 2 ? R.color.trim_gradient_start : R.color.trim_divider));
        updateActiveStepRing();
    }

    /**
     * ✅ NEW: spins a vibrant-green ring behind the step dot currently in
     * use (wizardStep) — shared :core drawable/color, same pattern used on
     * Reel Upload / Reel Editor / Reel Photo Editor.
     */
    private void updateActiveStepRing() {
        ImageView[] rings = {binding.stepRing1, binding.stepRing2, binding.stepRing3};
        if (activeStepRingSpin != null) {
            activeStepRingSpin.cancel();
            activeStepRingSpin = null;
        }
        for (int i = 0; i < rings.length; i++) {
            if (rings[i] == null) continue;
            if (i == wizardStep) {
                rings[i].setVisibility(View.VISIBLE);
                rings[i].setRotation(0f);
                activeStepRingSpin = android.animation.ObjectAnimator.ofFloat(
                        rings[i], View.ROTATION, 0f, 360f);
                activeStepRingSpin.setDuration(1400);
                activeStepRingSpin.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
                activeStepRingSpin.setInterpolator(new android.view.animation.LinearInterpolator());
                activeStepRingSpin.start();
            } else {
                rings[i].setVisibility(View.GONE);
            }
        }
    }

    /**
     * Render the current text/media state into the persistent wizard preview.
     * This is deliberately called from every input and media transition.
     */
    private void refreshStepPreview() {
        if (binding == null) return;

        // "Advance Editing" only makes sense on Create, and only once media
        // (photo or video) is actually picked — hidden everywhere else,
        // including text-only statuses. Re-checked here (not just in
        // showWizardStep()) because picking or discarding media updates
        // pickedImage/pickedVideo without itself changing wizardStep.
        if (binding.btnAdvanceEditing != null) {
            binding.btnAdvanceEditing.setVisibility(
                    wizardStep == 0 && (pickedImage != null || pickedVideo != null)
                            ? View.VISIBLE : View.GONE);
        }

        String text = binding.etText.getText() == null
                ? "" : binding.etText.getText().toString().trim();
        boolean hasMedia = pickedImage != null || pickedVideo != null;

        binding.ivStepPreviewMedia.setVisibility(hasMedia ? View.VISIBLE : View.GONE);
        binding.tvStepPreviewEmpty.setVisibility(!hasMedia && text.isEmpty()
                ? View.VISIBLE : View.GONE);
        binding.tvStepPreviewText.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);

        if (hasMedia) {
            Uri media = pickedVideo != null ? pickedVideo : pickedImage;
            Glide.with(this).load(media).fitCenter().into(binding.ivStepPreviewMedia);
            binding.statusStepPreviewFrame.setBackgroundResource(
                    R.drawable.bg_trim_photo_rounded);
            binding.tvStepPreviewText.setGravity(
                    android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL);
            binding.tvStepPreviewText.setTextColor(Color.WHITE);
        } else if (!text.isEmpty()) {
            android.graphics.drawable.GradientDrawable bg =
                    new android.graphics.drawable.GradientDrawable();
            bg.setColor(selectedBgColor);
            bg.setCornerRadius(dp(18));
            binding.statusStepPreviewFrame.setBackground(bg);
            binding.tvStepPreviewText.setGravity(textAlignGravity());
            binding.tvStepPreviewText.setTextColor(selectedTextColor);
        } else {
            binding.statusStepPreviewFrame.setBackgroundResource(
                    R.drawable.bg_trim_photo_rounded);
        }

        if (!text.isEmpty()) {
            binding.tvStepPreviewText.setText(StatusMentionHelper.highlight(text));
            applyFontStyle(binding.tvStepPreviewText, selectedFontStyle);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int textAlignGravity() {
        if (selectedTextAlign == null) return android.view.Gravity.CENTER;
        switch (selectedTextAlign) {
            case "left":  return android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL;
            case "right": return android.view.Gravity.END   | android.view.Gravity.CENTER_VERTICAL;
            default:      return android.view.Gravity.CENTER;
        }
    }

    // ── Sticker overlay frame setup ───────────────────────────────────────

    /**
     * Finds or creates the FrameLayout that wraps the status preview so
     * sticker overlay cards can be layered on top of it.
     */
    private void setupStickerOverlayFrame() {
        View frame = binding.getRoot().findViewWithTag("sticker_overlay_frame");
        if (frame instanceof android.widget.FrameLayout) {
            stickerOverlayFrame = (android.widget.FrameLayout) frame;
        }
    }

    /**
     * If this activity was launched from a ➕ Add Yours sticker tap
     * (StatusViewerActivity.openAddYoursComposer), auto-attaches that same
     * sticker here so the viewer doesn't have to re-type the prompt — they
     * just add their media/text and post to continue the chain.
     */
    private void applyPrefillStickerIfAny() {
        String prefillJson = getIntent().getStringExtra(EXTRA_PREFILL_STICKER_JSON);
        if (prefillJson == null || prefillJson.isEmpty()) return;

        // Wait a frame so the overlay frame has real dimensions before the
        // sticker is measured/positioned (mirrors addStickerOverlay's own
        // width fallback, but this runs before any layout pass at all).
        if (stickerOverlayFrame != null) {
            stickerOverlayFrame.post(() -> {
                addedStickerJsons.add(prefillJson);
                addStickerOverlay(prefillJson);
            });
        }

        String toastMsg = getIntent().getStringExtra(EXTRA_PREFILL_TOAST);
        if (toastMsg != null && !toastMsg.isEmpty()) {
            Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show();
        }
    }

    /** Open the sticker type picker sheet. */
    private void openStickerPicker() {
        StatusStickerPickerSheet.show(this, result -> {
            addedStickerJsons.add(result.json);
            addStickerOverlay(result.json);
            Toast.makeText(this,
                getStickerAddedLabel(result.type) + " added! Drag to reposition.",
                Toast.LENGTH_SHORT).show();
        });
    }

    private String getStickerAddedLabel(String type) {
        switch (type) {
            case "music":     return "🎵 Music sticker";
            case "countdown": return "⏳ Countdown";
            case "quiz":      return "🧠 Quiz sticker";
            case "question":  return "💬 Question box";
            case "poll":      return "🗳️ Poll sticker";
            case "slider":    return "🎚️ Slider sticker";
            case "mention":   return "👤 Mention sticker";
            case "hashtag":   return "#️⃣ Hashtag sticker";
            case "link":      return "🔗 Link sticker";
            case "addyours":  return "➕ Add Yours sticker";
            default:          return "✨ Sticker";
        }
    }

    /**
     * Inflate the sticker view and add it to the overlay frame.
     * Falls back gracefully if there is no overlay frame in the layout.
     */
    private void addStickerOverlay(String stickerJson) {
        if (stickerOverlayFrame == null) return;

        StatusStickerOverlayView stickerView = StatusStickerOverlayView.fromJson(this, stickerJson);

        // Position sticker near centre-top of frame
        int dp = (int) getResources().getDisplayMetrics().density;
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
            Math.min(stickerOverlayFrame.getWidth() > 0 ? stickerOverlayFrame.getWidth() - dp * 32 : dp * 280,
                dp * 280),
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
            android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL);
        // BUG FIX: this used to be `dp * (16 + addedStickerJsons.size() * 12)` —
        // a flat 12dp increment per sticker no matter how tall the previous
        // card actually was. Music/Countdown/Quiz/Question cards range from
        // ~70dp to 160dp+ tall, so adding all four landed each new one almost
        // fully on top of the last, all centred, all TOP-anchored. Instead,
        // stack each new sticker just below the *real* measured bottom of the
        // previously-added one (tracked in stickerStackBottomPx) plus a fixed
        // gap, so 4 stickers end up spaced apart down the story canvas instead
        // of overlapping. User can still drag any of them afterward.
        int gap = dp * 14;
        lp.topMargin = (stickerStackBottomPx < 0) ? (dp * 16) : (stickerStackBottomPx + gap);
        stickerOverlayFrame.addView(stickerView, lp);

        // Enable drag + pinch-resize + long-press-remove
        stickerView.attachDragToParent(stickerOverlayFrame);
        stickerView.setOnStickerTappedListener(this::showStickerSizeBar);
        stickerOverlayFrame.setOnClickListener(v -> hideStickerSizeBar());

        // Pop-in animation
        stickerView.setScaleX(0.3f);
        stickerView.setScaleY(0.3f);
        stickerView.setAlpha(0f);
        stickerView.animate().scaleX(stickerView.getStickerScale()).scaleY(stickerView.getStickerScale())
            .alpha(1f).setDuration(300)
            .setInterpolator(new android.view.animation.OvershootInterpolator(1.3f)).start();

        // Once this card is actually measured/laid out, remember where its
        // bottom edge landed so the *next* sticker (if any) starts below it.
        final int appliedTopMargin = lp.topMargin;
        stickerView.post(() -> {
            if (stickerView.getHeight() > 0) {
                stickerStackBottomPx = appliedTopMargin + stickerView.getHeight();
            }
        });
    }

    /**
     * Bottom Y (px) of the last sticker card added to {@link #stickerOverlayFrame},
     * used to place the next sticker below it instead of on top of it.
     * -1 until the first sticker has been measured.
     */
    private int stickerStackBottomPx = -1;


    /**
     * Small floating Small/Medium/Large row shown just above a tapped sticker —
     * the explicit alternative to pinch-to-resize for setting sticker size.
     */
    private void showStickerSizeBar(com.callx.app.stickers.StatusStickerOverlayView sticker) {
        selectedSticker = sticker;
        int dp = (int) getResources().getDisplayMetrics().density;

        if (stickerSizeBar == null) {
            stickerSizeBar = new LinearLayout(this);
            stickerSizeBar.setOrientation(LinearLayout.HORIZONTAL);
            stickerSizeBar.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setCornerRadius(dp * 20);
            bg.setColor(0xDD1A1A1A);
            stickerSizeBar.setBackground(bg);
            stickerSizeBar.setPadding(dp * 6, dp * 6, dp * 6, dp * 6);

            String[] labels = {"S", "M", "L"};
            float[]  scales = {
                com.callx.app.stickers.StatusStickerOverlayView.SCALE_SMALL,
                com.callx.app.stickers.StatusStickerOverlayView.SCALE_MEDIUM,
                com.callx.app.stickers.StatusStickerOverlayView.SCALE_LARGE
            };
            for (int i = 0; i < labels.length; i++) {
                TextView btn = new TextView(this);
                btn.setText(labels[i]);
                btn.setTextColor(Color.WHITE);
                btn.setTextSize(14);
                btn.setGravity(android.view.Gravity.CENTER);
                btn.setTypeface(null, android.graphics.Typeface.BOLD);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp * 40, dp * 40);
                lp.leftMargin = i == 0 ? 0 : dp * 4;
                float scale = scales[i];
                btn.setOnClickListener(v -> {
                    if (selectedSticker != null) selectedSticker.animateToScale(scale);
                });
                stickerSizeBar.addView(btn, lp);
            }
            stickerOverlayFrame.addView(stickerSizeBar, new android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL));
        }

        stickerSizeBar.setVisibility(View.VISIBLE);
        stickerSizeBar.bringToFront();
        // Position just above the tapped sticker (falls back near the top if it doesn't fit).
        stickerSizeBar.post(() -> {
            float top = sticker.getY() - stickerSizeBar.getHeight() - dp * 8;
            ((android.widget.FrameLayout.LayoutParams) stickerSizeBar.getLayoutParams()).topMargin =
                (int) Math.max(dp * 8, top);
            stickerSizeBar.requestLayout();
        });
    }

    private void hideStickerSizeBar() {
        selectedSticker = null;
        if (stickerSizeBar != null) stickerSizeBar.setVisibility(View.GONE);
    }
    @Override protected void onPause() { super.onPause(); saveDraft(); }
    // ── Toolbar ───────────────────────────────────────────────────────────
    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }
    // ── v217: COMBO "Add status" sheet ─────────────────────────────────────
    // Merges what used to be two separate, half-working sheets into one:
    //   1. showStatusAddSheet()'s own 5 action chips (Text/Music/Layout/
    //      Voice/AI images) — kept exactly as before.
    //   2. The full chat-grade attach sheet (openStatusAttachSheet(), which
    //      was written but never actually wired to the Upload button) —
    //      recent-media strip, expandable 4-col grid, folder picker, HD
    //      toggle, multi-select send bar, Edit-before-post.
    // Previously the chips lived in their own bottom_sheet_status_add.xml
    // with a 3-col RecyclerView (rv_status_add_recents) that
    // AttachSheetRecentMediaBinder could never bind to (it looks for
    // R.id.recents_grid/top_content, which that layout didn't have — see
    // the binder's early-return guard), so that grid was silently dead.
    // Now we inflate feature-chat's real bottom_sheet_attach.xml (the one
    // the binder actually supports) and inject just the chip row into it.
    private void showStatusAddSheet() {
        BottomSheetDialog sheet = new BottomSheetDialog(this);
        View v = getLayoutInflater().inflate(com.callx.app.chat.R.layout.bottom_sheet_attach, null);

        // Status has no poll/contact/location/document/payment/event
        // concepts, and its own AI-images entry point lives in the chip
        // row below — hide those chat-only chips from the icon grid so
        // the sheet stays focused on media, same as the old (unused)
        // openStatusAttachSheet() did.
        int[] chatOnlyOptionIds = {
                com.callx.app.chat.R.id.opt_document, com.callx.app.chat.R.id.opt_poll,
                com.callx.app.chat.R.id.opt_contact, com.callx.app.chat.R.id.opt_location,
                com.callx.app.chat.R.id.opt_payment, com.callx.app.chat.R.id.opt_event,
                com.callx.app.chat.R.id.opt_ai_images
        };
        for (int id : chatOnlyOptionIds) {
            View opt = v.findViewById(id);
            if (opt != null) opt.setVisibility(View.GONE);
        }
        View optGallery = v.findViewById(com.callx.app.chat.R.id.opt_gallery);
        if (optGallery != null) optGallery.setOnClickListener(x -> { sheet.dismiss(); imagePicker.launch("image/*"); });

        // Inject the 5-chip action row (Text/Music/Layout/Voice/AI images)
        // right below the drag handle, above the icon grid/Recents strip —
        // its height simply folds into top_content's measured height, which
        // AttachSheetRecentMediaBinder already uses to compute the sheet's
        // collapsed peekHeight, so no extra plumbing is needed for it to
        // show correctly in both collapsed and expanded state.
        View topContentView = v.findViewById(com.callx.app.chat.R.id.top_content);
        android.view.ViewGroup topContent = topContentView instanceof android.view.ViewGroup
                ? (android.view.ViewGroup) topContentView : null;
        View actionRow = getLayoutInflater().inflate(
                com.callx.app.status.R.layout.bottom_sheet_status_add, topContent, false);
        if (topContent != null) topContent.addView(actionRow, 1);

        // Text → switch to text-only mode
        View btnText = actionRow.findViewById(com.callx.app.status.R.id.status_add_btn_text);
        if (btnText != null) btnText.setOnClickListener(x -> {
            sheet.dismiss();
            // Show text input area (same as typing a text status)
            if (binding.tilText != null) {
                binding.tilText.setVisibility(View.VISIBLE);
                binding.tilText.requestFocus();
            }
        });

        // Music → open music sticker picker
        View btnMusic = actionRow.findViewById(com.callx.app.status.R.id.status_add_btn_music);
        if (btnMusic != null) btnMusic.setOnClickListener(x -> {
            sheet.dismiss();
            openStickerPicker();
        });

        // Layout → open layout picker activity
        View btnLayout = actionRow.findViewById(com.callx.app.status.R.id.status_add_btn_layout);
        if (btnLayout != null) btnLayout.setOnClickListener(x -> {
            sheet.dismiss();
            openLayoutPicker();
        });

        // Voice → record voice note for status
        View btnVoice = actionRow.findViewById(com.callx.app.status.R.id.status_add_btn_voice);
        if (btnVoice != null) btnVoice.setOnClickListener(x -> {
            sheet.dismiss();
            Intent voiceIntent = new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
            if (voiceIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(voiceIntent, 9022);
            } else {
                toast("No audio recorder found on this device");
            }
        });

        // AI Images → show AI prompt input
        View btnAi = actionRow.findViewById(com.callx.app.status.R.id.status_add_btn_ai_images);
        if (btnAi != null) btnAi.setOnClickListener(x -> {
            sheet.dismiss();
            showAiImagePromptDialog();
        });

        // Recents strip + expandable grid — same shared binder ChatMediaController
        // and GroupChatActivity use, wired to Status's own posting/edit flow.
        com.callx.app.conversation.controllers.AttachSheetRecentMediaBinder.bind(
                this, sheet, v, statusAttachMediaExecutor,
                // supportsViewOnce=false — Status doesn't need this toggle
                // (already ephemeral/24h), so hide it entirely instead of
                // leaving a dead control sitting in the sheet.
                false,
                new com.callx.app.conversation.controllers.AttachSheetRecentMediaBinder.Callbacks() {
                    @Override public void onCameraTapped() {
                        sheet.dismiss();
                        openReelCamera();
                    }
                    @Override public void onMoreAppsRequested() {
                        sheet.dismiss();
                        imagePicker.launch("image/*");
                    }
                    @Override public void onSeeMoreRequested() {
                        sheet.dismiss();
                        imagePicker.launch("image/*");
                    }
                    @Override public void onMediaSend(
                            java.util.List<com.callx.app.conversation.controllers.RecentMediaLoader.Item> items,
                            String caption, boolean isHD, boolean isViewOnce) {
                        if (items.isEmpty()) return;
                        sheet.dismiss();
                        String cap = caption == null || caption.isEmpty() ? null : caption;
                        // v238 BUG FIX: picking a single photo/video in the attach
                        // sheet and tapping "Send" used to upload + post it
                        // straight away (postStatusBatch) with zero chance to see
                        // it, add a caption, change privacy/expiry, or add
                        // stickers first — unlike every other single-media entry
                        // point (gallery pick, camera capture, layout) which all
                        // land back on THIS screen's own preview + Post button
                        // first. Route single selections through that same
                        // preview pipeline instead, so Post is still one manual
                        // tap on this screen — same as the layout flow.
                        if (items.size() == 1) {
                            com.callx.app.conversation.controllers.RecentMediaLoader.Item item = items.get(0);
                            showSinglePickedPreview(item.uri, item.isVideo, cap);
                            return;
                        }
                        java.util.List<Uri> uris = new java.util.ArrayList<>();
                        java.util.List<Boolean> videoFlags = new java.util.ArrayList<>();
                        for (com.callx.app.conversation.controllers.RecentMediaLoader.Item item : items) {
                            uris.add(item.uri);
                            videoFlags.add(item.isVideo);
                        }
                        postStatusBatch(uris, videoFlags, cap);
                    }
                    @Override public void onMediaEdit(
                            java.util.List<com.callx.app.conversation.controllers.RecentMediaLoader.Item> items,
                            String caption, boolean isHD) {
                        if (items.isEmpty()) return;
                        sheet.dismiss();

                        // NEW: a single picked VIDEO's pencil/Edit action now opens
                        // the real Reel Edit screen (feature-reels' ReelEditorActivity
                        // — filters/effects/speed/stickers/trim/sound, the same full
                        // editor Reels itself uses) instead of the limited chat-grade
                        // MediaEditActivity (trim-only for video, no filters/effects).
                        // Reused as-is, no duplicate editor code: launched by class
                        // name (feature-status can't depend on feature-reels) with
                        // EXTRA_TARGET_STATUS=true — the same flag/return-path
                        // ReelCameraActivity → ReelEditorActivity already uses for
                        // Status's own camera button, wired to reelCameraLauncher /
                        // handleReelCameraResult() so it lands back on THIS screen's
                        // preview (tapping the editor's back arrow or Done both just
                        // return here, exactly like every other single-media entry
                        // point on this screen).
                        if (items.size() == 1 && items.get(0).isVideo) {
                            Uri videoUri = items.get(0).uri;
                            Intent reelEditIntent = new Intent();
                            reelEditIntent.setClassName(getPackageName(), "com.callx.app.editor.ReelEditorActivity");
                            reelEditIntent.putExtra("editor_video_uri", videoUri.toString());
                            reelEditIntent.putExtra("is_file_path", false);
                            reelEditIntent.putExtra("target_status", true);
                            reelEditIntent.putExtra("allow_media_edit_fallback", true);
                            reelEditIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            if (reelEditIntent.resolveActivity(getPackageManager()) != null) {
                                pendingSingleVideoEditCaption = (caption == null || caption.isEmpty()) ? null : caption;
                                reelCameraLauncher.launch(reelEditIntent);
                                return;
                            }
                            // Reels module not present on this build — fall through
                            // to the chat-grade editor below, same fallback pattern
                            // openReelCamera() uses.
                        }

                        // Same idea as the video branch above, for a single picked
                        // PHOTO: pencil/Edit now opens the real Reel Photo Edit
                        // screen (feature-reels' ReelPhotoEditorActivity —
                        // filters/effects/caption/stickers/adjust, titled "Edit
                        // Status" via target_status) instead of the chat-grade
                        // MediaEditActivity directly. allow_media_edit_fallback
                        // still sends it on to MediaEditActivity afterwards (Back
                        // or Done), so the final result — and where it lands back
                        // on this screen — is identical either way; only the
                        // editor in front of it is richer now. Same
                        // reelCameraLauncher/handleReelCameraResult this screen's
                        // other entry points already share.
                        if (items.size() == 1 && !items.get(0).isVideo) {
                            Uri photoUri = items.get(0).uri;
                            Intent photoEditIntent = new Intent();
                            photoEditIntent.setClassName(getPackageName(), "com.callx.app.editor.ReelPhotoEditorActivity");
                            photoEditIntent.putExtra("photo_editor_uri", photoUri.toString());
                            photoEditIntent.putExtra("photo_editor_index", 0);
                            photoEditIntent.putExtra("photo_editor_count", 1);
                            photoEditIntent.putExtra("target_status", true);
                            photoEditIntent.putExtra("allow_media_edit_fallback", true);
                            photoEditIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            if (photoEditIntent.resolveActivity(getPackageManager()) != null) {
                                pendingSingleVideoEditCaption = (caption == null || caption.isEmpty()) ? null : caption;
                                reelCameraLauncher.launch(photoEditIntent);
                                return;
                            }
                            // Reels module not present on this build — fall through
                            // to the chat-grade editor below.
                        }

                        java.util.ArrayList<String> uriStrings = new java.util.ArrayList<>();
                        java.util.ArrayList<Integer> videoFlags = new java.util.ArrayList<>();
                        for (com.callx.app.conversation.controllers.RecentMediaLoader.Item item : items) {
                            uriStrings.add(item.uri.toString());
                            videoFlags.add(item.isVideo ? 1 : 0);
                        }
                        Intent intent = new Intent(NewStatusActivity.this,
                                com.callx.app.conversation.controllers.MediaEditActivity.class);
                        intent.putStringArrayListExtra(
                                com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_URIS, uriStrings);
                        intent.putIntegerArrayListExtra(
                                com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_IS_VIDEO, videoFlags);
                        intent.putExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_CAPTION, caption);
                        intent.putExtra(com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_HD, isHD);
                        statusMediaEditLauncher.launch(intent);
                    }
                });

        sheet.setContentView(v);
        sheet.show();
    }

    /** v216: Opens StatusLayoutPickerActivity to select 1-6 photos + layout style. */
    private void openLayoutPicker() {
        Intent intent = new Intent(this, StatusLayoutPickerActivity.class);
        layoutPickerLauncher.launch(intent);
    }

    /**
     * v237: Opens MediaEditActivity on the single already-flattened layout
     * collage file, so the person can crop/filter/draw/add text on their
     * chosen layout exactly like any other status photo — as ONE image,
     * never as the individual photos it was built from.
     */
    private void openLayoutEditor(Uri composedCollageUri) {
        java.util.ArrayList<String> uriStrings = new java.util.ArrayList<>();
        uriStrings.add(composedCollageUri.toString());
        java.util.ArrayList<Integer> videoFlags = new java.util.ArrayList<>();
        videoFlags.add(0); // the collage is always a flattened image, never a video

        Intent intent = new Intent(this, com.callx.app.conversation.controllers.MediaEditActivity.class);
        intent.putStringArrayListExtra(
                com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_URIS, uriStrings);
        intent.putIntegerArrayListExtra(
                com.callx.app.conversation.controllers.MediaEditActivity.EXTRA_IS_VIDEO, videoFlags);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        layoutMediaEditLauncher.launch(intent);
    }

    /**
     * Shared MediaEditActivity result handler — used directly by
     * statusMediaEditLauncher (attach sheet's plain Edit action), AND by
     * handleReelCameraResult() when ReelEditorActivity forwards a result it
     * received FROM MediaEditActivity (see ReelEditorActivity's
     * allowMediaEditFallback / goBackOrToMediaEdit() — backing out of the
     * Reel Edit screen for an already-picked video opens this same media
     * editing screen, whose result is transparently passed through). Kept
     * as one method so both paths land on the exact same preview pipeline
     * instead of duplicating this logic.
     */
    private void handleMediaEditActivityResult(int resultCode, Intent data) {
        if (resultCode != android.app.Activity.RESULT_OK || data == null) return;
        java.util.ArrayList<String> uriStrings = data.getStringArrayListExtra(
                com.callx.app.conversation.controllers.MediaEditActivity.RESULT_URIS);
        if (uriStrings == null || uriStrings.isEmpty()) return;
        String caption = data.getStringExtra(
                com.callx.app.conversation.controllers.MediaEditActivity.RESULT_CAPTION);
        String cap = caption == null || caption.isEmpty() ? null : caption;
        // v238 BUG FIX: editing a single photo/video from the attach
        // sheet used to auto-upload + post it immediately
        // (postStatusBatch) the moment MediaEditActivity returned —
        // with no preview, no chance to set privacy/expiry/stickers,
        // unlike every other single-media entry point on this screen
        // (gallery pick, camera, layout). A single edited item now
        // goes through that exact same pickedImage/pickedVideo +
        // showImagePreview()/showVideoPreview() pipeline instead, so
        // Post is still one manual tap on this screen — same as the
        // layout flow. Multi-item edits (2+) keep posting as a batch,
        // same as before.
        if (uriStrings.size() == 1) {
            Uri u = Uri.parse(uriStrings.get(0));
            String mime = getContentResolver().getType(u);
            boolean isVideo = mime != null && mime.startsWith("video");
            showSinglePickedPreview(u, isVideo, cap);
            return;
        }
        java.util.List<Uri> uris = new java.util.ArrayList<>();
        java.util.List<Boolean> videoFlags = new java.util.ArrayList<>();
        for (String s : uriStrings) {
            Uri u = Uri.parse(s);
            uris.add(u);
            String mime = getContentResolver().getType(u);
            videoFlags.add(mime != null && mime.startsWith("video"));
        }
        // Layout no longer routes through MediaEditActivity (see
        // layoutPickerLauncher below), so multi-item results here are
        // always the plain multi-select attach-sheet flow — post each
        // edited photo as its own status. Advance Editing only ever sends
        // a single video in, but clear its flag defensively so a stray
        // multi-item result can never leave it armed for a later edit.
        pendingAdvanceEditWizardJump = false;
        postStatusBatch(uris, videoFlags, cap);
    }

    /** v216: AI image prompt dialog — opens text input, result generates an AI image for status. */
    private void showAiImagePromptDialog() {
        android.widget.EditText et = new android.widget.EditText(this);
        et.setHint("Describe the image you want…");
        AlertDialogStyler.showRounded(new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("AI Image for Status")
            .setView(et)
            .setPositiveButton("Generate", (d, w) -> {
                String prompt = et.getText().toString().trim();
                if (!prompt.isEmpty()) {
                    toast("AI image generation coming soon…");
                }
            })
            .setNegativeButton("Cancel", null)
            .create());
    }

    // ── Attach sheet (Gallery) — reuses feature-chat's shared sheet ────────
    // Same bottom_sheet_attach.xml + AttachSheetRecentMediaBinder that
    // ChatMediaController (1-1 chat) and GroupChatActivity already share, so
    // Status gets the same multi-select grid, caption field, Edit action and
    // view-once toggle instead of a 3rd hand-rolled picker.
    private final java.util.concurrent.ExecutorService statusAttachMediaExecutor =
            java.util.concurrent.Executors.newSingleThreadExecutor();

    // ── Media pickers (gallery) ───────────────────────────────────────────
    private void setupMediaPickers() {
        imagePicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            pickedImage = uri; pickedVideo = null;
            showImagePreview(uri);
        });
        videoPicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            pickedVideo = uri; pickedImage = null;
            showVideoPreview(uri);
        });
    }
    // ── Camera capture (NEW) ──────────────────────────────────────────────
    private void setupCameraCapture() {
        cameraCapture = registerForActivityResult(
            new ActivityResultContracts.TakePicture(), success -> {
                if (success && cameraImageUri != null) {
                    pickedImage = cameraImageUri; pickedVideo = null;
                    showImagePreview(cameraImageUri);
                }
            });
        cameraVideoCapture = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                // Video from camera intent — handled via system camera
                if (uri == null) return;
                pickedVideo = uri; pickedImage = null;
                showVideoPreview(uri);
            });
    }
    private void captureFromCamera() {
        if (!hasCameraPermission()) { requestCameraPermission(); return; }
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "status_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cameraImageUri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (cameraImageUri != null) cameraCapture.launch(cameraImageUri);
        } catch (Exception e) {
            toast("Camera error: " + e.getMessage());
        }
    }

    // ── Reels camera (NEW) — same camera as Reels tab's + / Create button ──
    /**
     * Opens feature-reels' ReelCameraActivity — the full-feature camera
     * (filters, effects, speed control, stickers, text overlays, trending
     * audio, drafts, multi-clip) instead of the plain photo-only system
     * camera. Launched by class name (no compile-time module dependency)
     * since feature-status can't depend on feature-reels.
     *
     * The camera → editor chain is told target_status=true, which makes it
     * hand the finished video back here as an activity result (see
     * ReelCameraActivity / ReelEditorActivity) instead of continuing on
     * into the Reels upload/post flow.
     */
    /**
     * "Advance Editing" — Create step, media already picked. Routes to
     * whichever full-featured editor matches the picked media type, then —
     * because allow_media_edit_fallback is set on both — on to
     * MediaEditActivity ("media editing screen") either way, before landing
     * back on Add Status at the Edit step (step 2). Both branches reuse
     * reelCameraLauncher/handleReelCameraResult, the exact code the attach
     * sheet's pencil/Edit action already relies on, so the round trip is
     * identical to that path except for pendingAdvanceEditWizardJump, which
     * is what makes the result land on step 2 instead of staying on Create.
     */
    private void openAdvanceEditingForPickedMedia() {
        if (pickedVideo != null) {
            openAdvanceEditingForPickedVideo();
        } else if (pickedImage != null) {
            openAdvanceEditingForPickedImage();
        } else {
            toast("Pehle photo ya video select karo");
        }
    }

    /** Video branch — opens the real Reel Edit screen (feature-reels'
     *  ReelEditorActivity), same as the attach sheet's pencil/Edit action. */
    private void openAdvanceEditingForPickedVideo() {
        Intent reelEditIntent = new Intent();
        reelEditIntent.setClassName(getPackageName(), "com.callx.app.editor.ReelEditorActivity");
        reelEditIntent.putExtra("editor_video_uri", pickedVideo.toString());
        reelEditIntent.putExtra("is_file_path", false);
        reelEditIntent.putExtra("target_status", true);
        reelEditIntent.putExtra("allow_media_edit_fallback", true);
        reelEditIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (reelEditIntent.resolveActivity(getPackageManager()) == null) {
            toast("Advance editing is not available on this build");
            return;
        }
        String existingCaption = binding.etCaption != null && binding.etCaption.getText() != null
                ? binding.etCaption.getText().toString().trim() : null;
        pendingSingleVideoEditCaption = (existingCaption == null || existingCaption.isEmpty())
                ? null : existingCaption;
        pendingAdvanceEditWizardJump = true;
        reelCameraLauncher.launch(reelEditIntent);
    }

    /** Photo branch — opens the real Reel Photo Edit screen (feature-reels'
     *  ReelPhotoEditorActivity: filters/effects/caption/stickers/adjust),
     *  same "Edit Status"-titled screen the attach sheet's pencil/Edit
     *  action would open for a single picked photo. */
    private void openAdvanceEditingForPickedImage() {
        Intent photoEditIntent = new Intent();
        photoEditIntent.setClassName(getPackageName(), "com.callx.app.editor.ReelPhotoEditorActivity");
        photoEditIntent.putExtra("photo_editor_uri", pickedImage.toString());
        photoEditIntent.putExtra("photo_editor_index", 0);
        photoEditIntent.putExtra("photo_editor_count", 1);
        photoEditIntent.putExtra("target_status", true);
        photoEditIntent.putExtra("allow_media_edit_fallback", true);
        photoEditIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (photoEditIntent.resolveActivity(getPackageManager()) == null) {
            toast("Advance editing is not available on this build");
            return;
        }
        String existingCaption = binding.etCaption != null && binding.etCaption.getText() != null
                ? binding.etCaption.getText().toString().trim() : null;
        // Shared with the video branch — handleReelCameraResult()'s photo-mode
        // path (is_photo=true) doesn't currently read a preset caption back
        // in, but keeping this set costs nothing and matches the video branch
        // if that ever changes.
        pendingSingleVideoEditCaption = (existingCaption == null || existingCaption.isEmpty())
                ? null : existingCaption;
        pendingAdvanceEditWizardJump = true;
        reelCameraLauncher.launch(photoEditIntent);
    }

    private void openReelCamera() {
        try {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.callx.app.camera.ReelCameraActivity");
            intent.putExtra("target_status", true);
            if (intent.resolveActivity(getPackageManager()) == null) {
                // Reels module not present on this build — fall back to the plain camera.
                captureFromCamera();
                return;
            }
            reelCameraLauncher.launch(intent);
        } catch (Exception e) {
            toast("Camera error: " + e.getMessage());
            captureFromCamera();
        }
    }

    /**
     * Handles the result bubbled back from ReelCameraActivity → ReelEditorActivity,
     * AND from ReelEditorActivity opened directly on an already-picked video via
     * the attach sheet's pencil/Edit action (see onMediaEdit() in showStatusAddSheet())
     * — both return the same result shape via ReelEditorActivity.finishForStatusResult().
     */
    private void handleReelCameraResult(androidx.activity.result.ActivityResult result) {
        // Only relevant to the pencil-edit-video path; always cleared here so a
        // later plain camera round-trip never picks up a stale caption.
        String presetCaption = pendingSingleVideoEditCaption;
        pendingSingleVideoEditCaption = null;
        if (result.getResultCode() != RESULT_OK || result.getData() == null) {
            // Cancelled out of the Reel Edit screen entirely (not the
            // allow_media_edit_fallback hop) — don't leave the Advance
            // Editing flag armed for some unrelated later result.
            pendingAdvanceEditWizardJump = false;
            return;
        }
        Intent data = result.getData();

        // NEW: backing out of the Reel Edit screen (opened directly on an
        // already-picked video — see allow_media_edit_fallback above)
        // forwards MediaEditActivity's own result through unchanged, rather
        // than a normal "finished editing in Reel Edit" result. Recognise
        // that shape (MediaEditActivity.RESULT_URIS) and hand it to the
        // exact same handler the plain attach-sheet Edit action uses, so
        // both paths land on the identical preview pipeline.
        if (data.hasExtra(com.callx.app.conversation.controllers.MediaEditActivity.RESULT_URIS)) {
            handleMediaEditActivityResult(result.getResultCode(), data);
            return;
        }

        // NEW: Photo mode — ReelCameraActivity bakes the filter/overlays itself
        // and returns the JPEG directly (no video editor in the loop).
        boolean isPhoto = data.getBooleanExtra("is_photo", false);
        String photoUriStr = data.getStringExtra("photo_uri");
        if (isPhoto && photoUriStr != null && !photoUriStr.isEmpty()) {
            Uri photoUri = Uri.fromFile(new java.io.File(photoUriStr));
            String caption = data.getStringExtra("text_overlay");
            showSinglePickedPreview(photoUri, false, caption);
            attachMusicStickerIfAny(data);
            return;
        }

        String videoUriStr = data.getStringExtra("video_uri");
        if (videoUriStr == null || videoUriStr.isEmpty()) return;
        boolean isFilePath  = data.getBooleanExtra("is_file_path", true);
        Uri videoUri = isFilePath
                ? Uri.fromFile(new java.io.File(videoUriStr))
                : Uri.parse(videoUriStr);

        String caption = data.getStringExtra("text_overlay");
        if ((caption == null || caption.isEmpty()) && presetCaption != null) caption = presetCaption;
        showSinglePickedPreview(videoUri, true, caption);
        attachMusicStickerIfAny(data);

        // ✅ FIX: pick up the custom cover frame from the Thumbnail tool (see
        // pendingCustomThumbnailFile javadoc) — must run AFTER
        // showSinglePickedPreview/showVideoPreview above, which clears it.
        String customThumbPath = data.getStringExtra("thumbnail_path");
        if (customThumbPath != null && !customThumbPath.isEmpty()) {
            java.io.File f = new java.io.File(customThumbPath);
            if (f.exists()) pendingCustomThumbnailFile = f;
        }
    }

    /**
     * If a trending-audio sound was picked in the camera, attach it as a
     * Music sticker on the status preview — same sticker/JSON format used
     * by StatusStickerPickerSheet's own "🎵 Music" option.
     */
    private void attachMusicStickerIfAny(Intent data) {
        String soundTitle = data.getStringExtra("selected_sound_title");
        if (soundTitle == null || soundTitle.isEmpty()) return;
        String soundId  = data.getStringExtra("selected_sound_id");
        String soundUrl = data.getStringExtra("selected_sound_url");
        try {
            org.json.JSONObject musicJson = new org.json.JSONObject();
            musicJson.put("type",     "music");
            musicJson.put("song",     soundTitle);
            musicJson.put("artist",   "");
            musicJson.put("soundId",  soundId  != null ? soundId  : "");
            musicJson.put("soundUrl", soundUrl != null ? soundUrl : "");
            String json = musicJson.toString();
            addedStickerJsons.add(json);
            addStickerOverlay(json);
        } catch (Exception ignored) {}
    }

    private void captureVideoFromCamera() {
        if (!hasCameraPermission()) { requestCameraPermission(); return; }
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 30); // 30s max
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 9021);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 9021 && resultCode == RESULT_OK && data != null) {
            Uri videoUri = data.getData();
            if (videoUri != null) { pickedVideo = videoUri; pickedImage = null; showVideoPreview(videoUri); }
        }
    }
    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }
    private void requestCameraPermission() {
        registerForActivityResult(new ActivityResultContracts.RequestPermission(),
            granted -> { if (!granted) toast("Camera permission denied"); })
            .launch(Manifest.permission.CAMERA);
    }
    // ── GIF / Sticker input (NEW) ─────────────────────────────────────────
    private void showGifInputDialog() {
        EditText et = new EditText(this);
        et.setHint("Paste GIF or sticker URL…");
        AlertDialogStyler.showRounded(new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Add GIF / Sticker")
            .setView(et)
            .setPositiveButton("Preview", (d, w) -> {
                String url = et.getText().toString().trim();
                if (url.isEmpty()) return;
                fetchedPreview = null;
                pickedImage = Uri.parse(url); pickedVideo = null;
                showImagePreview(pickedImage);
                // Tag as gif type
                binding.btnPickImage.setTag("gif");
            })
            .setNegativeButton("Cancel", null)
            .create());
    }
    // ── Privacy button (NEW bottom sheet) ────────────────────────────────
    private void setupPrivacyButton() {
        selectedPrivacy = StatusPrivacyManager.getPrivacyMode(this);
        updatePrivacyLabel();
        binding.btnPrivacy.setOnClickListener(v -> {
            String myUid = safeUid();
            if (myUid == null) return;
            StatusPrivacyBottomSheet.show(this, myUid, (mode, uids) -> {
                selectedPrivacy = mode;
                privacyUids     = uids;
                if ("close_friends".equals(mode)) isCloseFriends = true;
                updatePrivacyLabel();
            });
        });
    }
    private void updatePrivacyLabel() {
        String label;
        switch (selectedPrivacy) {
            case StatusPrivacyManager.PRIVACY_EVERYONE: label = "👁 Everyone"; break;
            case StatusPrivacyManager.PRIVACY_CONTACTS: label = "👥 My contacts"; break;
            case StatusPrivacyManager.PRIVACY_EXCEPT:   label = "👥 Contacts except…"; break;
            case StatusPrivacyManager.PRIVACY_ONLY:     label = "🔒 Only share with…"; break;
            case "close_friends":                       label = "⭐ Close friends"; break;
            default: label = "👥 My contacts";
        }
        binding.btnPrivacy.setText(label);
    }
    // ── Expiry button (NEW) ───────────────────────────────────────────────
    private void setupExpiryButton() {
        updateExpiryLabel();
        View btnExpiry = binding.getRoot().findViewWithTag("btn_expiry");
        if (btnExpiry instanceof Button) {
            ((Button) btnExpiry).setOnClickListener(v -> showExpiryPicker());
        }
    }
    private void showExpiryPicker() {
        String[] labels = StatusCustomExpiryHelper.getLabelOptions();
        int[] hours     = StatusCustomExpiryHelper.getHoursOptions();
        AlertDialogStyler.showRounded(new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Status expires in…")
            .setItems(labels, (d, which) -> {
                selectedExpiryHours = hours[which];
                updateExpiryLabel();
            }).create());
    }
    private void updateExpiryLabel() {
        View btn = binding.getRoot().findViewWithTag("btn_expiry");
        if (btn instanceof Button)
            ((Button) btn).setText("⏱ " + StatusCustomExpiryHelper.labelFor(selectedExpiryHours));
    }
    // ── Close friends toggle (NEW) ────────────────────────────────────────
    private void setupCloseFriendsToggle() {
        View toggle = binding.getRoot().findViewWithTag("toggle_close_friends");
        if (toggle instanceof CompoundButton) {
            ((CompoundButton) toggle).setOnCheckedChangeListener((btn, checked) -> {
                isCloseFriends = checked;
                if (checked) {
                    selectedPrivacy = "close_friends";
                    updatePrivacyLabel();
                }
            });
        }
    }
    // ── Allow sharing toggle (NEW — mirrors WhatsApp "Allow sharing") ────────
    /**
     * Looks for a CompoundButton with tag "toggle_allow_sharing" in the layout.
     * When the user turns it OFF, allowSharing=false is saved with the status
     * and the repost icon is hidden from viewers in StatusViewerActivity.
     * Default is ON (true) — same behaviour as WhatsApp.
     */
    private void setupAllowSharingToggle() {
        View toggle = binding.getRoot().findViewWithTag("toggle_allow_sharing");
        if (toggle instanceof CompoundButton) {
            ((CompoundButton) toggle).setChecked(true); // default: allow sharing
            ((CompoundButton) toggle).setOnCheckedChangeListener((btn, checked) -> {
                allowSharing = checked;
            });
        }
        // If toggle doesn't exist in the current layout, allowSharing stays true (safe default)
    }
    // ── Level-stabilizer toggle (per-story opt-IN) ────────────────────────
    /**
     * Looks for a CompoundButton with tag "toggle_stabilizer" in the layout.
     * OFF by default — the story only gets the level-stabilizer when the
     * creator explicitly switches this on for THIS post. Leaving it off (or
     * having no such toggle in the layout) means stabilizerEnabled stays
     * false, so ordinary stories never pick up the effect and it never
     * shows up in Highlights either.
     */
    private void setupStabilizerToggle() {
        View toggle = binding.getRoot().findViewWithTag("toggle_stabilizer");
        if (toggle instanceof CompoundButton) {
            ((CompoundButton) toggle).setChecked(false);
            ((CompoundButton) toggle).setOnCheckedChangeListener((btn, checked) -> {
                stabilizerEnabled = checked;
            });
        }
    }
    // ── Ring color button (NEW — reuses the Highlights ring-color-picker) ──
    /**
     * Looks for a Button/View tagged "btn_ring_color" in the layout. Tapping
     * it opens the exact same {@link com.callx.app.highlights.HighlightRingColorPickerBottomSheet}
     * used to color a Highlights album, so the picked color/mode is saved on
     * THIS status (item.ringColor / item.ringMode) and shows up as a custom
     * ring around the owner's avatar on every viewer's status-tab card.
     */
    private void setupRingColorButton() {
        View btn = binding.getRoot().findViewWithTag("btn_ring_color");
        if (btn == null) return;
        updateRingColorLabel(btn);
        btn.setOnClickListener(v ->
            com.callx.app.highlights.HighlightRingColorPickerBottomSheet.show(
                this, selectedRingColor, selectedRingMode, selectedRingColor != null,
                (colorHex, mode) -> {
                    selectedRingColor = colorHex;
                    selectedRingMode  = mode;
                    updateRingColorLabel(btn);
                }));
    }
    private void updateRingColorLabel(View btn) {
        if (btn instanceof Button) {
            ((Button) btn).setText(selectedRingColor != null ? "\u26AA Ring color set" : "\u26AA Ring color");
        }
    }
    // ── Text align buttons (NEW) ──────────────────────────────────────────
    private void setupTextAlignButtons() {
        View btnLeft   = binding.getRoot().findViewWithTag("btn_align_left");
        View btnCenter = binding.getRoot().findViewWithTag("btn_align_center");
        View btnRight  = binding.getRoot().findViewWithTag("btn_align_right");
        if (btnLeft   != null) btnLeft.setOnClickListener(v -> setTextAlign("left"));
        if (btnCenter != null) btnCenter.setOnClickListener(v -> setTextAlign("center"));
        if (btnRight  != null) btnRight.setOnClickListener(v -> setTextAlign("right"));
    }
    private void setTextAlign(String align) {
        selectedTextAlign = align;
        refreshStepPreview();
    }
    // ── Bg color picker ───────────────────────────────────────────────────
    private void setupBgColorPicker() {
        for (int i = 0; i < BG_COLORS.length; i++) {
            final int idx = i;
            View swatch = getBgSwatch(i);
            if (swatch == null) continue;
            swatch.setBackgroundColor(BG_COLORS[i]);
            swatch.setOnClickListener(v -> {
                selectedBgColor = BG_COLORS[idx]; selectedTextColor = TEXT_COLORS_FOR_BG[idx];
                updateTextStatusPreview(); highlightSwatch(idx);
            });
        }
        highlightSwatch(0);
    }
    private View getBgSwatch(int idx) {
        try {
            int id = getResources().getIdentifier("color_swatch_" + idx, "id", getPackageName());
            return id != 0 ? findViewById(id) : null;
        } catch (Exception e) { return null; }
    }
    private void highlightSwatch(int sel) {
        for (int i = 0; i < BG_COLORS.length; i++) {
            View v = getBgSwatch(i);
            if (v != null) { v.setScaleX(i == sel ? 1.3f : 1f); v.setScaleY(i == sel ? 1.3f : 1f); }
        }
    }
    private void hideBgColorPicker() { binding.bgColorPickerRow.setVisibility(View.GONE); }
    private void showBgColorPicker()  { binding.bgColorPickerRow.setVisibility(View.VISIBLE); updateTextStatusPreview(); }
    // ── Font style picker ─────────────────────────────────────────────────
    private void setupFontStylePicker() {
        binding.btnFontDefault.setOnClickListener(v     -> setFont("default"));
        binding.btnFontBold.setOnClickListener(v        -> setFont("bold"));
        binding.btnFontItalic.setOnClickListener(v      -> setFont("italic"));
        binding.btnFontHandwriting.setOnClickListener(v -> setFont("handwriting"));
        View btnCondensed = binding.getRoot().findViewWithTag("btn_font_condensed");
        if (btnCondensed != null) btnCondensed.setOnClickListener(v -> setFont("condensed"));
        View btnSerif = binding.getRoot().findViewWithTag("btn_font_serif");
        if (btnSerif != null) btnSerif.setOnClickListener(v -> setFont("serif"));
    }
    private void setFont(String style) {
        selectedFontStyle = style;
        binding.btnFontDefault.setSelected("default".equals(style));
        binding.btnFontBold.setSelected("bold".equals(style));
        binding.btnFontItalic.setSelected("italic".equals(style));
        binding.btnFontHandwriting.setSelected("handwriting".equals(style));
        updateTextStatusPreview();
    }
    // ── Text input + link detection + mention ────────────────────────────
    private void setupTextInput() {
        binding.etText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                int len = s.length();
                binding.tvCharCount.setText(len + " / 700");
                if (len > 700) binding.tilText.setError("Max 700 characters");
                else           binding.tilText.setError(null);
                updateTextStatusPreview();
                detectAndFetchLinkPreview(s.toString());
            }
        });
    }
    // ── Link preview (NEW) ────────────────────────────────────────────────
    private void detectAndFetchLinkPreview(String text) {
        String url = StatusLinkPreviewHelper.extractUrl(text);
        if (url == null) {
            detectedLinkUrl = null; fetchedPreview = null;
            hideLinkPreview();
            return;
        }
        if (url.equals(detectedLinkUrl)) return;
        detectedLinkUrl = url;
        showLinkPreviewLoading();
        StatusLinkPreviewHelper.fetch(url, new StatusLinkPreviewHelper.Callback() {
            @Override public void onResult(StatusLinkPreviewHelper.LinkPreview preview) {
                fetchedPreview = preview;
                runOnUiThread(() -> {
                    if (preview.isValid()) showLinkPreview(preview);
                    else hideLinkPreview();
                });
            }
            @Override public void onError(String error) {
                fetchedPreview = null;
                runOnUiThread(() -> hideLinkPreview());
            }
        });
    }
    private void showLinkPreviewLoading() {
        View card = binding.getRoot().findViewWithTag("link_preview_card");
        if (card != null) card.setVisibility(View.VISIBLE);
        View pb = binding.getRoot().findViewWithTag("link_preview_progress");
        if (pb != null) pb.setVisibility(View.VISIBLE);
        View content = binding.getRoot().findViewWithTag("link_preview_content");
        if (content != null) content.setVisibility(View.GONE);
    }
    private void showLinkPreview(StatusLinkPreviewHelper.LinkPreview preview) {
        View card = binding.getRoot().findViewWithTag("link_preview_card");
        if (card == null) return;
        card.setVisibility(View.VISIBLE);
        View pb = binding.getRoot().findViewWithTag("link_preview_progress");
        if (pb != null) pb.setVisibility(View.GONE);
        View content = binding.getRoot().findViewWithTag("link_preview_content");
        if (content != null) content.setVisibility(View.VISIBLE);
        TextView tvTitle = binding.getRoot().findViewWithTag("link_preview_title");
        if (tvTitle != null) tvTitle.setText(preview.title);
        TextView tvDesc = binding.getRoot().findViewWithTag("link_preview_desc");
        if (tvDesc != null) tvDesc.setText(preview.description);
        TextView tvDomain = binding.getRoot().findViewWithTag("link_preview_domain");
        if (tvDomain != null) tvDomain.setText(preview.domain);
        android.widget.ImageView ivImage = binding.getRoot().findViewWithTag("link_preview_image");
        if (ivImage != null && preview.imageUrl != null)
            Glide.with(this).load(preview.imageUrl).override(480, 853).into(ivImage);
    }
    private void hideLinkPreview() {
        View card = binding.getRoot().findViewWithTag("link_preview_card");
        if (card != null) card.setVisibility(View.GONE);
    }
    // ── Preview card ──────────────────────────────────────────────────────
    private void updateTextStatusPreview() {
        // status_step_preview_card (bound via refreshStepPreview) is now the
        // single preview for every wizard step — the old duplicate inline
        // card has been removed from the layout entirely.
        refreshStepPreview();
        if (pickedImage != null || pickedVideo != null) return;
        String text = binding.etText.getText().toString().trim();
        if (text.isEmpty()) return;
    }
    private void applyFontStyle(android.widget.TextView tv, String style) {
        if (style == null) return;
        switch (style) {
            case "bold":        tv.setTypeface(null, android.graphics.Typeface.BOLD); break;
            case "italic":      tv.setTypeface(null, android.graphics.Typeface.ITALIC); break;
            case "handwriting": tv.setTypeface(android.graphics.Typeface.MONOSPACE); break;
            case "condensed":   tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); break;
            case "serif":       tv.setTypeface(android.graphics.Typeface.SERIF); break;
            default:            tv.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }
    // ── Draft save/restore ────────────────────────────────────────────────
    private void saveDraft() {
        getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE)
            .edit().putString(KEY_DRAFT, binding.etText.getText().toString()).apply();
    }
    private void restoreDraft() {
        String draft = getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE).getString(KEY_DRAFT, "");
        if (draft != null && !draft.isEmpty()) binding.etText.setText(draft);
    }
    private void clearDraft() {
        getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE).edit().remove(KEY_DRAFT).apply();
    }
    // ── Media preview helpers ─────────────────────────────────────────────
    /**
     * v238: Common landing spot for any single photo/video coming from the
     * attach sheet's "Send" or "Edit" chips — mirrors exactly what gallery
     * pick, camera capture, and the layout flow already do: set
     * pickedImage/pickedVideo, show the preview, optionally seed the
     * caption box, and leave posting to the person's own tap on Post.
     */
    private void showSinglePickedPreview(Uri uri, boolean isVideo, String caption) {
        if (isVideo) {
            pickedVideo = uri; pickedImage = null;
            showVideoPreview(uri);
        } else {
            pickedImage = uri; pickedVideo = null;
            showImagePreview(uri);
        }
        if (caption != null && !caption.isEmpty() && binding.etCaption != null) {
            binding.etCaption.setText(caption);
        }
        // Advance Editing round trip (Reel Edit → Media Editing) lands here
        // like any other single-media result — jump straight to the Edit
        // step (step 2) instead of leaving the person back on Create.
        if (pendingAdvanceEditWizardJump) {
            pendingAdvanceEditWizardJump = false;
            showWizardStep(1);
        }
    }
    private void showImagePreview(Uri uri) {
        binding.ivPreview.setVisibility(View.VISIBLE);
        binding.ivVideoHint.setVisibility(View.GONE);
        binding.btnDiscardMedia.setVisibility(View.VISIBLE);
        // Also show the overlay frame (so stickers are visible over the image)
        if (stickerOverlayFrame != null) stickerOverlayFrame.setVisibility(View.VISIBLE);
        // v238 BUG FIX: .centerCrop() here forcibly cropped the bitmap itself
        // regardless of the ImageView's own scaleType — switched to
        // .fitCenter() so the full photo/layout collage is always visible,
        // matching the taller fitCenter box in the layout.
        Glide.with(this).load(uri).fitCenter().into(binding.ivPreview);
        binding.captionGroup.setVisibility(View.VISIBLE);
        hideBgColorPicker();
        refreshStepPreview();
    }
    private void showVideoPreview(Uri uri) {
        // ✅ FIX: default-clear any earlier custom thumbnail pick — only
        // handleReelCameraResult() re-arms it, right after this call, when
        // the Reel Edit screen actually returned one for THIS video.
        pendingCustomThumbnailFile = null;
        binding.ivPreview.setVisibility(View.VISIBLE);
        binding.ivVideoHint.setVisibility(View.VISIBLE);
        binding.btnDiscardMedia.setVisibility(View.VISIBLE);
        if (stickerOverlayFrame != null) stickerOverlayFrame.setVisibility(View.VISIBLE);
        Glide.with(this).load(uri).fitCenter().into(binding.ivPreview);
        binding.captionGroup.setVisibility(View.VISIBLE);
        hideBgColorPicker();
        refreshStepPreview();
    }
    private void discardMedia() {
        pickedImage = null; pickedVideo = null; cameraImageUri = null;
        pendingCustomThumbnailFile = null;
        binding.ivPreview.setVisibility(View.GONE);
        binding.ivVideoHint.setVisibility(View.GONE);
        binding.btnDiscardMedia.setVisibility(View.GONE);
        binding.captionGroup.setVisibility(View.GONE);
        showBgColorPicker();
        refreshStepPreview();
    }

    /** Returns a JSON array string of all added sticker configs, or "" if none. */
    private String buildStickersJson() {
        if (stickerOverlayFrame == null) return "";
        java.util.List<String> jsons = new java.util.ArrayList<>();
        for (int i = 0; i < stickerOverlayFrame.getChildCount(); i++) {
            View child = stickerOverlayFrame.getChildAt(i);
            if (child instanceof com.callx.app.stickers.StatusStickerOverlayView) {
                jsons.add(((com.callx.app.stickers.StatusStickerOverlayView) child).toJsonWithScale());
            }
        }
        if (jsons.isEmpty()) return "";
        return "[" + android.text.TextUtils.join(",", jsons) + "]";
    }
    // ── Post ──────────────────────────────────────────────────────────────
    private void post() {
        String txt     = binding.etText.getText().toString().trim();
        String caption = binding.etCaption != null ? binding.etCaption.getText().toString().trim() : "";
        boolean isGif  = "gif".equals(binding.btnPickImage.getTag());
        if (pickedImage == null && pickedVideo == null && txt.isEmpty() && fetchedPreview == null) {
            toast("Kuch text ya media add karo"); return;
        }
        if (txt.length() > 700) { toast("Text 700 characters se zyada nahi"); return; }
        setPosting(true);
        String uid  = FirebaseUtils.getCurrentUid();
        String name = FirebaseUtils.getCurrentName();
        FirebaseUtils.getUserRef(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                String thumb = snap.child("thumbUrl").getValue(String.class);
                String full  = snap.child("photoUrl").getValue(String.class);
                String photo = (thumb != null && !thumb.isEmpty()) ? thumb : (full != null ? full : safePhoto());
                dispatchPost(txt, caption, uid, name, photo, isGif);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                dispatchPost(txt, caption, uid, name, safePhoto(), isGif);
            }
        });
    }
    private void dispatchPost(String txt, String caption, String uid, String name, String photo, boolean isGif) {
        if (fetchedPreview != null && pickedImage == null && pickedVideo == null) {
            // Link status
            saveStatus("link", fetchedPreview.imageUrl, null, txt, caption, uid, name, photo);
        } else if (isGif && pickedImage != null) {
            // GIF / sticker — store as sticker type
            saveStatus("gif", pickedImage.toString(), null, txt, caption, uid, name, photo);
        } else if (pickedImage != null) {
            compressAndUploadImage(pickedImage, caption, txt, uid, name, photo);
        } else if (pickedVideo != null) {
            compressAndUploadVideo(pickedVideo, caption, txt, uid, name, photo);
        } else {
            saveStatus("text", null, null, txt, caption, uid, name, photo);
        }
    }
    private void compressAndUploadImage(Uri uri, String caption, String txt, String uid, String name, String photo) {
        runOnUiThread(() -> setHint("Compressing image…"));
        ImageCompressor.compress(this, uri, new ImageCompressor.Callback() {
            @Override public void onSuccess(ImageCompressor.Result r) {
                runOnUiThread(() -> setHint("Uploading image…"));
                uploadAndSave(Uri.fromFile(r.fullFile), "image", caption, txt, uid, name, photo, r.thumbFile);
            }
            @Override public void onError(Exception e) {
                runOnUiThread(() -> setHint("Uploading image…"));
                uploadAndSave(uri, "image", caption, txt, uid, name, photo, null);
            }
        });
    }
    private void compressAndUploadVideo(Uri uri, String caption, String txt, String uid, String name, String photo) {
        runOnUiThread(() -> setHint("Compressing video… 0%"));
        // ✅ FIX: snapshot the Reel Edit screen's custom cover pick now — the
        // person picked it for THIS video, so it should win over whatever
        // frame VideoCompressor auto-grabs below (see pendingCustomThumbnailFile).
        java.io.File customThumb = pendingCustomThumbnailFile;
        VideoQualityPreferences.Quality quality = new VideoQualityPreferences(this).getGlobalQuality();
        VideoCompressor.compress(this, uri, quality, new VideoCompressor.Callback() {
            @Override public void onProgress(int pct) { runOnUiThread(() -> setHint("Compressing video… " + pct + "%")); }
            @Override public void onSuccess(VideoCompressor.Result r) {
                runOnUiThread(() -> setHint("Uploading video…"));
                if (customThumb != null && customThumb.exists()) {
                    // Discard the auto-generated frame, use the person's pick instead.
                    VideoCompressor.safeDelete(r.thumbFile);
                    uploadAndSave(Uri.fromFile(r.videoFile), "video", caption, txt, uid, name, photo, customThumb, true);
                } else {
                    uploadAndSave(Uri.fromFile(r.videoFile), "video", caption, txt, uid, name, photo, r.thumbFile, false);
                }
            }
            @Override public void onError(Exception e) {
                runOnUiThread(() -> setHint("Uploading video…"));
                boolean useCustom = customThumb != null && customThumb.exists();
                uploadAndSave(uri, "video", caption, txt, uid, name, photo,
                    useCustom ? customThumb : null, useCustom);
            }
        });
    }
    private void uploadAndSave(Uri uri, String type, String caption, String txt,
                                String uid, String name, String photo, java.io.File thumbFile) {
        uploadAndSave(uri, type, caption, txt, uid, name, photo, thumbFile, false);
    }
    private void uploadAndSave(Uri uri, String type, String caption, String txt,
                                String uid, String name, String photo, java.io.File thumbFile,
                                boolean forceCustomThumb) {
        String rt = "video".equals(type) ? "video" : "image";
        CloudinaryUploader.upload(this, uri, "callx/status", rt, new CloudinaryUploader.UploadCallback() {
            @Override public void onSuccess(CloudinaryUploader.Result r) {
                runOnUiThread(() -> {
                    setPosting(false);
                    // ✅ FIX: Cloudinary's own r.thumbnailUrl is just its
                    // auto-extracted video frame, which used to always win
                    // over a custom pick from the Reel Edit screen's
                    // Thumbnail tool. When forceCustomThumb is set, hold off
                    // saving a thumbnailUrl until the person's own pick has
                    // uploaded and can patch it in below instead.
                    String thumbUrl = ("video".equals(type) && !forceCustomThumb) ? r.thumbnailUrl : null;
                    if (!forceCustomThumb) VideoCompressor.safeDelete(thumbFile);
                    saveStatus(type, r.secureUrl, thumbUrl, txt, caption, uid, name, photo);
                    // FIX v25: If thumb was locally generated and Cloudinary didn't return one, upload separately
                    if ("video".equals(type) && thumbUrl == null && thumbFile != null && thumbFile.exists()) {
                        uploadThumbAndPatch(thumbFile, uid, r.secureUrl);
                    }
                });
            }
            @Override public void onError(String err) {
                runOnUiThread(() -> { setPosting(false); toast(err != null ? err : "Upload failed, try again"); });
            }
        });
    }
    private void uploadThumbAndPatch(java.io.File thumbFile, String uid, String mediaUrl) {
        Uri thumbUri = Uri.fromFile(thumbFile);
        CloudinaryUploader.upload(this, thumbUri, "callx/status/thumb", "image",
            new CloudinaryUploader.UploadCallback() {
                @Override public void onSuccess(CloudinaryUploader.Result r) {
                    VideoCompressor.safeDelete(thumbFile);
                    // FIX v25: Patch thumbnailUrl on status node — find the status by mediaUrl
                    FirebaseUtils.getStatusRef().child(uid)
                        .orderByChild("mediaUrl").equalTo(mediaUrl).limitToLast(1)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                                for (DataSnapshot c : snap.getChildren())
                                    c.getRef().child("thumbnailUrl").setValue(r.secureUrl);
                            }
                            @Override public void onCancelled(@NonNull DatabaseError e) {}
                        });
                }
                @Override public void onError(String err) { VideoCompressor.safeDelete(thumbFile); }
            });
    }
    private void saveStatus(String type, String mediaUrl, String thumbUrl,
                            String txt, String caption, String uid, String name, String photo) {
        long now = System.currentTimeMillis();
        DatabaseReference ref = FirebaseUtils.getStatusRef().child(uid).push();
        StatusItem item       = new StatusItem();
        item.id               = ref.getKey();
        item.ownerUid         = uid;
        item.ownerName        = name;
        item.ownerPhoto       = photo;
        item.type             = type;
        item.text             = txt.isEmpty() ? null : txt;
        item.caption          = caption.isEmpty() ? null : caption;
        item.mediaUrl         = mediaUrl;
        item.thumbnailUrl     = thumbUrl;
        item.bgColor          = String.format("#%08X", selectedBgColor);
        item.fontStyle        = selectedFontStyle;
        item.textColor        = String.format("#%08X", selectedTextColor);
        item.textAlign        = selectedTextAlign;
        item.privacy          = selectedPrivacy;
        item.privacyList      = privacyUids.isEmpty() ? null : new ArrayList<>(privacyUids);
        item.isCloseFriends   = isCloseFriends;
        item.allowSharing     = allowSharing;
        item.stabilizerEnabled = stabilizerEnabled;
        item.ringColor        = selectedRingColor != null ? selectedRingColor : "";
        item.ringMode         = selectedRingMode  != null ? selectedRingMode  : "";
        item.expiryHours      = selectedExpiryHours;
        item.timestamp        = now;
        item.expiresAt        = StatusCustomExpiryHelper.computeExpiresAt(selectedExpiryHours);
        item.deleted          = false;
        // ── v26: Attach interactive sticker JSON ──────────────────────────
        String stickersJson = buildStickersJson();
        if (!stickersJson.isEmpty()) {
            item.stickersJson = stickersJson;
        }
        // Mentions
        if (txt != null && !txt.isEmpty()) {
            StatusMentionHelper.MentionResult mentions = StatusMentionHelper.extract(txt);
            if (!mentions.mentionedNames.isEmpty()) {
                // Store mention names; UID resolution requires backend lookup
                item.mentionNames = new HashMap<>();
                for (String n : mentions.mentionedNames) item.mentionNames.put(n, "@" + n);
            }
        }
        // Link metadata
        if ("link".equals(type) && fetchedPreview != null) {
            item.linkUrl         = fetchedPreview.url;
            item.linkTitle       = fetchedPreview.title;
            item.linkDescription = fetchedPreview.description;
            item.linkImageUrl    = fetchedPreview.imageUrl;
            item.linkDomain      = fetchedPreview.domain;
        }
        // ── Scheduled post? Route to statusScheduled instead of going live now ──
        if (pendingScheduledAt > 0) {
            long scheduledAt = pendingScheduledAt;
            pendingScheduledAt = 0;
            item.scheduledAt = scheduledAt;
            item.timestamp   = scheduledAt;
            // Expiry must count down from the actual publish time, not from
            // "now" (composition time) — otherwise a status scheduled a day
            // out with a 24h expiry would already be dead on arrival.
            item.expiresAt = scheduledAt + (long) selectedExpiryHours * 3_600_000L;
            com.callx.app.repository.StatusRepository.getInstance(this)
                .scheduleStatus(item, scheduledAt, ok -> runOnUiThread(() -> {
                    if (ok) {
                        clearDraft();
                        String fmt = new java.text.SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
                            .format(new Date(scheduledAt));
                        toast("Status scheduled for " + fmt);
                        finish();
                    } else {
                        setPosting(false);
                        toast("Failed to schedule status");
                    }
                }));
            return;
        }
        ref.setValue(item.toMap())
            .addOnSuccessListener(u -> {
                clearDraft();
                StatusNotificationHelper.scheduleStatusExpiryReminder(this, item.id, item.expiresAt);
                toast("Status posted!");
                finish();
            })
            .addOnFailureListener(e -> {
                setPosting(false);
                toast("Failed to post: " + e.getMessage());
            });
    }
    // ── Batch post (attach-sheet multi-select) ─────────────────────────────
    // Posts each selected item from the attach-sheet as its own status entry
    // (same as WhatsApp posting several picked photos back-to-back), sharing
    // one caption + the screen's current privacy/expiry/close-friends
    // settings across all of them. Kept separate from post()/saveStatus()
    // above so the existing single-item flow (with its own txt/link/gif
    // handling and single finish()) is untouched.
    private java.util.List<Uri>    pendingBatchUris;
    private java.util.List<Boolean> pendingBatchIsVideo;
    private int    pendingBatchIndex;
    private String pendingBatchCaption;

    // BUG FIX (double upload): the layout-picker → edit → post chain reaches
    // postStatusBatch() from an ActivityResult callback. If Done/Send got
    // double-tapped upstream (StatusLayoutPickerActivity / MediaEditActivity —
    // now guarded there too) and the result still arrived twice, this used to
    // re-run the whole batch and upload the same edited photos a second time.
    // One NewStatusActivity screen only ever posts once, so a simple one-shot
    // guard is enough.
    private boolean batchUploadStarted = false;

    private void postStatusBatch(java.util.List<Uri> uris, java.util.List<Boolean> isVideoFlags, String caption) {
        if (uris == null || uris.isEmpty()) return;
        if (batchUploadStarted) return;
        batchUploadStarted  = true;
        pendingBatchUris    = uris;
        pendingBatchIsVideo = isVideoFlags;
        pendingBatchCaption = caption;
        pendingBatchIndex   = 0;
        postNextBatchItem();
    }

    private void postNextBatchItem() {
        if (pendingBatchUris == null || pendingBatchIndex >= pendingBatchUris.size()) {
            setPosting(false);
            if (pendingScheduledAt > 0) {
                String fmt = new java.text.SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
                    .format(new Date(pendingScheduledAt));
                toast("Statuses scheduled for " + fmt);
                pendingScheduledAt = 0;
            } else {
                toast("Status posted!");
            }
            finish();
            return;
        }
        setPosting(true);
        setHint("Posting " + (pendingBatchIndex + 1) + " of " + pendingBatchUris.size() + "…");
        Uri uri          = pendingBatchUris.get(pendingBatchIndex);
        boolean isVideo  = pendingBatchIsVideo.get(pendingBatchIndex);
        String uid       = FirebaseUtils.getCurrentUid();
        String name      = FirebaseUtils.getCurrentName();
        FirebaseUtils.getUserRef(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                String thumb = snap.child("thumbUrl").getValue(String.class);
                String full  = snap.child("photoUrl").getValue(String.class);
                String photo = (thumb != null && !thumb.isEmpty()) ? thumb : (full != null ? full : safePhoto());
                uploadBatchItem(uri, isVideo, pendingBatchCaption, uid, name, photo);
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {
                uploadBatchItem(uri, isVideo, pendingBatchCaption, uid, name, safePhoto());
            }
        });
    }

    private void uploadBatchItem(Uri uri, boolean isVideo, String caption, String uid, String name, String photo) {
        if (isVideo) {
            VideoQualityPreferences.Quality quality = new VideoQualityPreferences(this).getGlobalQuality();
            VideoCompressor.compress(this, uri, quality, new VideoCompressor.Callback() {
                @Override public void onProgress(int pct) { runOnUiThread(() -> setHint("Compressing video… " + pct + "%")); }
                @Override public void onSuccess(VideoCompressor.Result r) {
                    runOnUiThread(() -> setHint("Uploading video…"));
                    uploadBatchAndSave(Uri.fromFile(r.videoFile), "video", caption, uid, name, photo, r.thumbFile);
                }
                @Override public void onError(Exception e) {
                    runOnUiThread(() -> setHint("Uploading video…"));
                    uploadBatchAndSave(uri, "video", caption, uid, name, photo, null);
                }
            });
        } else {
            ImageCompressor.compress(this, uri, new ImageCompressor.Callback() {
                @Override public void onSuccess(ImageCompressor.Result r) {
                    runOnUiThread(() -> setHint("Uploading image…"));
                    uploadBatchAndSave(Uri.fromFile(r.fullFile), "image", caption, uid, name, photo, r.thumbFile);
                }
                @Override public void onError(Exception e) {
                    runOnUiThread(() -> setHint("Uploading image…"));
                    uploadBatchAndSave(uri, "image", caption, uid, name, photo, null);
                }
            });
        }
    }

    private void uploadBatchAndSave(Uri uri, String type, String caption, String uid, String name,
                                     String photo, java.io.File thumbFile) {
        String rt = "video".equals(type) ? "video" : "image";
        CloudinaryUploader.upload(this, uri, "callx/status", rt, new CloudinaryUploader.UploadCallback() {
            @Override public void onSuccess(CloudinaryUploader.Result r) {
                runOnUiThread(() -> {
                    String thumbUrl = "video".equals(type) ? r.thumbnailUrl : null;
                    if (thumbFile != null) VideoCompressor.safeDelete(thumbFile);
                    saveBatchStatus(type, r.secureUrl, thumbUrl, caption, uid, name, photo);
                });
            }
            @Override public void onError(String err) {
                runOnUiThread(() -> {
                    toast((err != null ? err : "Upload failed") + " — skipping item " + (pendingBatchIndex + 1));
                    pendingBatchIndex++;
                    postNextBatchItem();
                });
            }
        });
    }

    private void saveBatchStatus(String type, String mediaUrl, String thumbUrl, String caption,
                                  String uid, String name, String photo) {
        long now = System.currentTimeMillis();
        DatabaseReference ref = FirebaseUtils.getStatusRef().child(uid).push();
        StatusItem item     = new StatusItem();
        item.id             = ref.getKey();
        item.ownerUid       = uid;
        item.ownerName      = name;
        item.ownerPhoto     = photo;
        item.type           = type;
        item.text           = null;
        item.caption        = (caption == null || caption.isEmpty()) ? null : caption;
        item.mediaUrl       = mediaUrl;
        item.thumbnailUrl   = thumbUrl;
        item.bgColor        = String.format("#%08X", selectedBgColor);
        item.fontStyle      = selectedFontStyle;
        item.textColor      = String.format("#%08X", selectedTextColor);
        item.textAlign      = selectedTextAlign;
        item.privacy        = selectedPrivacy;
        item.privacyList    = privacyUids.isEmpty() ? null : new ArrayList<>(privacyUids);
        item.isCloseFriends = isCloseFriends;
        item.allowSharing   = allowSharing;
        item.stabilizerEnabled = stabilizerEnabled;
        item.ringColor      = selectedRingColor != null ? selectedRingColor : "";
        item.ringMode       = selectedRingMode  != null ? selectedRingMode  : "";
        item.expiryHours    = selectedExpiryHours;
        item.timestamp      = now;
        item.expiresAt      = StatusCustomExpiryHelper.computeExpiresAt(selectedExpiryHours);
        item.deleted        = false;
        // ── v26: Attach interactive sticker JSON (was missing — batch-posted
        // statuses never carried stickersJson, so the viewer's audio-name
        // ticker under the owner name never rendered for these items) ──────
        String stickersJson = buildStickersJson();
        if (!stickersJson.isEmpty()) {
            item.stickersJson = stickersJson;
        }
        // ── Scheduled post? Route to statusScheduled instead of going live now ──
        if (pendingScheduledAt > 0) {
            long scheduledAt = pendingScheduledAt;
            item.scheduledAt = scheduledAt;
            item.timestamp   = scheduledAt;
            item.expiresAt   = scheduledAt + (long) selectedExpiryHours * 3_600_000L;
            com.callx.app.repository.StatusRepository.getInstance(this)
                .scheduleStatus(item, scheduledAt, ok -> runOnUiThread(() -> {
                    pendingBatchIndex++;
                    if (!ok) toast("Failed to schedule item " + pendingBatchIndex);
                    postNextBatchItem();
                }));
            return;
        }
        ref.setValue(item.toMap())
            .addOnSuccessListener(u -> {
                StatusNotificationHelper.scheduleStatusExpiryReminder(this, item.id, item.expiresAt);
                pendingBatchIndex++;
                postNextBatchItem();
            })
            .addOnFailureListener(e -> {
                toast("Failed to post item " + (pendingBatchIndex + 1) + ": " + e.getMessage());
                pendingBatchIndex++;
                postNextBatchItem();
            });
    }

    // ── Scheduling ────────────────────────────────────────────────────────

    /**
     * Long-press on "Post" → pick a future date, then a time → stash it in
     * pendingScheduledAt and run the normal post() flow, which now detects
     * the pending schedule and routes the write to statusScheduled instead
     * of the live status tree (see saveStatus()/saveBatchStatus()).
     */
    private void showScheduleDialog() {
        Calendar now = Calendar.getInstance();
        Calendar picked = Calendar.getInstance();

        android.app.DatePickerDialog dateDialog = new android.app.DatePickerDialog(
            this,
            (view, year, month, dayOfMonth) -> {
                picked.set(Calendar.YEAR, year);
                picked.set(Calendar.MONTH, month);
                picked.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                android.app.TimePickerDialog timeDialog = new android.app.TimePickerDialog(
                    this,
                    (timeView, hourOfDay, minute) -> {
                        picked.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        picked.set(Calendar.MINUTE, minute);
                        picked.set(Calendar.SECOND, 0);
                        picked.set(Calendar.MILLISECOND, 0);

                        if (picked.getTimeInMillis() <= System.currentTimeMillis()) {
                            toast("Pick a time in the future");
                            return;
                        }
                        pendingScheduledAt = picked.getTimeInMillis();
                        String fmt = new java.text.SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
                            .format(new Date(pendingScheduledAt));
                        toast("Will be scheduled for " + fmt);
                        post();
                    },
                    now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false);
                timeDialog.show();
            },
            now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
        dateDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        dateDialog.show();
    }

    // ── UI helpers ────────────────────────────────────────────────────────
    private void setPosting(boolean posting) {
        binding.btnPost.setEnabled(!posting);
        binding.btnPost.setText(posting ? "Posting…" : "Post");
        if (binding.uploadProgress != null)
            binding.uploadProgress.setVisibility(posting ? View.VISIBLE : View.GONE);
    }
    private void setHint(String hint) {
        if (binding.tvUploadHint != null) binding.tvUploadHint.setText(hint);
    }

    @Override
    public void onBackPressed() {
        if (wizardStep > 0) {
            showWizardStep(wizardStep - 1);
            return;
        }
        super.onBackPressed();
    }
    private String safePhoto() {
        try { com.google.firebase.auth.FirebaseUser u = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser(); if (u != null && u.getPhotoUrl() != null) return u.getPhotoUrl().toString(); return ""; } catch (Exception e) { return ""; }
    }
    private String safeUid() {
        try { return FirebaseUtils.getCurrentUid(); } catch (Exception e) { return null; }
    }
    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onDestroy() {
        if (activeStepRingSpin != null) activeStepRingSpin.cancel();
        super.onDestroy();
    }
}