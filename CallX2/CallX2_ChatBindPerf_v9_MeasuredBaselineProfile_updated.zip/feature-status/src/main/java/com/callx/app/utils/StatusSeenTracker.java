package com.callx.app.utils;
import com.google.firebase.database.ServerValue;
import java.util.HashMap;
import java.util.Map;
/**
 * StatusSeenTracker v25 — Comprehensive seen/reaction tracking.
 * - markSeen / markSeenBatch: seenBy records + chat bubble (deduped 24h)
 * - reactTo / removeReaction: with UI toggle support
 * - recordViewDuration: analytics support
 * - deleteStatus: soft-delete (owner only)
 * - forwardStatus: increment forwardCount
 */
public final class StatusSeenTracker {
    private static final long DEDUP_WINDOW_MS = 24 * 60 * 60 * 1000L;
    private StatusSeenTracker() {}
    // ── Seen tracking ─────────────────────────────────────────────────────
    public static void markSeen(android.content.Context ctx, String ownerUid, String statusId) {
        if (ownerUid == null || statusId == null) return;
        String myUid = safeUid();
        if (myUid == null || myUid.equals(ownerUid)) return;
        // Optimistic local mark — every ring drawn app-wide (reels, chat,
        // comments, profile) picks this up on next bind, no Firebase wait.
        if (ctx != null) StorySeenState.markSeen(ctx, ownerUid, System.currentTimeMillis());
        FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId).child("seenBy").child(myUid)
            .setValue(ServerValue.TIMESTAMP);
        FirebaseUtils.db().getReference("statusSeen")
            .child(myUid).child(ownerUid).child(statusId)
            .setValue(ServerValue.TIMESTAMP);
    }
    // Legacy overload kept for any callers that don't have a Context handy —
    // still writes to Firebase, just can't optimistically warm the local cache.
    public static void markSeen(String ownerUid, String statusId) {
        markSeen(null, ownerUid, statusId);
    }
    public static void markSeenBatch(android.content.Context ctx, String ownerUid,
                                     Iterable<String> statusIds,
                                     String ownerName, String statusThumbUrl) {
        if (ownerUid == null || statusIds == null) return;
        String myUid = safeUid();
        if (myUid == null || myUid.equals(ownerUid)) return;
        if (ctx != null) StorySeenState.markSeen(ctx, ownerUid, System.currentTimeMillis());
        Map<String, Object> updates = new HashMap<>();
        for (String id : statusIds) {
            if (id != null) {
                updates.put(ownerUid + "/" + id + "/seenBy/" + myUid, ServerValue.TIMESTAMP);
            }
        }
        if (!updates.isEmpty()) FirebaseUtils.getStatusRef().updateChildren(updates);
        String safeOwnerName = ownerName != null ? ownerName : "";
        String safeThumb     = statusThumbUrl != null ? statusThumbUrl : "";
        writeStatusSeenToChat(myUid, ownerUid, safeOwnerName, safeThumb);
    }
    // Legacy overloads (no Context) — still functional, just skip the
    // optimistic local-cache warm; ring will update on next Firebase-driven bind.
    public static void markSeenBatch(String ownerUid, Iterable<String> statusIds,
                                     String ownerName, String statusThumbUrl) {
        markSeenBatch(null, ownerUid, statusIds, ownerName, statusThumbUrl);
    }
    public static void markSeenBatch(String ownerUid, Iterable<String> statusIds) {
        markSeenBatch(null, ownerUid, statusIds, "", "");
    }
    // ── View duration (analytics) ─────────────────────────────────────────
    public static void recordViewDuration(String ownerUid, String statusId, long durationMs) {
        if (ownerUid == null || statusId == null || durationMs < 200) return;
        String myUid = safeUid();
        if (myUid == null || myUid.equals(ownerUid)) return;
        FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId).child("viewDurations").child(myUid)
            .setValue(durationMs);
    }
    // ── Reactions ─────────────────────────────────────────────────────────
    /**
     * React to a status — if same emoji already set, removes it (toggle).
     * If different emoji, replaces it. Returns the new emoji or null if removed.
     */
    public static void reactTo(String ownerUid, String statusId, String emoji,
                                String currentReaction, OnReactionCallback cb) {
        if (ownerUid == null || statusId == null || emoji == null) return;
        String myUid = safeUid();
        if (myUid == null) return;
        com.google.firebase.database.DatabaseReference ref = FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId).child("reactions").child(myUid);
        if (emoji.equals(currentReaction)) {
            // Toggle off — remove reaction
            ref.removeValue().addOnSuccessListener(u -> { if (cb != null) cb.onReaction(null); });
        } else {
            // Set new reaction
            ref.setValue(emoji).addOnSuccessListener(u -> { if (cb != null) cb.onReaction(emoji); });
            // Notify owner (fire-and-forget)
            notifyReaction(ownerUid, statusId, emoji, myUid);
        }
    }
    public static void reactTo(String ownerUid, String statusId, String emoji) {
        reactTo(ownerUid, statusId, emoji, null, null);
    }
    public static void removeReaction(String ownerUid, String statusId) {
        if (ownerUid == null || statusId == null) return;
        String myUid = safeUid();
        if (myUid == null) return;
        FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId).child("reactions").child(myUid).removeValue();
    }
    public interface OnReactionCallback {
        void onReaction(String newEmoji); // null = removed
    }
    // ── Delete (soft) ─────────────────────────────────────────────────────
    public static void deleteStatus(String ownerUid, String statusId) {
        if (ownerUid == null || statusId == null) return;
        String myUid = safeUid();
        if (myUid == null || !myUid.equals(ownerUid)) return;
        FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId).child("deleted").setValue(true);
    }
    // ── Forward tracking ──────────────────────────────────────────────────
    public static void incrementForwardCount(String ownerUid, String statusId) {
        if (ownerUid == null || statusId == null) return;
        FirebaseUtils.getStatusRef()
            .child(ownerUid).child(statusId)
            .child("forwardCount")
            .runTransaction(new com.google.firebase.database.Transaction.Handler() {
                @Override
                public com.google.firebase.database.Transaction.Result doTransaction(
                        com.google.firebase.database.MutableData data) {
                    Long cur = data.getValue(Long.class);
                    data.setValue(cur == null ? 1L : cur + 1);
                    return com.google.firebase.database.Transaction.success(data);
                }
                @Override
                public void onComplete(com.google.firebase.database.DatabaseError e,
                                       boolean committed, com.google.firebase.database.DataSnapshot s) {}
            });
    }
    // ── Internal: chat bubble ─────────────────────────────────────────────
    /**
     * BUG FIX: the old dedup check only looked at the CHAT'S LAST MESSAGE
     * (orderByChild("timestamp").limitToLast(1)) to decide whether a
     * "seen your status" bubble was already shown within the last 24h.
     * That broke in two common ways:
     *   1. If ANY other message landed in the chat afterward (a reply, a
     *      status_reaction bubble, literally anything), the last message
     *      was no longer the status_seen bubble, so the check missed it
     *      and wrote a fresh duplicate bubble — this is exactly what
     *      happened when re-viewing the same status repeatedly, since
     *      each view can itself interleave other writes.
     *   2. Re-opening/rewinding the same status in quick succession raced
     *      two independent "read last message, then decide to write"
     *      calls against each other — neither read saw the other's
     *      not-yet-committed write, so both proceeded to write a bubble.
     * Fix: track "last bubble shown" on a dedicated gate node
     * (statusSeenBubbleGate/{chatId}/{viewerUid}) instead of inferring it
     * from chat history, and decide-and-claim it with a single atomic
     * Firebase transaction. This is independent of whatever else is in
     * the chat, and the transaction guarantees only one caller wins even
     * if two views race at the same instant.
     */
    private static void writeStatusSeenToChat(String viewerUid, String ownerUid,
                                               String ownerName, String statusThumbUrl) {
        String chatId = viewerUid.compareTo(ownerUid) < 0
                ? viewerUid + "_" + ownerUid : ownerUid + "_" + viewerUid;
        final long now = System.currentTimeMillis();
        com.google.firebase.database.DatabaseReference gateRef =
                FirebaseUtils.db().getReference("statusSeenBubbleGate")
                        .child(chatId).child(viewerUid);
        gateRef.runTransaction(new com.google.firebase.database.Transaction.Handler() {
            @Override
            public com.google.firebase.database.Transaction.Result doTransaction(
                    com.google.firebase.database.MutableData data) {
                Long last = data.getValue(Long.class);
                if (last != null && (now - last) < DEDUP_WINDOW_MS) {
                    // Bubble already shown within the window — claim nothing,
                    // abort so onComplete() knows not to write a bubble.
                    return com.google.firebase.database.Transaction.abort();
                }
                data.setValue(now);
                return com.google.firebase.database.Transaction.success(data);
            }
            @Override
            public void onComplete(com.google.firebase.database.DatabaseError error,
                                    boolean committed,
                                    com.google.firebase.database.DataSnapshot snap) {
                if (error != null || !committed) return; // deduped (or failed) — no bubble
                com.google.firebase.database.DatabaseReference messagesRef =
                        FirebaseUtils.db().getReference("messages").child(chatId);
                FirebaseUtils.db().getReference("users").child(viewerUid)
                    .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                        @Override
                        public void onDataChange(com.google.firebase.database.DataSnapshot u) {
                            String vName  = u.child("name").getValue(String.class);
                            String vPhoto = u.child("photoUrl").getValue(String.class);
                            if (vPhoto == null) vPhoto = u.child("thumbUrl").getValue(String.class);
                            doWriteSeenBubble(messagesRef, viewerUid,
                                    vName  != null ? vName  : "Someone",
                                    vPhoto != null ? vPhoto : "",
                                    ownerUid, ownerName, statusThumbUrl);
                        }
                        @Override
                        public void onCancelled(com.google.firebase.database.DatabaseError e) {
                            doWriteSeenBubble(messagesRef, viewerUid, "Someone", "",
                                    ownerUid, ownerName, statusThumbUrl);
                        }
                    });
            }
        });
    }
    private static void doWriteSeenBubble(
            com.google.firebase.database.DatabaseReference ref,
            String viewerUid, String viewerName, String viewerPhoto,
            String ownerUid, String ownerName, String statusThumbUrl) {
        String msgId = ref.push().getKey();
        if (msgId == null) return;
        Map<String, Object> msg = new HashMap<>();
        msg.put("id",              msgId);
        msg.put("senderId",        viewerUid);
        msg.put("senderName",      viewerName);
        msg.put("senderPhoto",     viewerPhoto);
        msg.put("text",            "seen your status");
        msg.put("type",            "status_seen");
        msg.put("timestamp",       ServerValue.TIMESTAMP);
        msg.put("seen",            false);
        msg.put("statusOwnerUid",  ownerUid);
        msg.put("statusOwnerName", ownerName);
        msg.put("statusThumbUrl",  statusThumbUrl); // fallback / older clients, or if the embed below fails
        // WhatsApp-level fix: embed a self-contained copy of the thumbnail
        // (statusThumbBase64) so this bubble keeps rendering even after the
        // status expires/gets deleted or statusThumbUrl's CDN link changes.
        // See ThumbnailEmbedder for the shared download/crop/compress logic
        // (same helper StatusReplyBottomSheet uses for reply thumbnails).
        com.callx.app.utils.ThumbnailEmbedder.embed(statusThumbUrl, base64 -> {
            if (base64 != null) msg.put("statusThumbBase64", base64);
            ref.child(msgId).setValue(msg);
        });
    }
    private static void notifyReaction(String ownerUid, String statusId,
                                        String emoji, String reactorUid) {
        Map<String, Object> n = new HashMap<>();
        n.put("type",      "status_reaction");
        n.put("fromUid",   reactorUid);
        n.put("emoji",     emoji);
        n.put("statusId",  statusId);
        n.put("timestamp", ServerValue.TIMESTAMP);
        FirebaseUtils.db().getReference("notifications")
            .child(ownerUid).push().setValue(n);
    }
    private static String safeUid() {
        try { return FirebaseUtils.getCurrentUid(); } catch (Exception e) { return null; }
    }
}