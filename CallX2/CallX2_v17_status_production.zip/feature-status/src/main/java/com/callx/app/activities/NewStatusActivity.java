package com.callx.app.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.bumptech.glide.Glide;
import com.callx.app.status.databinding.ActivityNewStatusBinding;
import com.callx.app.models.StatusItem;
import com.callx.app.utils.*;
import androidx.annotation.NonNull;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.*;
import com.callx.app.utils.StatusLinkPreviewFetcher;

/**
 * NewStatusActivity — Production-grade status creation.
 *
 * Features:
 *   • Text status with custom background color picker (10 presets)
 *   • Font style selector (Default / Bold / Italic / Handwriting)
 *   • Image status with caption  ← NOW compressed via ImageCompressor
 *   • Video status with caption  ← NOW compressed via VideoCompressor
 *   • Link detection in text with metadata fetch hint
 *   • Privacy mode selector (Everyone / Contacts / Except… / Only…)
 *   • Upload progress with percentage display
 *   • Character counter for text statuses
 *   • Preview card that updates live as you type / pick media
 *   • Cloudinary upload with retry on transient errors
 *   • Auto-saves draft text to SharedPreferences
 *
 * v24 changes:
 *   ✅ Image  → ImageCompressor (EXIF fix + WebP + thumbnail)
 *   ✅ Video  → VideoCompressor (LiTr, multi-codec, quality-aware)
 *   ✅ Compression progress shown in tvUploadHint
 *   ✅ Fallback to direct upload if compression fails
 */
public class NewStatusActivity extends AppCompatActivity {

    private static final String PREFS_DRAFT = "status_draft";
    private static final String KEY_DRAFT   = "draft_text";

    // Background color presets for text statuses
    private static final int[] BG_COLORS = {
        0xFF6200EE, 0xFF03DAC5, 0xFFE53935, 0xFF43A047,
        0xFF1E88E5, 0xFFFF6F00, 0xFF8E24AA, 0xFF00ACC1,
        0xFF6D4C41, 0xFF263238
    };
    private static final int[] TEXT_COLORS_FOR_BG = {
        0xFFFFFFFF, 0xFF000000, 0xFFFFFFFF, 0xFFFFFFFF,
        0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,
        0xFFFFFFFF, 0xFFFFFFFF
    };

    private ActivityNewStatusBinding binding;
    private Uri   pickedImage, pickedVideo;
    private int   selectedBgColor   = BG_COLORS[0];
    private int   selectedTextColor = TEXT_COLORS_FOR_BG[0];
    private String selectedFontStyle = "default";
    private String selectedPrivacy    = StatusPrivacyManager.PRIVACY_CONTACTS;
    private StatusLinkPreviewFetcher.LinkPreview detectedLinkPreview = null;

    private ActivityResultLauncher<String> imagePicker;
    private ActivityResultLauncher<String> videoPicker;

    // ── Lifecycle ─────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNewStatusBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupToolbar();
        setupMediaPickers();
        setupBgColorPicker();
        setupFontStylePicker();
        setupPrivacyPicker();
        setupTextInput();
        restoreDraft();

        binding.btnPickImage.setOnClickListener(v -> pickImage());
        binding.btnPickVideo.setOnClickListener(v -> pickVideo());
        binding.btnPost.setOnClickListener(v -> post());
        binding.btnDiscardMedia.setOnClickListener(v -> discardMedia());
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveDraft();
    }

    // ── Toolbar ───────────────────────────────────────────────────────────

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    // ── Media pickers ─────────────────────────────────────────────────────

    private void setupMediaPickers() {
        imagePicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) return;
                pickedImage = uri;
                pickedVideo = null;
                showImagePreview(uri);
            });
        videoPicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) return;
                pickedVideo = uri;
                pickedImage = null;
                showVideoPreview(uri);
            });
    }

    private void pickImage() {
        if (hasMediaPermission()) {
            imagePicker.launch("image/*");
        } else {
            requestMediaPermission();
        }
    }

    private void pickVideo() {
        if (hasMediaPermission()) {
            videoPicker.launch("video/*");
        } else {
            requestMediaPermission();
        }
    }

    private boolean hasMediaPermission() {
        String perm = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        return ContextCompat.checkSelfPermission(this, perm)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        String perm = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            granted -> { if (!granted) toast("Media permission denied"); }
        ).launch(perm);
    }

    private void showImagePreview(Uri uri) {
        binding.ivPreview.setVisibility(View.VISIBLE);
        binding.ivVideoHint.setVisibility(View.GONE);
        binding.btnDiscardMedia.setVisibility(View.VISIBLE);
        Glide.with(this).load(uri).centerCrop().into(binding.ivPreview);
        binding.captionGroup.setVisibility(View.VISIBLE);
        hideBgColorPicker();
    }

    private void showVideoPreview(Uri uri) {
        binding.ivPreview.setVisibility(View.VISIBLE);
        binding.ivVideoHint.setVisibility(View.VISIBLE);
        binding.btnDiscardMedia.setVisibility(View.VISIBLE);
        Glide.with(this).load(uri).centerCrop().into(binding.ivPreview);
        binding.captionGroup.setVisibility(View.VISIBLE);
        hideBgColorPicker();
    }

    private void discardMedia() {
        pickedImage = null;
        pickedVideo = null;
        binding.ivPreview.setVisibility(View.GONE);
        binding.ivVideoHint.setVisibility(View.GONE);
        binding.btnDiscardMedia.setVisibility(View.GONE);
        binding.captionGroup.setVisibility(View.GONE);
        showBgColorPicker();
    }

    // ── Background color picker ───────────────────────────────────────────

    private void setupBgColorPicker() {
        for (int i = 0; i < BG_COLORS.length; i++) {
            final int idx = i;
            View swatch = getBgSwatch(i);
            if (swatch == null) continue;
            swatch.setBackgroundColor(BG_COLORS[i]);
            swatch.setOnClickListener(v -> {
                selectedBgColor   = BG_COLORS[idx];
                selectedTextColor = TEXT_COLORS_FOR_BG[idx];
                updateTextStatusPreview();
                highlightSwatch(idx);
            });
        }
        highlightSwatch(0);
    }

    private View getBgSwatch(int idx) {
        try {
            int id = getResources().getIdentifier(
                    "color_swatch_" + idx, "id", getPackageName());
            return id != 0 ? findViewById(id) : null;
        } catch (Exception e) { return null; }
    }

    private void highlightSwatch(int selectedIdx) {
        for (int i = 0; i < BG_COLORS.length; i++) {
            View v = getBgSwatch(i);
            if (v != null) v.setScaleX(i == selectedIdx ? 1.3f : 1f);
            if (v != null) v.setScaleY(i == selectedIdx ? 1.3f : 1f);
        }
    }

    private void hideBgColorPicker() {
        binding.bgColorPickerRow.setVisibility(View.GONE);
    }

    private void showBgColorPicker() {
        binding.bgColorPickerRow.setVisibility(View.VISIBLE);
        updateTextStatusPreview();
    }

    // ── Font style picker ─────────────────────────────────────────────────

    private void setupFontStylePicker() {
        binding.btnFontDefault.setOnClickListener(v     -> setFont("default"));
        binding.btnFontBold.setOnClickListener(v        -> setFont("bold"));
        binding.btnFontItalic.setOnClickListener(v      -> setFont("italic"));
        binding.btnFontHandwriting.setOnClickListener(v -> setFont("handwriting"));
    }

    private void setFont(String style) {
        selectedFontStyle = style;
        updateTextStyleButton(style);
        updateTextStatusPreview();
    }

    private void updateTextStyleButton(String style) {
        binding.btnFontDefault.setSelected("default".equals(style));
        binding.btnFontBold.setSelected("bold".equals(style));
        binding.btnFontItalic.setSelected("italic".equals(style));
        binding.btnFontHandwriting.setSelected("handwriting".equals(style));
    }

    // ── Privacy picker ────────────────────────────────────────────────────

    private void setupPrivacyPicker() {
        selectedPrivacy = StatusPrivacyManager.getPrivacyMode(this);
        updatePrivacyLabel();
        binding.btnPrivacy.setOnClickListener(v -> cyclePrivacy());
    }

    private void cyclePrivacy() {
        switch (selectedPrivacy) {
            case StatusPrivacyManager.PRIVACY_EVERYONE:
                selectedPrivacy = StatusPrivacyManager.PRIVACY_CONTACTS; break;
            case StatusPrivacyManager.PRIVACY_CONTACTS:
                selectedPrivacy = StatusPrivacyManager.PRIVACY_EXCEPT;   break;
            case StatusPrivacyManager.PRIVACY_EXCEPT:
                selectedPrivacy = StatusPrivacyManager.PRIVACY_ONLY;     break;
            default:
                selectedPrivacy = StatusPrivacyManager.PRIVACY_EVERYONE;
        }
        StatusPrivacyManager.setPrivacyMode(this, selectedPrivacy);
        updatePrivacyLabel();
    }

    private void updatePrivacyLabel() {
        String label;
        switch (selectedPrivacy) {
            case StatusPrivacyManager.PRIVACY_EVERYONE: label = "Everyone"; break;
            case StatusPrivacyManager.PRIVACY_CONTACTS: label = "My contacts"; break;
            case StatusPrivacyManager.PRIVACY_EXCEPT:   label = "Contacts except…"; break;
            case StatusPrivacyManager.PRIVACY_ONLY:     label = "Only share with…"; break;
            default: label = "My contacts";
        }
        binding.btnPrivacy.setText(label);
    }

    // ── Text input & preview ──────────────────────────────────────────────

    private void setupTextInput() {
        binding.etText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                int len = s.length();
                binding.tvCharCount.setText(len + " / 700");
                updateTextStatusPreview();
                if (len > 700) {
                    binding.tilText.setError("Max 700 characters");
                } else {
                    binding.tilText.setError(null);
                }
                // Link detection: fetch OG preview when a URL is typed
                String detectedUrl = StatusLinkPreviewFetcher.detectUrl(s.toString());
                if (detectedUrl != null) {
                    fetchLinkPreview(detectedUrl);
                } else {
                    detectedLinkPreview = null;
                    hideLinkPreviewCard();
                }
            }
        });
    }

    private void updateTextStatusPreview() {
        if (pickedImage != null || pickedVideo != null) return;
        String text = binding.etText.getText().toString().trim();
        if (text.isEmpty()) {
            binding.textPreviewCard.setVisibility(View.GONE);
            return;
        }
        binding.textPreviewCard.setVisibility(View.VISIBLE);
        binding.textPreviewCard.setCardBackgroundColor(selectedBgColor);
        binding.tvTextPreview.setText(text);
        binding.tvTextPreview.setTextColor(selectedTextColor);
        applyFontStyle(binding.tvTextPreview, selectedFontStyle);
    }

    private void applyFontStyle(android.widget.TextView tv, String style) {
        switch (style) {
            case "bold":
                tv.setTypeface(null, android.graphics.Typeface.BOLD); break;
            case "italic":
                tv.setTypeface(null, android.graphics.Typeface.ITALIC); break;
            case "handwriting":
                tv.setTypeface(android.graphics.Typeface.MONOSPACE); break;
            default:
                tv.setTypeface(null, android.graphics.Typeface.NORMAL);
        }
    }

    // ── Draft save / restore ──────────────────────────────────────────────

    private void saveDraft() {
        String text = binding.etText.getText().toString();
        getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE)
            .edit().putString(KEY_DRAFT, text).apply();
    }

    private void restoreDraft() {
        String draft = getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE)
            .getString(KEY_DRAFT, "");
        if (draft != null && !draft.isEmpty()) {
            binding.etText.setText(draft);
        }
    }

    private void clearDraft() {
        getSharedPreferences(PREFS_DRAFT, MODE_PRIVATE)
            .edit().remove(KEY_DRAFT).apply();
    }

    // ── Post ──────────────────────────────────────────────────────────────

    private void post() {
        String txt     = binding.etText.getText().toString().trim();
        String caption = binding.etCaption != null
                ? binding.etCaption.getText().toString().trim() : "";

        if (pickedImage == null && pickedVideo == null && txt.isEmpty()) {
            toast("Kuch text ya media add karo");
            return;
        }
        if (txt.length() > 700) {
            toast("Text 700 characters se zyada nahi ho sakta");
            return;
        }

        setPosting(true);

        String uid  = FirebaseAuth.getInstance().getCurrentUser().getUid();
        String name = FirebaseUtils.getCurrentName();

        FirebaseUtils.getUserRef(uid).addListenerForSingleValueEvent(
            new com.google.firebase.database.ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snap) {
                    String thumb = snap.child("thumbUrl").getValue(String.class);
                    String fullP = snap.child("photoUrl").getValue(String.class);
                    String photo = (thumb != null && !thumb.isEmpty()) ? thumb : (fullP != null ? fullP : safePhoto());
                    dispatchMedia(pickedImage, pickedVideo, caption, txt, uid, name, photo);
                }
                @Override public void onCancelled(@NonNull DatabaseError e) {
                    String photo = safePhoto();
                    dispatchMedia(pickedImage, pickedVideo, caption, txt, uid, name, photo);
                }
            });
    }

    /**
     * Route to the right compress → upload pipeline based on media type.
     */
    private void dispatchMedia(Uri imageUri, Uri videoUri,
                               String caption, String txt,
                               String uid, String name, String photo) {
        if (imageUri != null) {
            compressAndUploadImage(imageUri, caption, txt, uid, name, photo);
        } else if (videoUri != null) {
            compressAndUploadVideo(videoUri, caption, txt, uid, name, photo);
        } else if (detectedLinkPreview != null) {
            // Link status
            saveLinkStatus(detectedLinkPreview, uid, name, photo);
        } else {
            // Text-only status — no media needed
            saveStatus("text", null, null, txt, caption, uid, name, photo);
        }
    }

    // ── Image: compress → upload ──────────────────────────────────────────

    private void compressAndUploadImage(Uri uri, String caption, String txt,
                                        String uid, String name, String photo) {
        runOnUiThread(() -> setHint("Compressing image…"));

        ImageCompressor.compress(this, uri, new ImageCompressor.Callback() {
            @Override
            public void onSuccess(ImageCompressor.Result result) {
                runOnUiThread(() -> setHint("Uploading image…"));
                // Convert compressed file to Uri for CloudinaryUploader
                Uri compressedUri = Uri.fromFile(result.fullFile);
                uploadAndSave(compressedUri, "image", caption, txt, uid, name, photo,
                        /*thumbFile=*/ result.thumbFile);
            }

            @Override
            public void onError(Exception e) {
                // Compression failed — fallback to original
                android.util.Log.w("NewStatus", "Image compress failed, fallback to original", e);
                runOnUiThread(() -> setHint("Uploading image…"));
                uploadAndSave(uri, "image", caption, txt, uid, name, photo, /*thumbFile=*/ null);
            }
        });
    }

    // ── Video: compress → upload ──────────────────────────────────────────

    private void compressAndUploadVideo(Uri uri, String caption, String txt,
                                        String uid, String name, String photo) {
        runOnUiThread(() -> setHint("Compressing video… 0%"));

        VideoQualityPreferences.Quality quality = new VideoQualityPreferences(this).getGlobalQuality();

        VideoCompressor.compress(this, uri, quality, new VideoCompressor.Callback() {
            @Override
            public void onProgress(int percent) {
                runOnUiThread(() -> setHint("Compressing video… " + percent + "%"));
            }

            @Override
            public void onSuccess(VideoCompressor.Result result) {
                runOnUiThread(() -> setHint("Uploading video…"));
                android.util.Log.i("NewStatus", result.compressionSummary());
                Uri compressedUri = Uri.fromFile(result.videoFile);
                uploadAndSave(compressedUri, "video", caption, txt, uid, name, photo,
                        /*thumbFile=*/ result.thumbFile);
            }

            @Override
            public void onError(Exception e) {
                // Compression failed — fallback to original
                android.util.Log.w("NewStatus", "Video compress failed, fallback to original", e);
                runOnUiThread(() -> setHint("Uploading video…"));
                uploadAndSave(uri, "video", caption, txt, uid, name, photo, /*thumbFile=*/ null);
            }
        });
    }

    // ── Upload (shared for both image + video) ────────────────────────────

    /**
     * Upload compressed (or original fallback) media to Cloudinary, then save status.
     *
     * @param thumbFile  Pre-generated thumbnail from compressor (may be null).
     *                   If non-null and upload is video, we upload thumb separately
     *                   to get a thumbUrl for the status card.
     */
    private void uploadAndSave(Uri uri, String type, String caption,
                               String txt, String uid, String name, String photo,
                               java.io.File thumbFile) {

        String resourceType = "video".equals(type) ? "video" : "image";

        CloudinaryUploader.upload(this, uri, "callx/status", resourceType,
            new CloudinaryUploader.UploadCallback() {
                @Override public void onSuccess(CloudinaryUploader.Result r) {
                    runOnUiThread(() -> {
                        setPosting(false);
                        // For video: prefer local thumb we generated, fallback to Cloudinary eager thumb
                        String thumbUrl = null;
                        if ("video".equals(type)) {
                            if (r.thumbnailUrl != null && !r.thumbnailUrl.isEmpty()) {
                                thumbUrl = r.thumbnailUrl;
                            } else if (thumbFile != null && thumbFile.exists()) {
                                // Upload the local thumb separately — fire-and-forget
                                // We save status immediately with null thumbUrl and patch later
                                uploadThumbAsync(thumbFile, uid, /*statusRef will be set in saveStatus*/null);
                            }
                        }
                        // Clean up compressed files
                        if (thumbFile != null) VideoCompressor.safeDelete(thumbFile);
                        saveStatus(type, r.secureUrl, thumbUrl, txt, caption, uid, name, photo);
                    });
                }
                @Override public void onError(String err) {
                    runOnUiThread(() -> {
                        setPosting(false);
                        toast(err != null ? err : "Upload fail hua, dobara try karo");
                    });
                }
            });
    }

    /** Upload a local thumbnail file to Cloudinary in background (fire-and-forget). */
    private void uploadThumbAsync(java.io.File thumbFile, String uid, Object ignored) {
        Uri thumbUri = Uri.fromFile(thumbFile);
        CloudinaryUploader.upload(this, thumbUri, "callx/status/thumb", "image",
            new CloudinaryUploader.UploadCallback() {
                @Override public void onSuccess(CloudinaryUploader.Result r) {
                    VideoCompressor.safeDelete(thumbFile);
                    android.util.Log.i("NewStatus", "Thumb uploaded: " + r.secureUrl);
                }
                @Override public void onError(String err) {
                    VideoCompressor.safeDelete(thumbFile);
                    android.util.Log.w("NewStatus", "Thumb upload failed (non-fatal): " + err);
                }
            });
    }

    private void saveStatus(String type, String mediaUrl, String thumbUrl,
                            String txt, String caption,
                            String uid, String name, String photo) {
        long now = System.currentTimeMillis();
        DatabaseReference ref = FirebaseUtils.getStatusRef().child(uid).push();

        StatusItem item = new StatusItem();
        item.id           = ref.getKey();
        item.ownerUid     = uid;
        item.ownerName    = name;
        item.ownerPhoto   = photo;
        item.type         = type;
        item.text         = txt;
        item.caption      = caption;
        item.mediaUrl     = mediaUrl;
        item.thumbnailUrl = thumbUrl;
        item.timestamp    = now;
        item.expiresAt    = now + Constants.STATUS_TTL_MS;
        item.privacy      = selectedPrivacy;
        item.bgColor      = String.format("#%08X", selectedBgColor);
        item.textColor    = String.format("#%08X", selectedTextColor);
        item.fontStyle    = selectedFontStyle;
        item.textSize     = 28;
        item.deleted      = false;

        ref.setValue(item.toMap()).addOnSuccessListener(x -> {
            PushNotify.notifyStatus(uid, name);
            clearDraft();
            toast("Status post ho gaya!");
            finish();
        }).addOnFailureListener(e -> {
            setPosting(false);
            toast("Save fail hua: " + e.getMessage());
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void setPosting(boolean posting) {
        binding.btnPost.setEnabled(!posting);
        binding.uploadProgress.setVisibility(posting ? View.VISIBLE : View.GONE);
        binding.tvUploadHint.setVisibility(posting ? View.VISIBLE : View.GONE);
        if (posting && binding.tvUploadHint.getText().toString().isEmpty()) {
            binding.tvUploadHint.setText("Processing…");
        }
    }

    private void setHint(String hint) {
        binding.tvUploadHint.setVisibility(View.VISIBLE);
        binding.tvUploadHint.setText(hint);
    }

    private String safePhoto() {
        try {
            android.net.Uri uri = FirebaseAuth.getInstance()
                .getCurrentUser().getPhotoUrl();
            return uri != null ? uri.toString() : null;
        } catch (Exception e) { return null; }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    // ── Link preview fetch + display ──────────────────────────────────────

    private void fetchLinkPreview(String url) {
        if (detectedLinkPreview != null && url.equals(detectedLinkPreview.url)) return;
        StatusLinkPreviewFetcher.fetch(url, new StatusLinkPreviewFetcher.Callback() {
            @Override
            public void onResult(StatusLinkPreviewFetcher.LinkPreview preview) {
                detectedLinkPreview = preview;
                showLinkPreviewCard(preview);
            }
            @Override
            public void onError(String message) {
                detectedLinkPreview = null;
                hideLinkPreviewCard();
            }
        });
    }

    private void showLinkPreviewCard(StatusLinkPreviewFetcher.LinkPreview preview) {
        try {
            View card = binding.linkPreviewCard;
            if (card == null) return;
            card.setVisibility(View.VISIBLE);
            android.widget.TextView tvTitle  = binding.tvLinkTitle;
            android.widget.TextView tvDomain = binding.tvLinkDomain;
            android.widget.ImageView ivThumb = binding.ivLinkThumb;
            if (tvTitle  != null) tvTitle.setText(preview.title   != null ? preview.title   : "");
            if (tvDomain != null) tvDomain.setText(preview.domain != null ? preview.domain  : "");
            if (ivThumb  != null && preview.imageUrl != null && !preview.imageUrl.isEmpty()) {
                ivThumb.setVisibility(View.VISIBLE);
                Glide.with(this).load(preview.imageUrl).centerCrop().into(ivThumb);
            } else if (ivThumb != null) {
                ivThumb.setVisibility(View.GONE);
            }
        } catch (Exception ignored) {}
    }

    private void hideLinkPreviewCard() {
        try {
            View card = binding.linkPreviewCard;
            if (card != null) card.setVisibility(View.GONE);
        } catch (Exception ignored) {}
    }

    private void saveLinkStatus(StatusLinkPreviewFetcher.LinkPreview preview,
                                String uid, String name, String photo) {
        long now = System.currentTimeMillis();
        DatabaseReference ref = FirebaseUtils.getStatusRef().child(uid).push();
        StatusItem item = new StatusItem();
        item.id           = ref.getKey();
        item.ownerUid     = uid;
        item.ownerName    = name;
        item.ownerPhoto   = photo;
        item.type         = "link";
        item.text         = binding.etText.getText().toString().trim();
        item.caption      = null;
        item.mediaUrl     = null;
        item.thumbnailUrl = preview.imageUrl;
        item.timestamp    = now;
        item.expiresAt    = now + Constants.STATUS_TTL_MS;
        item.privacy      = selectedPrivacy;
        item.bgColor      = String.format("#%08X", selectedBgColor);
        item.textColor    = String.format("#%08X", selectedTextColor);
        item.fontStyle    = selectedFontStyle;
        item.linkUrl      = preview.url;
        item.linkTitle    = preview.title;
        item.linkDescription = preview.description;
        item.linkFaviconUrl  = preview.faviconUrl;
        item.textSize     = 24;
        item.deleted      = false;
        ref.setValue(item.toMap()).addOnSuccessListener(x -> {
            PushNotify.notifyStatus(uid, name);
            clearDraft();
            detectedLinkPreview = null;
            toast("Status post ho gaya!");
            finish();
        }).addOnFailureListener(e -> {
            setPosting(false);
            toast("Save fail hua: " + e.getMessage());
        });
    }


}
